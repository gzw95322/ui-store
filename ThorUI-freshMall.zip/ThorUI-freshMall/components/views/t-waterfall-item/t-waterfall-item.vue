<template>
	<view :id="itemId" class="tui-waterfall__item-box" :class="{'tui-waterfall__item-show':isShow}"
		:style="{width:width+'px',transform:transform}" @tap="handleTap">
		<view class="tui-wf__img-box" :class="{'tui-waterfall__img-box':!isLoaded}">
			<image class="tui-waterfall__img" :src="item.src" mode="widthFix"></image>
		</view>
		<view class="tui-pro__content">
			<view class="tui-product__tit">{{item.title}}</view>
			<view class="tui-product__tag">
				<view class="tui-pro__tag" :class="['tui-tag__tj']">特价</view>
				<view class="tui-pro__tag" :class="['tui-tag__24h']">24H发货</view>
			</view>
			<view class="tui-product__info">
				<view class="tui-pri__box">
					<text class="tui-pri__sign">￥</text>
					<text class="tui-pri__num">{{item.price}}</text>
					<text class="tui-pri__unit">{{item.unit}}</text>
				</view>
				<image src="/static/images/common/cart_3x.png" class="tui-add__icon"></image>
			</view>
		</view>
		<slot></slot>
	</view>
</template>

<script>
	export default {
		name: "t-waterfall-item",
		emits: ['click'],
		inject: ['waterfall'],
		// #ifdef MP-WEIXIN
		options: {
			virtualHost: true
		},
		// #endif
		props: {
			item: {
				type: Object,
				default () {
					return {}
				}
			},
			index: {
				type: [Number, String],
				default: 0
			}
		},
		created() {
			if (this.waterfall) {
				this.waterfall.children.push(this)
				if (this.waterfall.itemWidth) {
					this.width = this.waterfall.itemWidth
				} else {
					this.waterfall.initParam((width) => {
						this.width = width
					})
				}
			}
		},
		mounted() {
			this.$nextTick(() => {
				setTimeout(() => {
					this.getWaterfallItemInfo()
				}, 20)
			})
		},
		data() {
			const itemId = `tui_w_${Math.ceil(Math.random() * 10e5).toString(36)}`
			return {
				itemId: itemId,
				width: 0,
				height: 0,
				transform: '',
				isShow: false,
				isLoaded: true
			};
		},
		methods: {
			getWaterfallItemInfo() {
				this.getItemHeight((res) => {
					if (this.waterfall) {
						this.waterfall.loadeds.push('success')
						setTimeout(() => {
							this.waterfall.startSorting()
						}, 10)
					}
				})
			},
			getItemHeight(callback, index = 0) {
				uni.createSelectorQuery()
					// #ifndef MP-ALIPAY
					.in(this)
					// #endif
					.select(`#${this.itemId}`)
					.fields({
						size: true
					}, data => {
						if (index >= 20) return
						if (data && data.height) {
							this.height = data.height
							callback && callback(data.height)
						} else {
							index++
							setTimeout(() => {
								this.getItemHeight(index)
							}, 50)
							return
						}
					})
					.exec()
			},
			handleTap() {
				this.$emit('click', {
					index: this.index,
					item: this.item
				})
			}
		}
	}
</script>

<style scoped>
	.tui-waterfall__item-box {
		position: absolute;
		left: 0;
		top: 0;
		display: flex;
		box-sizing: border-box;
		overflow: hidden;
		opacity: 0;
		transition-property: opacity;
		transition-duration: .3s;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		background: #FFFFFF;
		border-radius: 20rpx;
	}

	.tui-waterfall__item-show {
		opacity: 1;
	}

	.tui-wf__img-box {
		width: 274rpx;
		height: 274rpx;
		display: flex;
		align-items: center;
		justify-content: center;
		overflow: hidden;
	}

	.tui-waterfall__img-box {
		background: #EDEFF2;
		overflow: hidden;
	}

	.tui-waterfall__img {
		width: 260rpx;
		height: 260rpx;
		display: block;
	}

	.tui-pro__content {
		width: 100%;
		padding: 12rpx 30rpx;
		box-sizing: border-box;
	}

	.tui-add__icon {
		width: 44rpx;
		height: 44rpx;
		display: block;
		/* #ifdef H5 */
		cursor: pointer;
		/* #endif */
	}

	.tui-product__tit {
		width: 100%;
		font-size: 26rpx;
		font-weight: 500;
		color: #333;
		word-break: break-all;
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 2;
		margin-bottom: 20rpx;
	}

	.tui-product__tag {
		display: flex;
		align-items: center;
	}

	.tui-pro__tag {
		padding: 0 4rpx;
		font-size: 25rpx;
		zoom: 0.6;
		margin-right: 8rpx;
		position: relative;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.tui-pro__tag::after {
		content: '';
		position: absolute;
		width: 200%;
		height: 200%;
		border-width: 1px;
		border-style: solid;
		left: 0;
		top: 0;
		transform: scale(.5);
		transform-origin: 0 0;
		border-radius: 4rpx;
		box-sizing: border-box;
	}

	.tui-tag__tj {
		color: #F55726;
	}

	.tui-tag__tj::after {
		border-color: #F55726;
	}

	.tui-tag__24h {
		color: #40AE36;
	}
	.tui-tag__24h::after {
		border-color: #40AE36;
	}

	.tui-product__info {
		width: 100%;
		min-height: 44rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding-top: 20rpx;
		padding-bottom: 12rpx;
	}

	.tui-pri__sign {
		font-size: 24rpx;
		line-height: 24rpx;
		color: #F55726;
	}

	.tui-pri__num {
		font-size: 32rpx;
		line-height: 32rpx;
		font-weight: 500;
		color: #F55726;
	}

	.tui-pri__unit {
		font-size: 24rpx;
		line-height: 24rpx;
		color: #999999;
	}
</style>
