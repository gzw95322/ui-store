<template>
	<tui-bottom-popup :show="show">
		<view class="tui-bp__tit tui-flex__center">
			<text>分享到</text>
			<view class="tui-icon--close" @tap="hideShare">
				<tui-icon name="shut" unit="rpx" :size="44" color="#333"></tui-icon>
			</view>
		</view>
		<view class="tui-share__list">
			<view class="tui-share__item" v-for="(item,index) in list" :key="index">
				<tui-icon :name="item.icon" :color="item.color" unit="rpx" :size="item.size || 102"></tui-icon>
				<text class="tui-share__txt">{{item.text}}</text>
			</view>
		</view>
		<view class="tui-btn--box">
			<tui-button shape="circle" type="white" height="88rpx" :size="30" bold @click="hideShare">取消分享
			</tui-button>
		</view>
	</tui-bottom-popup>
</template>

<script>
	export default {
		emits: ['cancel'],
		name: "t-share",
		props: {
			show: {
				type: Boolean,
				default: false
			}
		},
		data() {
			return {
				list: [{
					icon: 'wechat',
					color: '#3ED176',
					text: '微信'
				}, {
					icon: 'moments',
					color: '#70E15A',
					text: '朋友圈',
					size: 90
				}, {
					icon: 'qq',
					color: '#42B6F5',
					text: 'QQ',
					size: 98
				}, {
					icon: 'sina',
					color: '#F35B43',
					text: '微博'
				}]
			};
		},
		methods: {
			hideShare() {
				this.$emit('cancel')
			}
		}
	}
</script>

<style scoped>
	.tui-bp__tit {
		width: 100%;
		padding: 30rpx;
		box-sizing: border-box;
		position: relative;
		font-weight: 500;
	}

	.tui-icon--close {
		position: absolute;
		right: 22rpx;
		top: 12rpx;
		padding: 8rpx;
		/* #ifdef H5 */
		cursor: pointer;
		/* #endif */
	}

	.tui-share__list {
		width: 100%;
		display: flex;
		justify-content: space-between;
		padding: 24rpx 24rpx 0;
		box-sizing: border-box;
	}

	.tui-share__item {
		flex: 1;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		/* #ifdef H5 */
		cursor: pointer;
		/* #endif */
	}
	.tui-share__item:active{
		opacity: .5;
	}

	.tui-share__txt {
		color: #8B8A99;
		font-size: 26rpx;
		padding-top: 12rpx;
	}

	.tui-btn--box {
		width: 100%;
		padding: 60rpx 60rpx 30rpx;
		box-sizing: border-box;
	}
</style>
