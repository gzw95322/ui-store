<template>
	<view class="tui-goods__bar" :class="{'tui-safe__area':safeArea || isH5,'tui-main__page':mainPage}">
		<view class="tui-goods__bar-inner tui--flex" :class="['tui-flex--'+align]">
			<tui-label v-if="checkAll">
				<view class="tui--flex">
					<tui-checkbox color="#40AE36"></tui-checkbox>
					<text class="tui-check--all">全选</text>
				</view>
			</tui-label>
			<view class="tui--flex">
				<view class="tui-price--box">
					<text class="tui-size--24" v-if="num>0">共{{num}}件，</text>
					<text class="tui-size--24">合计：</text>
					<text class="tui-color--price tui-size--24">￥</text>
					<text class="tui-color--price tui-bold">79.8</text>
				</view>
				<tui-form-button width="180rpx" height="70rpx" radius="40rpx" @click="handleClick">{{text}}
				</tui-form-button>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "t-goods-bar",
		emits: ['click'],
		props: {
			checkAll: {
				type: Boolean,
				default: true
			},
			//商品数量，大于0时展示
			num: {
				type: Number,
				default: 0
			},
			//价格，处理后的数据
			price: {
				type: String,
				default: '79.8'
			},
			text: {
				type: String,
				default: '去结算'
			},
			//内容对齐方式：left between right
			align: {
				type: String,
				default: 'between'
			},
			//是否需要适配安全区域，非H5有效
			safeArea: {
				type: Boolean,
				default: false
			},
			//当前页面是否为tabbar主页面
			mainPage: {
				type: Boolean,
				default: false
			}
		},
		data() {
			let isH5 = false
			// #ifdef H5
			isH5 = true
			// #endif
			return {
				isH5
			}
		},
		methods: {
			handleClick() {
				this.$emit('click', {})
			}
		}

	}
</script>

<style scoped>
	.tui-goods__bar {
		position: fixed;
		z-index: 10;
		left: 0;
		right: 0;
		bottom: 0;
		background-color: #fff;
	}

	.tui-goods__bar::before {
		content: '';
		width: 100%;
		border-top: 1px solid #eaeef1;
		position: absolute;
		top: 0;
		left: 0;
		transform: scaleY(0.5);
		transform-origin: 0 0;
	}

	/* #ifdef H5 */
	.tui-main__page {
		bottom: 50px;
	}

	/* #endif */
	.tui-goods__bar-inner {
		width: 100%;
		height: 100rpx;
		padding: 0 30rpx;
		box-sizing: border-box;
	}

	.tui--flex {
		display: flex;
		align-items: center;
	}

	.tui-flex--between {
		justify-content: space-between;
	}

	.tui-flex--end {
		justify-content: flex-end;
	}

	.tui-check--all {
		font-size: 26rpx;
		padding-left: 16rpx;
	}

	.tui-price--box {
		padding-right: 30rpx;
	}

	.tui-size--24 {
		font-size: 24rpx;
	}

	.tui-bold {
		font-weight: bold;
	}

	.tui-color--price {
		color: #F55726;
	}

	.tui-safe__area {
		padding-bottom: constant(safe-area-inset-bottom);
		padding-bottom: env(safe-area-inset-bottom);
	}
</style>
