<template>
	<view class="tui-waterfall__box" :style="{height:height+'px'}">
		<slot></slot>
	</view>
</template>

<script>
	export default {
		name: "t-waterfall",
		emits: ['init', 'end'],
		props: {
			columnGap: {
				type: [Number, String],
				default: 20
			},
			topGap: {
				type: [Number, String],
				default: 20
			},
			leftGap: {
				type: [Number, String],
				default: 30
			},
			rightGap: {
				type: [Number, String],
				default: 30
			}
		},
		provide() {
			return {
				waterfall: this
			}
		},
		data() {
			return {
				height: 0,
				itemWidth: 0,
				leftHeight: 0,
				rightHeight: 0,
				tGap: 0,
				lGap: 0,
				x2: 0
			};
		},
		created() {
			this.children = []
			this.loadeds = []
			this.initParam()
		},
		// #ifndef VUE3
		beforeDestroy() {
			this.children = null
			this.loadeds = null
		},
		// #endif
		// #ifdef VUE3
		beforeUnmount() {
			this.children = null
			this.loadeds = null
		},
		// #endif
		methods: {
			getPx(value) {
				let val = parseInt(uni.upx2px(Number(value)))
				return val % 2 === 0 ? val : val + 1
			},
			initParam(callback) {
				this.tGap = this.getPx(this.topGap)
				this.lGap = this.getPx(this.leftGap)
				const colGap = this.getPx(this.columnGap)
				const rGap = this.getPx(this.rightGap)
				const sys = uni.getSystemInfoSync()
				const gap = colGap + this.lGap + rGap;
				this.itemWidth = (sys.windowWidth - gap) / 2
				this.x2 = this.lGap + this.itemWidth + colGap
				callback && callback(this.itemWidth)
				this.$emit('init', {
					itemWidth: this.itemWidth
				})
			},
			resetLoadmore() {
				this.leftHeight = 0
				this.rightHeight = 0
				this.height = 0
				this.children = []
				this.loadeds = []
			},
			getWaterfallInfo(itemHeight, callback) {
				if (!itemHeight) return;
				let x = this.lGap;
				let y = 0;
				let itemGap = 0;
				if (this.leftHeight <= this.rightHeight) {
					y = this.leftHeight;

					if (this.leftHeight === 0) {
						this.leftHeight += itemHeight;
					} else {
						itemGap = this.tGap;
						y += this.tGap;
						this.leftHeight += itemHeight + this.tGap;
					}
				} else {
					x = this.x2;
					y = this.rightHeight;

					if (this.rightHeight === 0) {
						this.rightHeight += itemHeight;
					} else {
						itemGap = this.tGap;
						y += this.tGap;
						this.rightHeight += itemHeight + this.tGap;
					}
				}
				callback && callback({
					x,
					y,
					itemGap
				})
			},
			setWaterfallHeight(itemGap) {
				this.height = Math.ceil(Math.max(this.leftHeight, this.rightHeight) + itemGap);
			},
			startSorting() {
				let clen = this.children.length
				let llen = this.loadeds.length
				if (clen === llen && llen > 0) {
					let itemGap = 0
					this.children.forEach((item, index) => {
						this.getWaterfallInfo(item.height, (res) => {
							itemGap = res.itemGap
							item.transform = `translate3d(${res.x}px,${res.y}px,0)`
							setTimeout(() => {
								item.isShow = true
							}, 20)
						})
					})
					this.setWaterfallHeight(itemGap)
					this.children = []
					this.loadeds = []
					this.$emit('end', {})
				}
			}
		}
	}
</script>

<style scoped>
	.tui-waterfall__box {
		width: 100%;
		box-sizing: border-box;
		position: relative;
	}
</style>
