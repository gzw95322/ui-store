<template>
  <tui-list-cell radius :arrow="arrow" :hover="false" unlined>
	<view class="tui-address__item" @tap="handleTap">
		<slot></slot>
		<view class="tui-address__pr" v-if="icon">
			<tui-icon name="gps" unit="rpx" color="#40AE36" :size="40"></tui-icon>
		</view>
		<view class="tui-address__content">
			<view class="tui-address__detail" :class="{'tui-address__arrow':arrow}">
				<view class="tui-addr__tag">公司</view>
				<text>北京市海淀区恒大新宏福苑西区20号楼2单2022</text>
			</view>
			<view class="tui-address__contacts">
				<text class="tui-address__pr">张三</text>
				<text>135****7009</text>
			</view>
		</view>
		<view class="tui-edit__icon" v-if="edit" @tap.stop="editAddress">
			<image class="tui-address__edit" src="/static/images/set/edit_3x.png"></image>
		</view>
	 </view>
  </tui-list-cell>
</template>

<script>
	 export default{
		 name:'t-address-item',
		 emits:['edit','click'],
		 props:{
			 icon:{
				 type:Boolean,
				 default:false
			 },
			 arrow:{
				 type:Boolean,
				 default:false
			 },
			 edit:{
				 type:Boolean,
				 default:false
			 }
		 },
		 data(){
			 return {}
		 },
		 methods:{
			 editAddress(){
				 this.$emit('edit',{})
			 },
			 handleTap(){
				 this.$emit('click',{})
			 }
		 }
	 }
</script>

<style scoped>
	.tui-address__item{
		display: flex;
	}
	
	.tui-addr__tag{
		display: inline-flex;
		align-items: center;
		justify-content: center;
		font-size: 24rpx;
		line-height: 40rpx;
		color: var(--tui-primary, #40AE36);
		background: var(--tui-primary-bg, rgba(64, 174, 54, .2));
		padding:0 8rpx;
		height: 40rpx;
		border-radius: 6rpx;
		transform: scale(.8);
		transform-origin: 0 center;
		flex-shrink: 0;
	}
	.tui-address__detail{
		flex: 1;
		font-size: 30rpx;
		font-weight: 500;
		word-break: break-all;
		box-sizing: border-box;
	}
	.tui-address__pr{
		padding-right: 16rpx;
	}
	.tui-address__contacts{
		font-size: 26rpx;
		font-weight: 400;
		color: #666;
		padding-top: 12rpx;
	}
	.tui-address__arrow{
		padding-right: 30rpx;
	}
	.tui-address__edit{
		width: 48rpx;
		height: 48rpx;
	}
	.tui-edit__icon{
		display: flex;
		align-items: center;
		justify-content: center;
		padding-left: 40rpx;
		flex-shrink: 0;
	}
</style>