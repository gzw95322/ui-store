<template>
	<view class="tui-order__item" :class="{'tui-order__item-radius':radius}" @tap="handleTap">
		<view class="tui-item__header" v-if="title || descr">
			<text>{{title}}</text>
			<text class="tui-primary__color">{{descr}}</text>
		</view>
		<view class="tui-order__inner">
			<image class="tui-goods__img" :src="item.src">
			</image>
			<view class="tui-goods__content">
				<view class="tui-goods__title">{{item.title}}</view>
				<view class="tui-goods__descr">规格：{{item.specs}}</view>
				<view class="tui-goods__descr">数量：{{item.quantity}}</view>
			</view>
			<view class="tui-price__box">
				<text class="tui-price__sign">￥</text>
				<text class="tui-price__num">{{item.price || '0.00'}}</text>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 't-order-item',
		emits: ['click'],
		props: {
			title: {
				type: String,
				default: ''
			},
			descr: {
				type: String,
				default: ''
			},
			item: {
				type: Object,
				default () {
					return {
						src: '/static/images/product/cabbage_3x.png',
						title: '彩食有机鲜菠菜彩食新鲜的菠菜 1kg/份彩食有机鲜菠菜彩食新鲜的菠菜 1kg/份',
						specs: '1kg/份',
						quantity: '2份'
					}
				}
			},
			radius: {
				type: Boolean,
				default: false
			}
		},
		methods: {
			handleTap() {
				this.$emit('click', {
					item: this.item
				})
			}
		},
	}
</script>

<style scoped>
	.tui-item__header {
		width: 100%;
		font-size: 24rpx;
		display: flex;
		justify-content: space-between;
		padding-bottom: 30rpx;
	}

	.tui-primary__color {
		color: var(--tui-primary, #40AE36)
	}

	.tui-order__item {
		width: 100%;
		flex: 1;
		background: #fff;
		padding: 20rpx 30rpx;
		box-sizing: border-box;

	}

	.tui-order__inner {
		width: 100%;
		display: flex;
	}

	.tui-order__item-radius {
		border-radius: 20rpx;
		overflow: hidden;
	}

	.tui-goods__img {
		width: 148rpx;
		height: 148rpx;
		margin-right: 30rpx;
		display: block;
		border-radius: 16rpx;
	}

	.tui-goods__content {
		flex: 1;
		position: relative;
	}

	.tui-goods__title {
		width: 100%;
		font-size: 26rpx;
		font-weight: 500;
		color: #333;
		word-break: break-all;
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 2;
		margin-bottom: 12rpx;
	}

	.tui-goods__descr {
		font-size: 27rpx;
		color: #999999;
		zoom: .8;
		margin-bottom: 2rpx;
	}

	.tui-price__sign {
		font-size: 24rpx;
		line-height: 24rpx;
	}

	.tui-price__num {
		font-size: 32rpx;
		line-height: 32rpx;
		font-weight: 500;
	}

	.tui-price__box {
		width: 142rpx;
		padding-left: 16rpx;
		flex-shrink: 0;
		text-align: right;
		overflow: hidden;
		text-overflow: ellipsis;
	}
</style>
