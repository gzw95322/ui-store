<template>
	<tui-list-cell :unlined="unlined" :padding="padding" :backgroundColor="background" :hover="false">
		<view class="tui-goods__item" :style="{height:height+'rpx'}" @tap="detail">
			<image class="tui-goods__img" :style="{width:width+'rpx',height:height+'rpx'}" :src="item.src">
			</image>
			<view class="tui-goods__content">
				<view class="tui-goods__tit">{{item.title}}</view>
				<view class="tui-goods__descr">{{item.specs}}</view>
				<view class="tui-goods__tag">
					<view class="tui-gs__tag" :class="['tui-tag__tj']">特价</view>
					<view class="tui-gs__tag" :class="['tui-tag__24h']">24H发货</view>
				</view>
				<view class="tui-goods__info">
					<view class="tui-pri__box">
						<text class="tui-pri__sign">￥</text>
						<text class="tui-pri__num">{{item.price || '0.00'}}</text>
						<text class="tui-pri__unit">{{item.unit || ''}}</text>
						<text class="tui-pri__original" v-if="item.original">{{item.original}}</text>
					</view>
					<image src="/static/images/common/cart_3x.png" class="tui-add__icon" @tap.stop="addCart"></image>
				</view>
			</view>
		</view>
	</tui-list-cell>
</template>

<script>
	export default {
		name: "t-goods-item",
		props: {
			item: {
				type: Object,
				default () {
					return {}
				}
			},
			background: {
				type: String,
				default: '#fff'
			},
			padding: {
				type: String,
				default: '30rpx'
			},
			width: {
				type: [Number, String],
				default: 200
			},
			height: {
				type: [Number, String],
				default: 200
			},
			unlined: {
				type: Boolean,
				default: true
			}
		},
		data() {
			return {

			};
		},
		methods: {
			detail() {
				this.tui.toast('商品详情页！')
				this.tui.href('/pages/goods/goodsDetail/goodsDetail')
				// this.$emit('click', {})
			},
			addCart() {
				this.tui.toast('加入购物车！')
				// this.$emit('add',{})
			}
		}
	}
</script>

<style scoped>
	.tui-goods__item {
		width: 100%;
		display: flex;
		box-sizing: border-box;
		flex: 1;
	}

	.tui-goods__img {
		margin-right: 30rpx;
		display: block;
	}

	.tui-goods__content {
		flex: 1;
		position: relative;
	}

	.tui-goods__tit {
		width: 100%;
		font-size: 26rpx;
		font-weight: 500;
		color: #333;
		word-break: break-all;
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 2;
		margin-bottom: 12rpx;
	}

	.tui-goods__descr {
		font-size: 27rpx;
		color: #999999;
		zoom: .8;
		margin-bottom: 8rpx;
	}

	.tui-goods__tag {
		display: flex;
		align-items: center;
	}

	.tui-gs__tag {
		padding: 0 4rpx;
		font-size: 25rpx;
		zoom: 0.6;
		margin-right: 8rpx;
		position: relative;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.tui-gs__tag::after {
		content: '';
		position: absolute;
		width: 200%;
		height: 200%;
		border-width: 1px;
		border-style: solid;
		left: 0;
		top: 0;
		transform: scale(.5);
		transform-origin: 0 0;
		border-radius: 4rpx;
		box-sizing: border-box;
	}

	.tui-tag__tj {
		color: #F55726;
	}

	.tui-tag__tj::after {
		border-color: #F55726;
	}

	.tui-tag__24h {
		color: #40AE36;
	}

	.tui-tag__24h::after {
		border-color: #40AE36;
	}

	.tui-goods__info {
		width: 100%;
		min-height: 44rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
		position: absolute;
		left: 0;
		bottom: 0;
	}

	.tui-pri__sign {
		font-size: 24rpx;
		line-height: 24rpx;
		color: #F55726;
	}

	.tui-pri__num {
		font-size: 32rpx;
		line-height: 32rpx;
		font-weight: 500;
		color: #F55726;
	}

	.tui-pri__unit {
		font-size: 24rpx;
		line-height: 24rpx;
		color: #999999;
	}

	.tui-pri__original {
		font-size: 24rpx;
		line-height: 24rpx;
		color: #CCCCCC;
		text-decoration: line-through;
		padding-left: 12rpx;
	}

	.tui-add__icon {
		width: 44rpx;
		height: 44rpx;
		display: block;
		/* #ifdef H5 */
		cursor: pointer;
		/* #endif */
	}
</style>
