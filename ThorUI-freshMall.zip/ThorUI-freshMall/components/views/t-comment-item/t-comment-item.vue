<template>
	<view class="tui-comment__box" :style="{background:background,marginTop:marginTop,padding:padding}">
		<image src="/static/images/index/fruits_3x.png" class="tui-avatar"></image>
		<view class="tui-flex__1">
			<view class="tui-flex__between">
				<text class="tui-nickname">金金设计**铺</text>
				<text class="tui-datetime">2021.12.27</text>
			</view>
			<tui-grade :size="10" :score="4" active="#FBA808" :width="12"></tui-grade>
			<view class="tui-cmt__descr">
				入手很多，活动力度很大必须囤起来，橙子很新鲜，水分足，甜度可口，没有酸感，大小很合适。
			</view>
			<view class="tui-cmt__img-box">
				<image src="/static/images/product/cart_orange_3x.png" class="tui-cmt__img" mode="widthFix"></image>
				<image src="/static/images/product/img_orange_cart.png" class="tui-cmt__img" mode="widthFix"></image>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "t-goods-item",
		props: {
			item: {
				type: Object,
				default () {
					return {}
				}
			},
			background: {
				type: String,
				default: '#fff'
			},
			padding: {
				type: String,
				default: '30rpx 20rpx'
			},
			marginTop: {
				type: String,
				default: '0'
			}
		},
		data() {
			return {

			};
		},
		methods: {

		}
	}
</script>

<style scoped>
	.tui-comment__box {
		width: 100%;
		display: flex;
		justify-content: space-between;
		box-sizing: border-box;
		border-radius: 20rpx;
	}

	.tui-avatar {
		width: 60rpx;
		height: 60rpx;
		border-radius: 50%;
		display: block;
	}

	.tui-flex__1 {
		flex: 1;
		padding-left: 20rpx;
		box-sizing: border-box;
	}

	.tui-flex__between {
		width: 100%;
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	.tui-nickname {
		font-size: 26rpx;
		font-weight: 500;
		line-height: 24rpx;
	}

	.tui-datetime {
		font-size: 24rpx;
		line-height: 24rpx;
		color: #999;
	}

	.tui-cmt__descr {
		font-size: 24rpx;
		font-weight: 400;
		color: #666666;
		padding-top: 20rpx;
	}
	.tui-cmt__img-box{
		display: flex;
		flex-wrap: wrap;
	}
	.tui-cmt__img{
		width: 112rpx;
		height: 112rpx;
		border-radius: 20rpx;
		margin-left: 20rpx;
		margin-top: 20rpx;
	}
</style>
