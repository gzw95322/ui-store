<template>
	<view class="tui-container tui-spacing">
		<view class="tui-card__wrap">
			<tui-list-cell unlined @click="href('/pages/my/info/info')">
				<view class="tui-align__center">
					<tui-lazyload-img backgroundColor="transparent" width="80rpx" height="80rpx"
						src="/static/images/set/info_3x.png"></tui-lazyload-img>
					<view class="tui-pl--20">
						<tui-text text="个人信息" :size="30"></tui-text>
						<tui-text padding="8rpx 0 0" block text="头像、昵称、收货地址等" :size="24" type="gray"></tui-text>
					</view>
				</view>
			</tui-list-cell>
		</view>
		<view class="tui-card__wrap">
			<tui-list-cell unlined @click="href('/pages/my/verifyPhoneNo/verifyPhoneNo')">
				<view class="tui-align__center">
					<tui-lazyload-img backgroundColor="transparent" width="80rpx" height="80rpx"
						src="/static/images/set/account_3x.png"></tui-lazyload-img>
					<view class="tui-pl--20">
						<tui-text text="账户与安全" :size="30"></tui-text>
						<tui-text padding="8rpx 0 0" block text="修改手机号" :size="24" type="gray"></tui-text>
					</view>
				</view>
			</tui-list-cell>
		</view>
		<view class="tui-card__wrap">
			<tui-list-cell unlined @click="href('/pages/my/qa/qa')">
				<view class="tui-align__center">
					<tui-lazyload-img backgroundColor="transparent" width="80rpx" height="80rpx"
						src="/static/images/set/qa_3x.png"></tui-lazyload-img>
					<view class="tui-pl--20">
						<tui-text text="常见问题" :size="30"></tui-text>
					</view>
				</view>
			</tui-list-cell>
		</view>
		<view class="tui-spacing">
			<tui-form-button margin="70rpx 0 0" radius="80rpx">退出当前账号</tui-form-button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {
            href(page){
				this.tui.href(page)
			}
		}
	}
</script>

<style>
	.tui-pl--20 {
		padding-left: 20rpx;
	}
</style>
