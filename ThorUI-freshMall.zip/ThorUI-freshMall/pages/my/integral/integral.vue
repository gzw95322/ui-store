<template>
	<view class="tui-container">
		<tui-banner-arc background="linear-gradient(306deg, #40AE36 0%, #7AC158 100%)" :height="384" :percent="150">
			<view class="tui-flex__column tui-pt--88">
				<tui-text lineHeight padding="0 0 0 12rpx" text="50" type="white" :size="72" fontWeight="500">
				</tui-text>
				<tui-text padding="16rpx 0 0" text="我的积分" :size="24" color="#FEFFFE"></tui-text>
				<view class="tui-align__center tui-sign--rule">
					<tui-lazyload-img src="/static/images/my/help.png" width="40rpx" height="40rpx"
						backgroundColor="transparent"></tui-lazyload-img>
					<tui-text padding="0 0 0 8rpx" text="规则" size="24" type="white" @click="show=true"></tui-text>
				</view>
			</view>
		</tui-banner-arc>
		<view class="tui-content__box tui-spacing">
			<view class="tui-card__wrap ">
				<view>
					<tui-text text="已连续签到" fontWeight="600" size="36"></tui-text>
					<tui-text padding="0 0 0 8rpx" :text="`${days}天`" fontWeight="600" size="36" color="#40AE36">
					</tui-text>
				</view>
				<view class="tui-sign--descr tui-sign--scale">
					<tui-text :text="`${isSignIn?'明':'今'}日签到可获得`" size="25"></tui-text>
					<tui-text padding="0 0 0 8rpx" :text="`${score}积分`" color="#40AE36" :size="25"></tui-text>
				</view>
				<view class="tui-flex__between">
					<view class="tui-sign__card-box tui-flex__column" v-for="(item,index) in weekList" :key="index">
						<view class="tui-sign__card tui-flex__column"
							:class="{'tui-sing__card-active':item.isSignIn || (item.isToday && isSignIn)}">
							<tui-icon name="circle-fill"
								:color="item.isSignIn || (item.isToday && isSignIn)?'#40AE36':'#ccc'" unit="rpx"
								size="48">
							</tui-icon>
						</view>
						<view class="tui-week--scale">
							<tui-text size="24" type="gray" :text="item.isToday?'今天':item.week"></tui-text>
						</view>
					</view>
				</view>
			</view>
			<view class="tui-spacing">
				<tui-form-button margin="50rpx 0 0" radius="80rpx" :disabled="isSignIn" @click="signIn">
					{{isSignIn?'今日已签到':'立即签到'}}
				</tui-form-button>
			</view>
			<view class="tui-pt--60">
				<tui-text text="积分明细" fontWeight="600"></tui-text>
				<tui-text padding="0 0 0 12rpx" text="最近30条积分明细" size="24" type="gray"></tui-text>
			</view>
			<view class="tui-card__wrap tui-pd--0" v-for="(item,index) in list" :key="index">
				<tui-list-cell unlined :hover="false">
					<view class="tui-flex__between">
						<view>
							<tui-text block text="签到得积分" size="28"></tui-text>
							<tui-text padding="12rpx 0 0" text="2022.09.09 12:36:15" size="24" type="gray"></tui-text>
						</view>
						<tui-text text="+2" color="#40AE36" size="36"></tui-text>
					</view>
				</tui-list-cell>
			</view>
		</view>
		<view class="tui-safe__area"></view>
		<tui-modal :show="show" shape="circle" padding="30rpx 40rpx" custom>
			<view class="tui-flex__center">
				<tui-text text="积分规则" fontWeight="600" padding="0 0 8rpx"></tui-text>
			</view>
			<tui-text block text="1.按照连续7天的规则，7天为一周期：连续签到的第1、2、3、4、5、6、7天，分别对应积分为1、2、4、8、16、32、64。" size="26" padding="20rpx 0 0"></tui-text>
			<tui-text block text="2.对应积分可按照500:1进行购物抵扣金额。如 积分为500，则可以抵扣金额 ￥1.00。" size="26" padding="20rpx 0 0"></tui-text>
			<view class="tui-modal__btn tui-flex__center">
				<tui-form-button width="280rpx" height="68rpx" radius="40rpx" :size="26" @click="show = false">我知道了
				</tui-form-button>
			</view>
		</tui-modal>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				weekList: [{
					week: '周一',
					date: '',
					isSignIn: true,
					isToday: false
				}, {
					week: '周二',
					date: '',
					isSignIn: false,
					isToday: true
				}, {
					week: '周三',
					date: '',
					isSignIn: false,
					isToday: false
				}, {
					week: '周四',
					date: '',
					isSignIn: false,
					isToday: false
				}, {
					week: '周五',
					date: '',
					isSignIn: false,
					isToday: false
				}, {
					week: '周六',
					date: '',
					isSignIn: false,
					isToday: false
				}, {
					week: '周日',
					date: '',
					isSignIn: false,
					isToday: false
				}],
				isSignIn: false,
				score: 2,
				days: 1,
				list: [1, 1, 1, 1, 1],
				show: false
			}
		},
		onLoad() {
			const index = this.weekList.findIndex(item => item.isToday && item.isSignIn)
			this.isSignIn = index !== -1
		},
		methods: {
			signIn() {
				this.isSignIn = true;
				this.score = 2 * 2
				this.days += 1;
				this.tui.toast('签到成功')
			}
		}
	}
</script>

<style>
	.tui-container {
		padding-bottom: 24rpx;
	}

	.tui-pt--88 {
		padding-top: 88rpx;
		position: relative;
	}

	.tui-sign--rule {
		position: absolute;
		top: 88rpx;
		right: 30rpx;
	}

	.tui-content__box {
		margin-top: -148rpx;
		position: relative;
		z-index: 10;
	}

	.tui-sign__card-box {
		width: 80rpx;
	}

	.tui-sign__card {
		width: 80rpx;
		height: 88rpx;
		background-color: rgba(102, 102, 102, .1);
		flex-shrink: 0;
		border-radius: 8rpx;
		box-sizing: border-box;
	}

	.tui-sing__card-active {
		background-color: rgba(64, 174, 54, .1);
		border: 1rpx solid rgba(64, 174, 54, .2);
	}

	.tui-card__wrap {
		padding: 20rpx;
		box-sizing: border-box;
	}

	.tui-pd--0 {
		padding: 0;
	}

	.tui-sign--descr {
		padding-bottom: 20rpx;
	}

	.tui-sign--scale {
		transform: scale(.8);
		transform-origin: 0 center;
	}

	.tui-week--scale {
		transform: scale(.8);
		transform-origin: center center;
	}

	.tui-pt--60 {
		padding-top: 60rpx;
	}
	.tui-modal__btn {
		padding: 60rpx 0 20rpx;
		box-sizing: border-box;
	}
</style>
