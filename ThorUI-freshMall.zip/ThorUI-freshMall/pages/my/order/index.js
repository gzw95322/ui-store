export default [{
	//订单id
	id: 1,
	//订单号
	orderNo: '',
	//1-待付款 2-待发货 3-待收货 4-待评价 5-已完成 6-已取消
	status: 1,
	//订单时间
	orderTime: '',
	//商品列表
	list: []
},{
	//订单id
	id: 1,
	//订单号
	orderNo: '',
	//1-待付款 2-待发货 3-待收货 4-待评价 5-已完成
	status: 2,
	//订单时间
	orderTime: '',
	//商品列表
	list: []
},{
	//订单id
	id: 1,
	//订单号
	orderNo: '',
	//1-待付款 2-待发货 3-待收货 4-待评价 5-已完成
	status: 3,
	//订单时间
	orderTime: '',
	//商品列表
	list: []
},{
	//订单id
	id: 1,
	//订单号
	orderNo: '',
	//1-待付款 2-待发货 3-待收货 4-待评价 5-已完成
	status: 4,
	//订单时间
	orderTime: '',
	//商品列表
	list: []
},{
	//订单id
	id: 1,
	//订单号
	orderNo: '',
	//1-待付款 2-待发货 3-待收货 4-待评价 5-已完成
	status: 5,
	//订单时间
	orderTime: '',
	//商品列表
	list: []
}]
