<template>
	<view class="tui-container">
		<tui-tab isFixed :top="0" :tabs="tabs" selectedColor="#40AE36" sliderBgColor="#40AE36" @change="change">
		</tui-tab>
		<view class="tui-order--list" :class="{'tui-list--hidden':current!==idx}" v-for="(order,idx) in tabsData"
			:key="order.key" >
			<view class="tui-card__wrap" v-for="(item,index) in order.list" :key="index" @tap="orderDetail(item)">
				<tui-list-cell :hover="false" lineRight>
					<view class="tui-flex__between">
						<tui-text text="2021.12.27 12:23" type="gray" :size="24"></tui-text>
						<tui-text :text="getStatusText(item.status)" :color="getColor(item.status)" :size="24">
						</tui-text>
					</view>
				</tui-list-cell>
				<t-order-item title="生鲜超市"></t-order-item>
				<view class="tui-btn--box tui-spacing">
					<tui-form-button margin="0 0 0 20rpx" width="144rpx" height="60rpx" :size="24"
						background="transparent" borderColor="#999999" color="#333333" radius="30rpx"
						v-if="item.status===1 || item.status===2">
						取消订单</tui-form-button>
					<tui-form-button margin="0 0 0 20rpx" width="144rpx" height="60rpx" :size="24"
						background="transparent" borderColor="#999999" color="#333333" radius="30rpx"
						v-if="item.status===3 || item.status===4 || item.status===5">再来一单</tui-form-button>
					<tui-form-button margin="0 0 0 20rpx" width="144rpx" height="60rpx" :size="24"
						background="transparent" borderColor="#999999" color="#333333" radius="30rpx"
						v-if="item.status===4 || item.status===5" @click="refund">退款/售后</tui-form-button>
					<tui-form-button margin="0 0 0 20rpx" width="144rpx" height="60rpx" :size="24"
						background="transparent" borderColor="#999999" color="#333333" radius="30rpx"
						v-if="item.status===6">删除订单</tui-form-button>
					<tui-form-button margin="0 0 0 20rpx" width="144rpx" height="60rpx" :size="24"
						background="transparent" borderColor="#40AE36" color="#40AE36" radius="30rpx"
						v-if="item.status===1">去支付
					</tui-form-button>
					<tui-form-button margin="0 0 0 20rpx" width="144rpx" height="60rpx" :size="24"
						background="transparent" borderColor="#40AE36" color="#40AE36" radius="30rpx"
						v-if="item.status===2">提醒发货
					</tui-form-button>
					<tui-form-button margin="0 0 0 20rpx" width="144rpx" height="60rpx" :size="24"
						background="transparent" borderColor="#40AE36" color="#40AE36" radius="30rpx"
						v-if="item.status===3">确认收货
					</tui-form-button>
					<tui-form-button margin="0 0 0 20rpx" width="144rpx" height="60rpx" :size="24"
						background="transparent" borderColor="#40AE36" color="#40AE36" radius="30rpx"
						v-if="item.status===4" @click="evaluate">去评价
					</tui-form-button>
				</view>
			</view>
		</view>
		<tui-loadmore v-if="false"></tui-loadmore>
		<view class="tui-safe__area"></view>
		<tui-no-data fixed imgUrl="/static/images/common/icon_no_data.png" v-if="false">抱歉，没有找到订单哦</tui-no-data>
	</view>
</template>

<script>
	import mock from './index.js'
	export default {
		data() {
			return {
				tabs: ['全部', '待付款', '待发货', '待收货', '待评价'],
				tabsData: [],
				current: 0
			}
		},
		onLoad() {
			this.initData()
		},
		methods: {
			getColor(status) {
				let color = '#40AE36';
				if (status === 1) {
					color = '#F55726';
				} else if (status === 5) {
					color = '#999';
				}
				return color;
			},
			getStatusText(status) {
				return ['待付款', '待发货', '待收货', '待评价', '已完成', '已取消'][status - 1]
			},
			getOrderList(current) {
				//此处仅做演示，实际逻辑需自行实现
				let item = this.tabsData[current]
				item.list = current === 0 ? mock : mock.filter(item => item.status === current)
				item.pageIndex++;
			},
			initData() {
				let list = []
				this.tabs.map((item, index) => {
					list.push({
						list: [],
						key: `tab_${index}`,
						pageIndex: 1,
						pullUpOff: false,
						loading: false
					})
				})
				this.tabsData = list
				this.getOrderList(0)
			},
			change(e) {
				this.current = e.index
				const pageIndex = this.tabsData[this.current].pageIndex
				if (pageIndex === 1) {
					this.getOrderList(this.current)
				}
			},
			orderDetail(e){
				console.log(e)
				this.tui.href(`/pages/my/orderDetail/orderDetail?status=${e.status}`)
			},
			evaluate(){
				this.tui.href('/pages/my/evaluate/evaluate')
			},
			refund(){
				this.tui.href('/pages/my/refund/refund')
			}
		},
		onReachBottom() {
			//上拉加载

		}
	}
</script>

<style>
	.tui-container{
		padding-bottom: 24rpx;
	}
	.tui-order--list {
		width: 100%;
		padding: 80rpx 30rpx 0;
		box-sizing: border-box;
	}

	.tui-btn--box {
		width: 100%;
		display: flex;
		justify-content: flex-end;
		padding-top: 8rpx;
		padding-bottom: 30rpx;
	}

	.tui-list--hidden {
		opacity: 0;
		visibility: hidden;
		position: fixed;
		transform: translateX(100%);
	}
</style>
