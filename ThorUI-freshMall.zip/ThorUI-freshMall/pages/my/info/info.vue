<template>
	<view class="tui-container tui-spacing">
		<view class="tui-card__wrap">
			<tui-list-cell lineRight arrow @click="changeAvatar">
				<view class="tui-flex__between tui-pr--30">
					<tui-text text="头像" :size="30"></tui-text>
					<tui-lazyload-img width="80rpx" height="80rpx" radius="50%"
						src="/static/images/product/carrot_3x.png"></tui-lazyload-img>
				</view>
			</tui-list-cell>
			<tui-list-cell lineRight arrow @click="href(1)">
				<view class="tui-flex__between tui-pr--30">
					<tui-text text="昵称" :size="30"></tui-text>
					<tui-text text="ThorUI 模板" :size="30" fontWeight="500"></tui-text>
				</view>
			</tui-list-cell>
			<tui-list-cell lineRight :hover="false">
				<view class="tui-flex__between">
					<tui-text text="联系电话" :size="30"></tui-text>
					<tui-text text="18822229999" textType="mobile" format :size="30" fontWeight="500"></tui-text>
				</view>
			</tui-list-cell>
			<tui-list-cell lineRight arrow unlined radius @click="href(2)">
				<view class="tui-flex__between">
					<tui-text text="收货地址" :size="30"></tui-text>
				</view>
			</tui-list-cell>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {
			changeAvatar() {
				uni.chooseImage({
					count: 1,
					sizeType: ['original', 'compressed'],
					sourceType: ['album', 'camera'],
					success: res => {
						const tempFilePaths = res.tempFilePaths[0];
						this.tui.href('/pages/my/avatar/avatar?src=' + tempFilePaths);
					}
				});
			},
			href(type) {
				const url = type === 1 ? '/pages/my/nickname/nickname' : '/pages/my/address/address'
				this.tui.href(url)
			}
		}
	}
</script>

<style>
	.tui-pr--30 {
		padding-right: 30rpx;
		box-sizing: border-box;
	}
</style>
