<template>
	<view class="tui-container">
		<view class="tui-form">
			<view class="tui-form__title">验证原手机号</view>
			<tui-input :marginTop="68" maxlength="11" placeholder="请输入手机号码" :size="30" padding="32rpx 0" :lineLeft="false"
				v-model="mobile" disabled></tui-input>
			<tui-input maxlength="6" placeholder="请输入手机验证码" :size="30" padding="32rpx 0" :lineLeft="false"
				v-model="code">
				<template v-slot:right>
					<tui-countdown-verify :successVal="successVal" :resetVal="resetVal" borderWidth="0" height="40rpx"
						width="auto" color="#40AE36" @send="send">
					</tui-countdown-verify>
				</template>
			</tui-input>
			
			<view class="tui-btn__box">
				<tui-form-button radius="80rpx" @click="nextStep">下一步</tui-form-button>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				mobile: '188****0099',
				code: '',
				successVal: 0,
				resetVal: 0
			}
		},
		methods: {
			//自行验证手机号码正确性
			send(e) {
				if (!this.mobile || this.mobile.length !== 11) {
					this.tui.toast('手机号码有误！')
					this.resetVal++
				} else {
					this.successVal++
				}
			},
			nextStep() {
				this.tui.href('../modifyPhoneNo/modifyPhoneNo')
			}
		}
	}
</script>
<style>
	@import '@/static/style/login.css';
</style>
