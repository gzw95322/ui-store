<template>
	<view class="tui-container">
		<tui-radio-group>
			<view class="tui-address__outer" v-for="(item,index) in 5" :key="index">
				<tui-label>
					<t-address-item edit @edit="href(index)">
						<view v-if="isSelect" class="tui-ck__item tui-flex__center">
							<tui-radio color="#40AE36"></tui-radio>
						</view>
					</t-address-item>
				</tui-label>
			</view>
		</tui-radio-group>
		<view class="tui-btn__box">
			<tui-form-button radius="80rpx" @click="href">添加新地址</tui-form-button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isSelect: false
			}
		},
		onLoad(options) {
			this.isSelect = options.isSelect == 1 ? true : false
		},
		methods: {
			href() {
				this.tui.href('/pages/my/editAddress/editAddress')
			}
		}
	}
</script>

<style>
	.tui-address__outer {
		width: 100%;
		padding: 0 30rpx;
		box-sizing: border-box;
		margin-top: 20rpx;
	}

	.tui-ck__item {
		padding-right: 20rpx;
		flex-shrink: 0;
	}

	.tui-btn__box {
		width: 100%;
		padding: 70rpx 60rpx;
		box-sizing: border-box;
	}
</style>
