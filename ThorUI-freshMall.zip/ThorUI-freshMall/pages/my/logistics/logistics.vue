<template>
	<view class="tui-container tui-spacing">
		<view class="tui-card__wrap">
			<tui-list-cell :hover="false" unlined>
				<tui-text text="订单编号：" :size="28"></tui-text>
				<tui-text text="9136257866" :size="28" font-weight="500"></tui-text>
			</tui-list-cell>
			<tui-list-cell padding="0 30rpx 26rpx" :hover="false" unlined radius>
				<tui-text text="预计送达：" :size="28"></tui-text>
				<tui-text text="2022.09.09 18:00" :size="28" font-weight="500"></tui-text>
			</tui-list-cell>
		</view>
		<view class="tui-card__wrap tui-order--tracking">
			<tui-time-axis>
				<tui-timeaxis-item backgroundColor="transparent">
					<template v-slot:node>
						<view class="tui-node" style="background:#F55726">
							<tui-icon name="check" color="#fff" :size="14" :bold="true"></tui-icon>
						</view>
					</template>

					<template v-slot:content>
						<view>
							<tui-text padding="0 0 12rpx" text="已签收" fontWeight="600"></tui-text>
							<tui-text block padding="0 0 12rpx" text="您的订单已由本人签收。感谢您在商城购物，欢迎再次光临。" size="28"></tui-text>
							<tui-text text="2019-05-01 16:17:32" type="gray" :size="24"></tui-text>
						</view>
					</template>
				</tui-timeaxis-item>

				<tui-timeaxis-item backgroundColor="transparent">
					<template v-slot:node>
						<view class="tui-node">
							<tui-icon name="people" color="#fff" :size="13"></tui-icon>
						</view>
					</template>
					<template v-slot:content>
						<tui-text padding="0 0 12rpx" text="派送中" fontWeight="600" color="#999"></tui-text>
						<tui-text block padding="0 0 12rpx" text="您的订单正在配送途中（快递员：张三，电话：13822448855，请您耐心等待。" size="28"
							color="#999"></tui-text>
						<tui-text text="2019-05-01 16:17:32" type="gray" :size="24"></tui-text>
					</template>
				</tui-timeaxis-item>

				<tui-timeaxis-item backgroundColor="transparent">
					<template v-slot:node>
						<view class="tui-node">
							<tui-icon name="transport" color="#fff" :size="13"></tui-icon>
						</view>
					</template>
					<template v-slot:content>
						<tui-text padding="0 0 12rpx" text="运输中" fontWeight="600" color="#999"></tui-text>
						<tui-text block padding="0 0 12rpx" text="您的订单已到达XX【北京XX营业部】" size="28" color="#999"></tui-text>
						<tui-text text="2019-05-01 16:17:32" type="gray" :size="24"></tui-text>
					</template>
				</tui-timeaxis-item>

				<tui-timeaxis-item backgroundColor="transparent">
					<template v-slot:node>
						<view class="tui-node-dot"></view>
					</template>

					<template v-slot:content>
						<tui-text block padding="0 0 12rpx" text="您的订单已在XX【北京XX营业部】收货完成" size="28" color="#999">
						</tui-text>
						<tui-text text="2019-05-01 16:17:32" type="gray" :size="24"></tui-text>
					</template>
				</tui-timeaxis-item>

				<tui-timeaxis-item backgroundColor="transparent">
					<template v-slot:node>
						<view class="tui-node-dot"></view>
					</template>
					<template v-slot:content>
						<tui-text block padding="0 0 12rpx" text="您的订单由XXXX送往XX【北京XX营业部】" size="28" color="#999">
						</tui-text>
						<tui-text text="2019-05-01 16:17:32" type="gray" :size="24"></tui-text>
					</template>
				</tui-timeaxis-item>

				<tui-timeaxis-item backgroundColor="transparent">
					<template v-slot:node>
						<view class="tui-node">
							<tui-icon name="home" color="#fff" :size="12"></tui-icon>
						</view>
					</template>
					<template v-slot:content>
						<tui-text padding="0 0 12rpx" text="仓库处理中" fontWeight="600" color="#999"></tui-text>
						<tui-text block padding="0 0 12rpx" text="打包完成" size="28" color="#999"></tui-text>
						<tui-text text="2019-05-01 16:17:32" type="gray" :size="24"></tui-text>
					</template>
				</tui-timeaxis-item>

				<tui-timeaxis-item backgroundColor="transparent">
					<template v-slot:node>
						<view class="tui-node">
							<tui-icon name="order" color="#fff" :size="12"></tui-icon>
						</view>
					</template>
					<template v-slot:content>
						<tui-text padding="0 0 12rpx" text="已下单" fontWeight="600" color="#999"></tui-text>
						<tui-text block padding="0 0 12rpx" text="您提交了订单，请等待商家系统弄确认" size="28" color="#999"></tui-text>
						<tui-text text="2019-05-01 16:17:32" type="gray" :size="24"></tui-text>
					</template>
				</tui-timeaxis-item>

			</tui-time-axis>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		onLoad(options) {}
	}
</script>

<style>
	.tui-container {
		padding-bottom: 64rpx;
	}

	.tui-node {
		height: 44rpx;
		width: 44rpx;
		border-radius: 50%;
		background-color: #ddd;
		display: flex;
		align-items: center;
		justify-content: center;
		color: #fff;
		flex-shrink: 0;
	}

	.tui-node-dot {
		height: 16rpx;
		width: 16rpx;
		background-color: #ddd;
		border-radius: 50%;
		margin-top: 6rpx;
	}

	.tui-order--tracking {
		padding: 30rpx 30rpx 30rpx 40rpx;
		background: #fff;
		box-sizing: border-box;
	}
</style>
