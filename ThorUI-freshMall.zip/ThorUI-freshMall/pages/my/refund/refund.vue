<template>
	<view class="tui-container tui-spacing">
		<view class="tui-card__wrap">
			<t-order-item title="商品信息"></t-order-item>
		</view>
		<view class="tui-card__wrap">
			<tui-input required label="申请类型" value="退货退款" labelSize="28" size="28" :borderBottom="false" disabled></tui-input>
			<tui-list-cell size="32" arrow padding="0" unlined>
				<tui-input required backgroundColor="transparent" :borderBottom="false" label="申请原因"
					placeholder="请选择退款原因" disabled size="28" labelSize="28"></tui-input>
			</tui-list-cell>
			<tui-input required label="退款金额" value="￥28.90" labelSize="28" size="28" :borderBottom="false" disabled></tui-input>
			<tui-input isFillet required label="申请说明" labelSize="28" size="28" placeholder="请填写申请说明" :borderBottom="false"></tui-input>
		</view>
		<view class="tui-btn--box">
			<tui-form-button radius="80rpx">提交申请</tui-form-button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>
.tui-btn--box{
	width: 100%;
	padding: 70rpx 30rpx;
	box-sizing: border-box;
}
</style>
