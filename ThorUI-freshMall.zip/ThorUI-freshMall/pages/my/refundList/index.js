export default [{
	//订单id
	id: 1,
	//订单号
	orderNo: '',
	//1-退款中 2-退款成功 3-退款失败 4-无退款操作
	status: 4,
	//订单时间
	orderTime: '',
	//商品信息
	goods: {}
},{
	//订单id
	id: 1,
	//订单号
	orderNo: '',
	status: 2,
	//订单时间
	orderTime: '',
	//商品信息
	goods: {}
},{
	//订单id
	id: 1,
	//订单号
	orderNo: '',
	status: 3,
	//订单时间
	orderTime: '',
	//商品列表
	goods: {}
},{
	//订单id
	id: 1,
	//订单号
	orderNo: '',
	status: 1,
	//订单时间
	orderTime: '',
	//商品列表
	goods: {}
},{
	//订单id
	id: 1,
	//订单号
	orderNo: '',
	status: 2,
	//订单时间
	orderTime: '',
	//商品列表
	goods: {}
}]
