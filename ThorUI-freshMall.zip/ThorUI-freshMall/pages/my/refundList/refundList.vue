<template>
	<view class="tui-container tui-spacing">
		<view class="tui-card__wrap" v-for="(item,index) in orderList" :key="index" @tap="detail(item.status)">
			<tui-list-cell :hover="false" lineRight>
				<view class="tui-flex__between">
					<tui-text text="2021.12.27 12:23" type="gray" :size="24"></tui-text>
					<tui-text v-if="item.status!==4" :text="getStatusText(item.status)" :color="getColor(item.status)" :size="24">
					</tui-text>
				</view>
			</tui-list-cell>
			<t-order-item title="生鲜超市"></t-order-item>
			<view class="tui-btn--box tui-spacing">
				<tui-form-button margin="0 0 0 20rpx" width="144rpx" height="60rpx" :size="24" background="transparent"
					borderColor="#999999" color="#333333" radius="30rpx" v-if="item.status!==4">查看详情</tui-form-button>
				<tui-form-button margin="0 0 0 20rpx" width="144rpx" height="60rpx" :size="24" background="transparent"
					borderColor="#40AE36" color="#40AE36" radius="30rpx" v-if="item.status===4">申请退款
				</tui-form-button>
				<tui-form-button margin="0 0 0 20rpx" width="144rpx" height="60rpx" :size="24" background="transparent"
					borderColor="#40AE36" color="#40AE36" radius="30rpx" v-if="item.status===1">取消退款
				</tui-form-button>
			</view>
		</view>
		<tui-loadmore v-if="false"></tui-loadmore>
		<view class="tui-safe__area"></view>
		<tui-no-data fixed imgUrl="/static/images/common/icon_no_data.png" v-if="false">抱歉，没有找到订单哦</tui-no-data>
	</view>
</template>

<script>
	import mock from './index.js'
	export default {
		data() {
			return {
				orderList: mock
			}
		},
		onLoad() {

		},
		methods: {
			getColor(status) {
				let color = '#40AE36';
				if (status !== 1) {
					color = '#F55726';
				}
				return color;
			},
			getStatusText(status) {
				return ['退款中', '退款成功', '退款失败'][status - 1]
			},
			detail(status){
				this.tui.href(`/pages/my/refundDetail/refundDetail?status=${status}`)
			}
		},
		onReachBottom() {
			//上拉加载

		}
	}
</script>

<style>
	.tui-container {
		padding-bottom: 24rpx;
	}

	.tui-btn--box {
		width: 100%;
		display: flex;
		justify-content: flex-end;
		padding-top: 8rpx;
		padding-bottom: 30rpx;
	}
</style>
