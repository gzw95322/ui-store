<template>
	<view class="tui-container">
		<tui-list-cell unlined :hover="false">
			<view class="tui-align__center tui-header">
				<tui-lazyload-img width="80rpx" height="80rpx" src="/static/images/product/cart_orange_3x.png">
				</tui-lazyload-img>
				<tui-text padding="0 0 0 20rpx" text="四川眉山 爱媛38号果冻橙礼盒装" :size="26"></tui-text>
			</view>
		</tui-list-cell>
		<view class="tui-spacing">
			<view class="tui-card__wrap">
				<tui-list-cell :hover="false" unlined>
					<tui-text padding="0 0 20rpx" text="评分" block :size="28"></tui-text>
					<tui-grade :score="score" :isHalf="false" :width="28" active="#FBA808" @change="change"></tui-grade>
					<tui-text padding="50rpx 0 20rpx" text="评价" block :size="28"></tui-text>
					<tui-textarea placeholder="对评价进行补充，更客观，更全面~" textareaBorder isCounter></tui-textarea>
					<tui-text padding="50rpx 0 20rpx" text="图片" block :size="28"></tui-text>
					<tui-upload width="180" height="180" iconSize="18"></tui-upload>
				</tui-list-cell>
			</view>
			<view class="tui-btn__box">
				<tui-form-button radius="80rpx">提交评价</tui-form-button>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				score: 0
			}
		},
		methods: {
			change: function(e) {
				console.log(e);
				this.score = e.score;
			}
		}
	}
</script>

<style>
.tui-container{
	padding-bottom: 64rpx;
}
.tui-btn__box{
	width: 100%;
	padding: 70rpx 30rpx 30rpx;
	box-sizing: border-box;
}
</style>
