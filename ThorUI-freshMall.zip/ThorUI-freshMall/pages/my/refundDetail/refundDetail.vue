<template>
	<view class="tui-container">
		<tui-banner-arc background="linear-gradient(306deg, #40AE36 0%, #7AC158 100%)" :height="384" :percent="150">
			<view class="tui-flex__center tui-pt--88">
				<tui-lazyload-img width="48rpx" height="48rpx" backgroundColor="transparent"
					:src="`/static/images/order/${getStatusIcon(status)}.png`"></tui-lazyload-img>
				<tui-text lineHeight padding="0 0 0 12rpx" :text="getStatusText(status)" type="white" :size="36"
					fontWeight="600">
				</tui-text>
			</view>
			<view class="tui-flex__center tui-pt--16">
				<tui-text :text="getStatusDescr(status)" :size="24" color="#FEFFFE"></tui-text>
			</view>
		</tui-banner-arc>
		<view class="tui-content__box tui-spacing">
			<view class="tui-card__wrap">
				<tui-list-cell unlined radius :hover="false">
					<view class="tui-align__center">
						<tui-lazyload-img width="44rpx" height="44rpx" backgroundColor="transparent"
							src="/static/images/order/location.png"></tui-lazyload-img>
						<view class="tui-cell--pd">
							<tui-text text="北京市海淀区恒大新宏福苑西区20号楼2单元301" :size="30" fontWeight="500"></tui-text>
							<tui-text padding="8rpx 0 0" block text="金金 15800000000" type="gray" :size="24"></tui-text>
						</view>
					</view>
				</tui-list-cell>
			</view>
			<view class="tui-card__wrap">
				<t-order-item title="生鲜超市"></t-order-item>
			</view>
			<view class="tui-card__wrap">
				<tui-list-cell padding="26rpx 30rpx 0" :hover="false" unlined>
					<view class="tui-flex__between">
						<tui-text text="商品小计" :size="24" color="#666"></tui-text>
						<tui-text text="￥38.80" font-weight="500"></tui-text>
					</view>
				</tui-list-cell>
				<tui-list-cell padding="26rpx 30rpx 0" :hover="false" unlined>
					<view class="tui-flex__between">
						<tui-text text="优惠券" :size="24" color="#666"></tui-text>
						<tui-text text="-￥7.00" :size="24"></tui-text>
					</view>
				</tui-list-cell>
				<tui-list-cell :hover="false">
					<view class="tui-flex__between">
						<tui-text text="积分" :size="24" color="#666"></tui-text>
						<tui-text text="-￥0.00" :size="24"></tui-text>
					</view>
				</tui-list-cell>
				<tui-list-cell :hover="false" unlined radius>
					<view class="tui-flex__between">
						<tui-text text="应退款金额合计" :size="24" fontWeight="500"></tui-text>
						<tui-text text="￥31.80" color="#F55726" fontWeight="500"></tui-text>
					</view>
				</tui-list-cell>
			</view>

			<view class="tui-card__wrap">
				<tui-list-cell padding="26rpx 30rpx 0" :hover="false" unlined>
					<view class="tui-flex__between">
						<tui-text text="售后类型" :size="24" color="#666"></tui-text>
						<tui-text text="退货退款" :size="24" font-weight="500"></tui-text>
					</view>
				</tui-list-cell>
				<tui-list-cell padding="26rpx 30rpx 0" radius :hover="false" unlined>
					<view class="tui-flex__between">
						<tui-text text="付款方式" :size="24" color="#666"></tui-text>
						<tui-text text="支付宝" :size="24" font-weight="500"></tui-text>
					</view>
				</tui-list-cell>
				<tui-list-cell padding="26rpx 30rpx 0" radius :hover="false" unlined>
					<view class="tui-flex__between">
						<tui-text text="退款编号" :size="24" color="#666"></tui-text>
						<tui-text text="390000122222229" :size="24" font-weight="500"></tui-text>
					</view>
				</tui-list-cell>
				<tui-list-cell padding="26rpx 30rpx 0" radius :hover="false" unlined>
					<view class="tui-flex__between">
						<tui-text text="退款原因" :size="24" color="#666"></tui-text>
						<tui-text text="不想要了" :size="24" font-weight="500"></tui-text>
					</view>
				</tui-list-cell>
				<tui-list-cell padding="26rpx 30rpx 0" radius :hover="false" unlined>
					<view class="tui-flex__between">
						<tui-text text="订单编号" :size="24" color="#666"></tui-text>
						<tui-text text="899999888999999" :size="24" font-weight="500"></tui-text>
					</view>
				</tui-list-cell>
				<tui-list-cell padding="26rpx 30rpx 0" radius :hover="false" unlined>
					<view class="tui-flex__between">
						<tui-text text="申请时间" :size="24" color="#666"></tui-text>
						<tui-text text="2022.09.09 12:12:20" :size="24" font-weight="500"></tui-text>
					</view>
				</tui-list-cell>
				<tui-list-cell radius :hover="false" unlined>
					<view class="tui-flex__between">
						<view class="tui-flex--shrink">
							<tui-text text="申请说明" :size="24" color="#666"></tui-text>
						</view>
						<tui-text padding="0 0 0 40rpx" text="重新购买~" :size="24" font-weight="500"></tui-text>
					</view>
				</tui-list-cell>
				
			</view>
		</view>
		<view class="tui-safe__area"></view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				status: 1
			}
		},
		onLoad(options) {
			this.status = Number(options.status || 1)
		},
		methods: {
			getStatusText(status) {
				return ['退款中', '退款成功', '退款失败'][status - 1]
			},
			getStatusIcon(status) {
				return ['wait', 'complete', 'cancel'][status - 1]
			},
			getStatusDescr(status) {
				return [
					'请耐心等待，24小时内处理退款',
					'退款原路退回 2022.09.09 15:20',
					'该商品不支持退货退款'
				][status - 1]
			}
		}
	}
</script>

<style>
	.tui-container {
		padding-bottom: 24rpx;
	}

	.tui-pt--88 {
		padding-top: 88rpx;
	}

	.tui-pt--16 {
		padding-top: 16rpx;
	}

	.tui-content__box {
		margin-top: -148rpx;
		position: relative;
		z-index: 10;
	}

	.tui-cell--pd {
		flex: 1;
		padding-left: 20rpx;
		padding-right: 40rpx;
		box-sizing: border-box;
	}
	.tui-flex--shrink{
		flex-shrink: 0;
	}
</style>
