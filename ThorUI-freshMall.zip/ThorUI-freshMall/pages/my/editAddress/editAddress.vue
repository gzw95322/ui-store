<template>
	<view class="tui-container">
		<view class="tui-form__box">
			<tui-input :labelSize="30" :size="30" label="收货人" placeholder="请输入姓名"></tui-input>
			<tui-input :labelSize="30" :size="30" label="手机号码" placeholder="请输入手机号码"></tui-input>
			<tui-input  v-model="result" :labelSize="30" :size="30" label="所在城市" placeholder="请选择城市" disabled @click="pickerCity">
				<template v-slot:right>
					<view class="tui-arrow"></view>
				</template>
			</tui-input>
			<tui-input :labelSize="30" :size="30" label="详细地址" placeholder="请输入详细收货地址"></tui-input>
			<tui-list-cell padding="20rpx 30rpx" :hover="false" unlined>
				<view class="tui-flex__between">
					<text class="tui-size--28">默认地址</text>
					<tui-switch color="#40AE36" scaleRatio=".8"></tui-switch>
				</view>
			</tui-list-cell>
		</view>
		<view class="tui-form__box tui-outer__box">
			<tui-data-checkbox :width="138" :options="addrTypes" background="#F8F9FA" activeBgColor="#F8F9FA"
				borderColor="#F8F9FA" activeColor="#40AE36"></tui-data-checkbox>
		</view>
		<view class="tui-btn__box">
			<tui-form-button radius="80rpx">提交</tui-form-button>
		</view>
		<tui-picker confirmColor="#40AE36" :value="value" :layer="3" :show="show" :pickerData="cityData" @hide="hide" @change="change">
		</tui-picker>
	</view>
</template>

<script>
	import cityData from './picker.city.min.js'
	export default {
		data() {
			return {
				addrTypes: ['公司', '家', '父母家', '其他'],
				cityData,
				// value: ['河北省','唐山市','路北区'],
				value: [],
				show:false,
				result:''
			}
		},
		methods: {
			change(e) {
				console.log(e)
				this.result=e.result
			},
			pickerCity() {
				this.show = true
			},
			hide() {
				this.show = false
			}
		}
	}
</script>

<style>
	.tui-container {
		width: 100%;
		padding: 20rpx 30rpx;
		box-sizing: border-box;
	}

	.tui-form__box {
		width: 100%;
		border-radius: 20rpx;
		overflow: hidden;
		background: #fff;
		margin-bottom: 20rpx;
	}
    .tui-arrow{
		position: relative;
		padding-left: 20rpx;
		flex-shrink: 0;
	}
	.tui-arrow::after {
		content: ' ';
		height: 10px;
		width: 10px;
		border-width: 2px 2px 0 0;
		border-color: #c0c0c0;
		border-style: solid;
		-webkit-transform: matrix(0.5, 0.5, -0.5, 0.5, 0, 0);
		transform: matrix(0.5, 0.5, -0.5, 0.5, 0, 0);
		position: absolute;
		top: 50%;
		margin-top: -6px;
		right: 0;
	}

	.tui-btn__box {
		width: 100%;
		padding: 50rpx 60rpx;
		box-sizing: border-box;
	}

	.tui-size--28 {
		font-size: 28rpx;
	}

	.tui-outer__box {
		padding: 30rpx;
		box-sizing: border-box;
	}
</style>
