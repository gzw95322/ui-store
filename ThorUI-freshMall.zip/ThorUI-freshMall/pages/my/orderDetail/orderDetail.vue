<template>
	<view class="tui-container">
		<tui-banner-arc background="linear-gradient(306deg, #40AE36 0%, #7AC158 100%)" height="384" :percent="150">
			<view class="tui-flex__center tui-pt--88">
				<tui-lazyload-img width="48rpx" height="48rpx" backgroundColor="transparent"
					:src="`/static/images/order/${getStatusIcon(status)}.png`"></tui-lazyload-img>
				<tui-text lineHeight padding="0 0 0 12rpx" :text="getStatusText(status)" type="white" :size="36"
					fontWeight="600">
				</tui-text>
			</view>
			<view class="tui-flex__center tui-pt--16">
				<tui-text text="9" :size="24" color="#FEFFFE" v-if="status===1"></tui-text>
				<tui-text :text="getStatusDescr(status)" :size="24" color="#FEFFFE"></tui-text>
			</view>
		</tui-banner-arc>
		<view class="tui-content__box tui-spacing">
			<view class="tui-card__wrap">
				<tui-list-cell arrow unlined radius v-if="status>1">
					<view class="tui-align__center">
						<tui-lazyload-img width="44rpx" height="44rpx" backgroundColor="transparent"
							src="/static/images/order/transport.png"></tui-lazyload-img>
						<view class="tui-cell--pd">
							<tui-text text="[北京市] [北京综合邮件处理中心]，已发下一站" :size="24"></tui-text>
							<tui-text padding="8rpx 0 0" block text="2021.12.28 10:31:11" type="gray" :size="24">
							</tui-text>
						</view>
					</view>
				</tui-list-cell>
				<tui-list-cell unlined radius :hover="false">
					<view class="tui-align__center">
						<tui-lazyload-img width="44rpx" height="44rpx" backgroundColor="transparent"
							src="/static/images/order/location.png"></tui-lazyload-img>
						<view class="tui-cell--pd">
							<tui-text text="北京市海淀区恒大新宏福苑西区20号楼2单元301" :size="30" fontWeight="500"></tui-text>
							<tui-text padding="8rpx 0 0" block text="金金 15800000000" type="gray" :size="24"></tui-text>
						</view>
					</view>
				</tui-list-cell>
			</view>
			<view class="tui-card__wrap">
				<t-order-item title="生鲜超市"></t-order-item>
			</view>
			<view class="tui-card__wrap">
				<tui-list-cell padding="26rpx 30rpx 0" :hover="false" unlined>
					<view class="tui-flex__between">
						<tui-text text="商品小计" :size="24" color="#666"></tui-text>
						<tui-text text="￥38.80" font-weight="500"></tui-text>
					</view>
				</tui-list-cell>
				<tui-list-cell padding="26rpx 30rpx 0" :hover="false" unlined>
					<view class="tui-flex__between">
						<tui-text text="优惠券" :size="24" color="#666"></tui-text>
						<tui-text text="-￥7.00" :size="24"></tui-text>
					</view>
				</tui-list-cell>
				<tui-list-cell :hover="false">
					<view class="tui-flex__between">
						<tui-text text="积分" :size="24" color="#666"></tui-text>
						<tui-text text="-￥0.00" :size="24"></tui-text>
					</view>
				</tui-list-cell>
				<tui-list-cell :hover="false" unlined radius>
					<view class="tui-flex__between">
						<tui-text text="应付金额合计" :size="24" fontWeight="500"></tui-text>
						<tui-text text="￥31.80" color="#F55726" fontWeight="500"></tui-text>
					</view>
				</tui-list-cell>
			</view>

			<view class="tui-card__wrap">
				<tui-list-cell padding="26rpx 30rpx 0" :hover="false" unlined>
					<view class="tui-flex__between">
						<tui-text text="下单时间" :size="24" color="#666"></tui-text>
						<tui-text text="2021.12.27 12:22:35" :size="24" font-weight="500"></tui-text>
					</view>
				</tui-list-cell>
				<tui-list-cell :padding="status===1 || status===6?'26rpx 30rpx 0':'26rpx 30rpx'" radius :hover="false" unlined>
					<view class="tui-flex__between">
						<tui-text text="订单编号" :size="24" color="#666"></tui-text>
						<tui-text text="98988898989" :size="24" font-weight="500"></tui-text>
					</view>
				</tui-list-cell>
				<tui-list-cell v-if="status!==1 && status!==6" padding="26rpx 30rpx 0" :hover="false" unlined>
					<view class="tui-flex__between">
						<tui-text text="支付方式" :size="24" color="#666"></tui-text>
						<tui-text text="支付宝" :size="24" font-weight="500"></tui-text>
					</view>
				</tui-list-cell>
				<tui-list-cell v-if="status!==1 && status!==6" :hover="false" unlined radius>
					<view class="tui-flex__between">
						<tui-text text="支付流水号" :size="24" color="#666"></tui-text>
						<tui-text text="181881818192929299290" :size="24" font-weight="500"></tui-text>
					</view>
				</tui-list-cell>
			</view>
		</view>
		<view class="tui-safe__area"></view>
		<view class="tui-order__bar tui-top__line">
			<view class="tui-btn--box tui-spacing">
				<tui-form-button margin="0 0 0 20rpx" width="144rpx" height="60rpx" :size="24" background="transparent"
					borderColor="#999999" color="#333333" radius="30rpx" v-if="status===1 || status===2">
					取消订单</tui-form-button>
				<tui-form-button margin="0 0 0 20rpx" width="144rpx" height="60rpx" :size="24" background="transparent"
					borderColor="#999999" color="#333333" radius="30rpx" v-if="status===3 || status===4 || status===5">
					再来一单</tui-form-button>
				<tui-form-button margin="0 0 0 20rpx" width="144rpx" height="60rpx" :size="24" background="transparent"
					borderColor="#999999" color="#333333" radius="30rpx" v-if="status===4 || status===5" @click="refund">退款/售后
				</tui-form-button>
				<tui-form-button margin="0 0 0 20rpx" width="144rpx" height="60rpx" :size="24" background="transparent"
					borderColor="#999999" color="#333333" radius="30rpx" v-if="status===6">删除订单</tui-form-button>
				<tui-form-button margin="0 0 0 20rpx" width="144rpx" height="60rpx" :size="24" background="transparent"
					borderColor="#40AE36" color="#40AE36" radius="30rpx" v-if="status===1">去支付
				</tui-form-button>
				<tui-form-button margin="0 0 0 20rpx" width="144rpx" height="60rpx" :size="24" background="transparent"
					borderColor="#40AE36" color="#40AE36" radius="30rpx" v-if="status===2">提醒发货
				</tui-form-button>
				<tui-form-button margin="0 0 0 20rpx" width="144rpx" height="60rpx" :size="24" background="transparent"
					borderColor="#40AE36" color="#40AE36" radius="30rpx" v-if="status===3">确认收货
				</tui-form-button>
				<tui-form-button margin="0 0 0 20rpx" width="144rpx" height="60rpx" :size="24" background="transparent"
					borderColor="#40AE36" color="#40AE36" radius="30rpx" v-if="status===4" @click="evaluate">去评价
				</tui-form-button>
			</view>
			<view class="tui-safe__area"></view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				status: 1
			}
		},
		onLoad(options) {
			this.status = Number(options.status || 1)
		},
		methods: {
			getStatusText(status) {
				return ['待付款', '待发货', '待收货', '已完成', '已完成', '已取消'][status - 1]
			},
			getStatusIcon(status) {
				return ['wait', 'sendout', 'receive', 'complete', 'complete', 'cancel'][status - 1]
			},
			getStatusDescr(status) {
				return [
					'分钟后订单关闭，请及时付款哦',
					'已付款，等待上架发货',
					'已发货，等待收货',
					'订单已完成',
					'订单已完成',
					'订单已取消',
				][status - 1]
			},
			evaluate(){
				this.tui.href('/pages/my/evaluate/evaluate')
			},
			refund(){
				this.tui.href('/pages/my/refund/refund')
			}
		}
	}
</script>

<style>
	.tui-container {
		padding-bottom: 124rpx;
	}

	.tui-pt--88 {
		padding-top: 88rpx;
	}

	.tui-pt--16 {
		padding-top: 16rpx;
	}

	.tui-content__box {
		margin-top: -148rpx;
		position: relative;
		z-index: 10;
	}

	.tui-cell--pd {
		flex: 1;
		padding-left: 20rpx;
		padding-right: 40rpx;
		box-sizing: border-box;
	}

	.tui-order__bar {
		position: fixed;
		bottom: 0;
		left: 0;
		right: 0;
		z-index: 11;
		background: #fff;
	}

	.tui-btn--box {
		width: 100%;
		height: 100rpx;
		display: flex;
		justify-content: flex-end;
		align-items: center;
	}
</style>
