<template>
	<view class="tui-container tui-spacing">
		<view class="tui-card__wrap">
			<tui-list-cell unlined radius arrow @click="contacts">
				<view class="tui-align__center">
					<tui-lazyload-img backgroundColor="transparent" width="32rpx" height="32rpx"
						src="/static/images/common/tel_3x.png"></tui-lazyload-img>
					<tui-text padding="0 0 0 20rpx" text="联系客服" :size="28" fontWeight="500"></tui-text>
				</view>
			</tui-list-cell>
		</view>
		<tui-text padding="60rpx 0 0" text="常见问题" :size="28" fontWeight="500"></tui-text>
		<view class="tui-card__wrap" v-for="(item,index) in list" :key="index">
			<tui-list-cell unlined radius :hover="false">
				<view class="tui-flex__between" @tap="toggle(index)">
					<tui-text padding="0 30rpx 0 0" :text="item.question" :size="28" fontWeight="500"></tui-text>
					<view class="tui-qa__item" :class="{'tui-qa__show':item.show}">
						<tui-icon name="arrowdown" unit="rpx" :size="40" color="#666666"></tui-icon>
					</view>
				</view>
				<tui-text v-if="item.show" padding="30rpx 0 0" :text="item.answer" size="28"></tui-text>
			</tui-list-cell>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: [{
					question: '我们的服务流程是什么？',
					show: true,
					answer: '我们的服务流程是什么我们的服务流程是什么我们的服务流程是什么我们的服务流程是什么我们的服务流程是什么我们的服务流程是什么我们的服务流程是什么'
				}, {
					question: '运费是如何计算的？',
					show: false,
					answer: '运费是如何计算的运费是如何计算的运费是如何计算的运费是如何计算的运费是如何计算的'
				}, {
					question: '哪里可以获取发票？',
					show: false,
					answer: '哪里可以获取发票哪里可以获取发票哪里可以获取发票哪里可以获取发票哪里可以获取发票'
				}]
			}
		},
		methods: {
			toggle(index) {
				const item = this.list[index]
				item.show = !item.show
			},
			contacts() {
				uni.makePhoneCall({
					phoneNumber: '18899990000'
				})
			}
		}
	}
</script>

<style>
	.tui-container {
		padding-bottom: 64rpx;
	}

	.tui-qa__item {
		transition: all .2s;
	}

	.tui-qa__show {
		transform: rotate(180deg);
	}
</style>
