<template>
	<view class="tui-container">
		<t-waterfall>
			<t-waterfall-item v-for="(item,idx) in productList" :key="idx" :item="item" :index="idx" @click="detail">
			</t-waterfall-item>
		</t-waterfall>
		<tui-no-data imgUrl="/static/images/common/icon_no_data.png" v-if="false">抱歉，您还没有浏览商品哦</tui-no-data>
	</view>
</template>

<script>
	import data from './index.js'
	export default {
		data() {
			return {
				productList: data.productList
			}
		},
		methods: {
			detail(){
				this.tui.href('/pages/goods/goodsDetail/goodsDetail')
			}
		}
	}
</script>

<style>
.tui-container{
	padding: 20rpx 0 48rpx;
}
</style>
