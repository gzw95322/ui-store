<template>
	<view class="tui-container tui-spacing">
		<view class="tui-card__wrap">
			<tui-input placeholder="请输入昵称" :borderBottom="false" clearable></tui-input>
		</view>
		<view class="tui-btn--box tui-spacing">
			<tui-form-button radius="80rpx">保存</tui-form-button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>
.tui-btn--box{
	padding-top: 70rpx;
}
</style>
