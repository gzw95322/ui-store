<template>
	<view class="tui-container tui-spacing">
		<view class="tui-card__wrap" v-for="(item,index) in list" :key="index">
			<view class="tui-flex__between">
				<view class="tui-coupon--left tui-flex__column">
					<view>
						<tui-text text="￥" color="#999" fontWeight="500"></tui-text>
						<tui-text text="5" color="#999" size="64" fontWeight="500"></tui-text>
					</view>
					<tui-text padding="8rpx 0 0" :text="index%2===0?'无门槛':'满100可用'" size="24" color="#999">
					</tui-text>
				</view>
				<view class="tui-coupon--right tui-flex-1">
					<tui-text text="水果品类新人专享券" fontWeight="500"></tui-text>
					<tui-text padding="4rpx 0 0" block text="有效期至 2022.09.22" size="24" type="gray"></tui-text>
					<view class="tui-instructions">
						<tui-text block text="部分商品可用" size="24" type="gray"></tui-text>
						<tui-text lineHeight :text="index%2===0?'可叠加':'不可叠加'" color="#999" size="24"></tui-text>
					</view>
					<view class="tui-btn--box">
						<tui-form-button width="148rpx" height="56rpx" radius="40rpx" size="24"
							borderColor="transparent" background="#bfbfbf" disabled>{{index%2===0?'已使用':'已过期'}}</tui-form-button>
					</view>
				</view>
			</view>
		</view>
		<view class="tui-safe__area"></view>
		<!-- 无数据时显示 -->
		<tui-no-data v-if="false" imgUrl="/static/images/common/icon_no_data.png" imgHeight="auto">
			<tui-text text="暂无优惠券~" type="gray" size="24"></tui-text>
		</tui-no-data>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: [1, 2, 3, 4, 5]
			}
		},
		methods: {
			
		}
	}
</script>

<style>
	.tui-container {
		padding-bottom: 48rpx;
	}

	.tui-coupon--left {
		width: 200rpx;
		height: 200rpx;
		background: #eee;
		flex-shrink: 0;
	}

	.tui-coupon--right {
		padding: 0 20rpx;
		box-sizing: border-box;
		position: relative;
	}

	.tui-instructions {
		padding-top: 8rpx;
		transform: scale(.8);
		transform-origin: 0 100%;
	}

	.tui-btn--box {
		position: absolute;
		right: 20rpx;
		bottom: 16rpx;
	}
</style>
