<template>
	<view class="tui-container">
		<view class="tui-logo--box tui-flex__column">
			<tui-lazyload-img src="/static/images/product/cabbage_3x.png" width="240rpx" height="240rpx" backgroundColor="transparent"></tui-lazyload-img>
			<tui-text padding="20rpx 0 0" text="ThorUI模板生鲜商城" :size="44" color="#40AE36"></tui-text>
		</view>
		<view class="tui-spacing">
			<view class="tui-card__wrap">
				<tui-list-cell arrow @click="href">隐私政策</tui-list-cell>
				<tui-list-cell radius unlined :hover="false">当前版本：1.0.0</tui-list-cell>
			</view>
		</view>
		<tui-footer copyright="Copyright © 2022 ThorUI All Rights Reserved." backgroundColor="transparent"></tui-footer>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			href(){
				this.tui.href('/pages/common/protocol/protocol')
			}
		}
	}
</script>

<style>
.tui-logo--box{
	width: 100%;
	padding: 30rpx 0;
	background-color: #fff;
}
</style>
