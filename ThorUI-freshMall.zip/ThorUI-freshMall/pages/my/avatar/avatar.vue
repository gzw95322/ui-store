<template>
	<view class="container">
		<tui-picture-cropper :lockRatio="true" :imageUrl="imageUrl" @ready="ready" @cropper="cropper"></tui-picture-cropper>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				src: '',
				imageUrl: '',
				isRound:true
			};
		},
		onLoad(options) {
			this.src = options.src || '';
			this.src &&
				uni.showLoading({
					title: '请稍候...',
					mask: true
				});
		},
		methods: {
			ready() {
				this.imageUrl = this.src;
			},
			cropper(e) {
				//裁剪后图片
				console.log(e.url)
			}
		}
	};
</script>