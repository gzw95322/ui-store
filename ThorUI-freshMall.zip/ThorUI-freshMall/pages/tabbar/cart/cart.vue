<template>
	<view class="tui-container">
		<view class="tui-cart__box">
			<tui-checkbox-group>
				<view class="tui-cart__list">
					<tui-list-cell :hover="false" padding="20rpx 30rpx" :lineLeft="false">
						<view class="tui-flex__between">
							<text class="tui-size--24">共2件商品</text>
							<tui-button width="116rpx" height="48rpx" shape="circle" plain type="gray" :size="24">编辑
							</tui-button>
						</view>
					</tui-list-cell>
					<tui-slide-view v-for="(item,index) in 2" :key="index">
						<view class="tui-cart__item">
							<view class="tui-ck--box">
								<tui-checkbox color="#40AE36"></tui-checkbox>
							</view>
							<image class="tui-cart__img" src="/static/images/product/crab_3x.png">
							</image>
							<view class="tui-cart__content">
								<view class="tui-cart__tit">鲜活 江苏洪泽湖南大闸蟹3对(母215-235g，公290-310g)</view>
								<view class="tui-cart__tag">
									<view class="tui-gs__tag" :class="['tui-tag__tj']">特价</view>
									<view class="tui-gs__tag" :class="['tui-tag__24h']">24H发货</view>
								</view>
								<view class="tui-cart__info">
									<view class="tui-pri__box">
										<text class="tui-pri__sign">￥</text>
										<text class="tui-pri__num">39.9</text>
									</view>
									<tui-numberbox backgroundColor="#fff" color="#333" iconBgColor="#F8F9FA"
										iconColor="#333">
									</tui-numberbox>
								</view>
							</view>
						</view>
					</tui-slide-view>
				</view>
			</tui-checkbox-group>
		</view>
		<view class="tui-rec__box tui-flex__center">
			<image class="tui-rec__img" src="/static/images/common/tit_3x.png" mode="widthFix"></image>
		</view>
		<t-waterfall>
			<t-waterfall-item v-for="(item,idx) in productList" :key="idx" :item="item" :index="idx" @click="detail">
			</t-waterfall-item>
		</t-waterfall>
		<view class="tui-safe__area"></view>
		<t-goods-bar mainPage @click="submitOrder"></t-goods-bar>
	</view>
</template>

<script>
	import mock from './index.js'
	export default {
		data() {
			return {
				productList: mock.productList
			}
		},
		methods: {
			detail() {
				this.tui.href('/pages/goods/goodsDetail/goodsDetail')
			},
			submitOrder(){
				this.tui.href('/pages/goods/submitOrder/submitOrder')
			}
		}
	}
</script>

<style>
	.tui-container {
		padding-bottom: 100rpx;
	}

	.tui-cart__box {
		width: 100%;
		padding: 20rpx 30rpx;
		box-sizing: border-box;
	}

	.tui-cart__list {
		width: 100%;
		background: #FFFFFF;
		border-radius: 24rpx;
		overflow: hidden;
	}

	.tui-cart__item {
		width: 100%;
		display: flex;
		box-sizing: border-box;
		background: #fff;
		padding: 24rpx 30rpx;
		border-radius: 24rpx;
	}

	.tui-ck--box {
		height: 188rpx;
		display: flex;
		align-items: center;
		flex-shrink: 0;
		padding-right: 20rpx;
	}

	.tui-cart__img {
		width: 188rpx;
		height: 188rpx;
		margin-right: 30rpx;
		display: block;
	}

	.tui-cart__content {
		flex: 1;
		position: relative;
	}

	.tui-cart__tit {
		width: 100%;
		font-size: 26rpx;
		font-weight: 500;
		color: #333;
		word-break: break-all;
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 2;
		margin-bottom: 12rpx;
	}

	.tui-cart__tag {
		display: flex;
		align-items: center;
	}

	.tui-gs__tag {
		padding: 0 4rpx;
		font-size: 25rpx;
		zoom: 0.6;
		margin-right: 8rpx;
		position: relative;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.tui-gs__tag::after {
		content: '';
		position: absolute;
		width: 200%;
		height: 200%;
		border-width: 1px;
		border-style: solid;
		left: 0;
		top: 0;
		transform: scale(.5);
		transform-origin: 0 0;
		border-radius: 4rpx;
		box-sizing: border-box;
	}

	.tui-tag__tj {
		color: #F55726;
	}

	.tui-tag__tj::after {
		border-color: #F55726;
	}

	.tui-tag__24h {
		color: #40AE36;
	}

	.tui-tag__24h::after {
		border-color: #40AE36;
	}

	.tui-cart__info {
		width: 100%;
		min-height: 44rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
		position: absolute;
		left: 0;
		bottom: 0;
	}

	.tui-pri__sign {
		font-size: 24rpx;
		line-height: 24rpx;
		color: #F55726;
	}

	.tui-pri__num {
		font-size: 32rpx;
		line-height: 32rpx;
		font-weight: 500;
		color: #F55726;
	}

	.tui-size--24 {
		font-size: 24rpx;
	}

	.tui-rec__box {
		width: 100%;
		padding-top: 50rpx;
		padding-bottom: 30rpx;
	}

	.tui-rec__img {
		width: 258rpx;
		height: 42rpx;
	}
</style>
