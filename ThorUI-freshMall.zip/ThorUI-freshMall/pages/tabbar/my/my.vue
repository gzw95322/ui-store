<template>
	<view class="tui-container">
		<tui-banner-arc background="linear-gradient(306deg, #40AE36 0%, #7AC158 100%)" :height="height" :percent="150">
			<!-- #ifndef H5 -->
			<tui-status-bar></tui-status-bar>
			<!-- #endif -->
			<view class="tui-align__between tui-spacing">
				<view class="tui-align__center" @tap="href(1)">
					<tui-lazyload-img width="120rpx" height="120rpx" radius="50%"
						src="/static/images/product/carrot_3x.png"></tui-lazyload-img>
					<view class="tui-pl--30">
						<tui-text type="white" block text="ThorUI模板"></tui-text>
						<tui-text color="#f8f8f8" :size="24" textType="mobile" format text="15188888888"></tui-text>
					</view>
				</view>
				<view class="tui-pt--26">
					<image class="tui-header__icon" src="/static/images/my/set_3x.png"  @tap="href(2)"></image>
					<image class="tui-header__icon" src="/static/images/my/kefu_3x.png" @tap="contacts"></image>
				</view>
			</view>
			<view class="tui-flex__between tui-spacing">
				<view class="tui-flex__column tui-flex-1"  @tap="href(3)">
					<tui-text type="white" text="50" fontWeight="500" :size="36"></tui-text>
					<tui-text padding="4rpx 0 0" color="rgba(255,255,255,.8)" text="优惠券" :size="24" block></tui-text>
				</view>
				<view class="tui-flex__column tui-flex-1"  @tap="href(4)">
					<tui-text type="white" text="50" fontWeight="500" :size="36"></tui-text>
					<tui-text padding="4rpx 0 0" color="rgba(255,255,255,.8)" text="积分" :size="24" block></tui-text>
				</view>
				<view class="tui-flex__column tui-flex-1"  @tap="href(5)">
					<tui-text type="white" text="6" fontWeight="500" :size="36"></tui-text>
					<tui-text padding="4rpx 0 0" color="rgba(255,255,255,.8)" text="收藏夹" :size="24" block></tui-text>
				</view>
				<view class="tui-flex__column tui-flex-1"  @tap="href(6)">
					<tui-text type="white" text="50" fontWeight="500" :size="36"></tui-text>
					<tui-text padding="4rpx 0 0" color="rgba(255,255,255,.8)" text="足迹" :size="24" block></tui-text>
				</view>
			</view>
		</tui-banner-arc>
		<view class="tui-spacing tui-content__top">
			<view class="tui-cart__box">
				<tui-list-cell arrow unlined :hover="false" @click="href(7)">
					<view class="tui-flex__between tui-pr--30">
						<tui-text fontWeight="bold" size="28" text="我的订单"></tui-text>
						<tui-text text="全部订单" :size="24" type="gray"></tui-text>
					</view>
				</tui-list-cell>
				<view class="tui-flex__between tui-card__pd">
					<view class="tui-flex__column tui-flex-1"  @tap="href(7)">
						<view class="tui-icon__box">
							<image class="tui-icon" src="/static/images/my/paid_3x.png"></image>
							<tui-badge absolute type="warning" :scaleRatio="0.8" translateX="12rpx">1</tui-badge>
						</view>
						<tui-text text="待付款" :size="24" color="#666"></tui-text>
					</view>
					<view class="tui-flex__column tui-flex-1"  @tap="href(7)">
						<view class="tui-icon__box">
							<image class="tui-icon" src="/static/images/my/shipped_3x.png"></image>
							<tui-badge absolute type="warning" :scaleRatio="0.8" translateX="12rpx" v-if="false">1
							</tui-badge>
						</view>
						<tui-text text="待发货" :size="24" color="#666"></tui-text>
					</view>
					<view class="tui-flex__column tui-flex-1"  @tap="href(7)">
						<view class="tui-icon__box">
							<image class="tui-icon" src="/static/images/my/received_3x.png"></image>
							<tui-badge absolute type="warning" :scaleRatio="0.8" translateX="12rpx" v-if="false">1
							</tui-badge>
						</view>
						<tui-text text="待收货" :size="24" color="#666"></tui-text>
					</view>
					<view class="tui-flex__column tui-flex-1"  @tap="href(7)">
						<view class="tui-icon__box">
							<image class="tui-icon" src="/static/images/my/evaluated_3x.png"></image>
							<tui-badge absolute type="warning" :scaleRatio="0.8" translateX="12rpx">2</tui-badge>
						</view>
						<tui-text text="待评价" :size="24" color="#666"></tui-text>
					</view>
					<view class="tui-flex__column tui-flex-1"  @tap="href(8)">
						<image class="tui-icon" src="/static/images/my/refund_3x.png"></image>
						<tui-text text="退款/售后" :size="24" color="#666"></tui-text>
					</view>
				</view>
			</view>
			<view class="tui-cart__box tui-mt--24">
				<tui-list-cell unlined :hover="false">
					<view class="tui-flex__between">
						<tui-text fontWeight="bold" size="28" text="我的服务"></tui-text>
					</view>
				</tui-list-cell>
				<view class="tui-flex__between tui-card__pd">
					<view class="tui-flex__column tui-flex-1" @tap="href(9)">
						<image class="tui-icon" src="/static/images/my/address_3x.png"></image>
						<tui-text text="收货地址" :size="24" color="#666"></tui-text>
					</view>
					<view class="tui-flex__column tui-flex-1"  @tap="href(6)">
						<image class="tui-icon" src="/static/images/my/footprint_3x.png"></image>
						<tui-text text="足迹" :size="24" color="#666"></tui-text>
					</view>
					<view class="tui-flex__column tui-flex-1"  @tap="href(5)">
						<image class="tui-icon" src="/static/images/my/collection_3x.png"></image>
						<tui-text text="我的收藏" :size="24" color="#666"></tui-text>
					</view>
					<view class="tui-flex__column tui-flex-1"  @tap="href(10)">
						<image class="tui-icon" src="/static/images/my/Invoice_3x.png"></image>
						<tui-text text="关于我们" :size="24" color="#666"></tui-text>
					</view>
					<view class="tui-flex__column tui-flex-1" @tap="contacts">
						<image class="tui-icon" src="/static/images/my/service_3x.png"></image>
						<tui-text text="联系客服" :size="24" color="#666"></tui-text>
					</view>
				</view>
			</view>
		</view>
		<view class="tui-rec__box tui-flex__center">
			<image class="tui-rec__img" src="/static/images/common/tit_3x.png" mode="widthFix"></image>
		</view>
		<t-waterfall>
			<t-waterfall-item v-for="(item,idx) in productList" :key="idx" :item="item" :index="idx" @click="detail">
			</t-waterfall-item>
		</t-waterfall>
	</view>
</template>

<script>
	import mock from './index.js'
	export default {
		data() {
			let height = 560
			// #ifdef H5
			height = 480
			// #endif
			return {
				height,
				productList: mock.productList
			}
		},
		methods: {
			href(type) {
				let page = ''
				switch (type) {
					case 1:
						page = '/pages/my/info/info';
						break;
					case 2:
						page = '/pages/my/setup/setup';
						break;
					case 3:
						page = '/pages/my/myCoupon/myCoupon';
						break;
					case 4:
						page = '/pages/my/integral/integral';
						break;
					case 5:
						page = '/pages/my/collection/collection';
						break;
					case 6:
						page = '/pages/my/footprint/footprint';
						break;
					case 7:
						page = '/pages/my/order/order';
						break;
					case 8:
						page = '/pages/my/refundList/refundList';
						break;
					case 9:
						page = '/pages/my/address/address';
						break;
					case 10:
						page = '/pages/my/aboutUs/aboutUs';
						break;
					default:
						break;
				}
				page && this.tui.href(page)
			},
			contacts(){
				uni.makePhoneCall({
					phoneNumber:'18899990000'
				})
			},
			detail(){
				this.tui.href('/pages/goods/goodsDetail/goodsDetail')
			}
		}
	}
</script>

<style>
	.tui-spacing {
		padding-top: 40rpx;
	}

	.tui-header__icon {
		width: 48rpx;
		height: 48rpx;
		margin-left: 30rpx;
	}

	/* #ifdef MP */
	.tui-pt--26 {
		padding-top: 26px;
	}

	/* #endif */
	.tui-content__top {
		padding-top: 0;
		margin-top: -160rpx;
		position: relative;
		z-index: 10;
	}

	.tui-cart__box {
		width: 100%;
		background: #FFFFFF;
		border-radius: 24rpx;
		overflow: hidden;
	}

	.tui-icon__box {
		position: relative;
	}

	.tui-icon {
		width: 70rpx;
		height: 70rpx;
		margin-bottom: 4rpx;
		display: block;
	}

	.tui-card__pd {
		padding: 16rpx 0 40rpx;
	}

	.tui-mt--24 {
		margin-top: 24rpx;
	}

	.tui-rec__box {
		width: 100%;
		padding-top: 50rpx;
		padding-bottom: 30rpx;
	}

	.tui-rec__img {
		width: 258rpx;
		height: 42rpx;
	}
</style>
