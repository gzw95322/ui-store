const productList = [{
	src: '/static/images/product/spinach_3x.png',
	title: '彩食鲜菠菜 270g/份',
	price: '12.8',
	unit: '/份'
}, {
	src: '/static/images/product/orange_3x.png',
	title: '四川爱媛38号可吸果冻橙 1kg/份',
	price: '39.9',
	unit: '/箱'
}, {
	src: '/static/images/product/carrot_3x.png',
	title: '云南昆明 有机水果胡萝卜 1.5kg/份',
	price: '38.8',
	unit: '/箱'
}, {
	src: '/static/images/product/img_walnut_3x.png',
	title: '云南香格里拉 野生山核桃 原味150g*6',
	price: '39.9',
	unit: '/箱'
}, {
	src: '/static/images/product/img_spinach_3x.png',
	title: '彩食鲜菠菜 270g/份',
	price: '12.8',
	unit: '/份'
}, {
	src: '/static/images/product/spinach_3x.png',
	title: '彩食鲜菠菜 270g/份',
	price: '12.8',
	unit: '/份'
}, {
	src: '/static/images/product/orange_3x.png',
	title: '四川爱媛38号可吸果冻橙 1kg/份',
	price: '39.9',
	unit: '/箱'
}, {
	src: '/static/images/product/carrot_3x.png',
	title: '云南昆明 有机水果胡萝卜 1.5kg/份',
	price: '38.8',
	unit: '/箱'
}, {
	src: '/static/images/product/img_walnut_3x.png',
	title: '云南香格里拉 野生山核桃 原味150g*6',
	price: '39.9',
	unit: '/箱'
}, {
	src: '/static/images/product/img_spinach_3x.png',
	title: '彩食鲜菠菜 270g/份',
	price: '12.8',
	unit: '/份'
}]

export default {
	productList
}