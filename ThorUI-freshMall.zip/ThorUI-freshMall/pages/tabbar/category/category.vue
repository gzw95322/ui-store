<template>
	<view class="tui-container">
		<tui-navigation-bar backgroundColor="#F8F9FA" :isOpacity="false" @init="initNavigation">
			<view class="tui-header tui-align__center" :class="['tui-header-pl']" :style="{width:left+'px'}">
				<!-- #ifndef H5 || MP-ALIPAY || MP-BAIDU -->
				<tui-icon name="arrowleft" unit="rpx" :size="64" color="#333"></tui-icon>
				<!-- #endif -->
				<tui-searchbar padding="0" height="32px" placeholder="吃出没好生活" disabled></tui-searchbar>
				<view class="tui-cart__box tui-active" @tap="toCart">
					<image class="tui-cart__icon" src="/static/images/cart/cart_3x.png" mode="widthFix"></image>
					<tui-badge absolute type="warning" :scaleRatio="0.8" translateX="12rpx">1</tui-badge>
				</view>
			</view>
		</tui-navigation-bar>
		<scroll-view scroll-x>
			<view :class="{'tui-category__wrap':menus.length<6}" :style="{paddingTop:height+'px'}">
				<view :class="[menus.length>5?'tui-flex':'tui-flex__between']">
					<view class="tui-item__box"
						:class="{'tui-item__active':activeIndex===index,'tui-item__box-scroll':menus.length>5}"
						@tap="menuChange(index)" v-for="(item,index) in menus" :key="index">
						<image class="tui-item__img" :src="`/static/images/index/${item.src}`"></image>
						<view class="tui-item__text">{{item.text}}</view>
					</view>
				</view>
			</view>
		</scroll-view>
		<scroll-view :scroll-into-view="scrollInto" scroll-y scroll-with-animation scroll-anchoring
			class="tui-tab__view" :style="{ top: top + 'px' }">
			<view :id="'tid_'+index" v-for="(item, index) in tabbar" :key="index" class="tui-tab__item tui-flex__center"
				:class="[currentTab == index ? 'tui-tab__active' : '']" @tap.stop="swichNav(index)">{{ item.name }}
			</view>
		</scroll-view>
		<scroll-view scroll-y scroll-anchoring class="tui-content__view" :style="{ top: top + 'px' }">
			<view class="tui-goods__view">
				<t-goods-item v-for="(item,index) in dataList" :key="index" :item="item"></t-goods-item>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	import data from './index.js'
	export default {
		data() {
			return {
				//大分类索引
				activeIndex: 0,
				menus: data.menus,
				height: 44,
				left: 240,
				scrollH: 0,
				top: 0,
				tabbar: data.tabbar,
				currentTab: 0,
				dataList: data.dataList,
				scrollInto: ''
			}
		},
		onShow() {
			this.activeIndex = Number(uni.getStorageSync('category') || 0)
		},
		methods: {
			getScrollH(height) {
				//32+20+118+8+36
				let _header = uni.upx2px(214) + height
				this.top = _header
			},
			initNavigation(e) {
				this.height = e.height
				this.left = e.left
				this.getScrollH(e.height)
			},
			toCart() {
				uni.switchTab({
					url: '/pages/tabbar/cart/cart'
				})
			},
			menuChange(index) {
				if (this.activeIndex === index) return;
				this.activeIndex = index
				//获取分类列表数据
				//...
			},
			swichNav(index) {
				if (this.currentTab === index) return;
				this.currentTab = index;
				this.scrollInto = `tid_${index - 1 < 0 ? 0 : index - 1}`;
				//获取分类数据
				//...
			}
		}
	}
</script>

<style>
	page,
	.tui-container {
		height: 100%;
	}

	.tui-header {
		width: 100%;
		height: 44px;
		padding: 0 30rpx 0 12rpx;
		box-sizing: border-box;
	}

	/*#ifdef H5*/
	.tui-header-pl {
		padding-left: 30rpx;
	}

	/* #endif */

	/*#ifdef MP-ALIPAY || MP-BAIDU */
	.tui-header-pl {
		padding-left: 80rpx;
	}

	/* #endif */

	.tui-category__wrap {
		width: 100%;
		padding: 0 30rpx;
		box-sizing: border-box;
	}

	.tui-cart__box {
		position: relative;
		width: 48rpx;
		height: 48rpx;
		margin-left: 24rpx;
	}

	.tui-cart__icon {
		width: 48rpx;
		height: 48rpx;
		display: block;
	}

	.tui-item__box {
		display: flex;
		align-items: center;
		justify-content: center;
		flex-direction: column;
		padding: 32rpx 0 20rpx;
	}

	.tui-item__box-scroll {
		width: 148rpx;
		flex-shrink: 0;
	}


	.tui-item__img {
		width: 108rpx;
		height: 108rpx;
		display: block;
		border: 1px solid transparent;
		border-radius: 50%;
		box-sizing: border-box;
	}

	.tui-item__text {
		font-size: 24rpx;
		line-height: 24rpx;
		color: #666666;
		height: 36rpx;
		display: flex;
		align-items: center;
		justify-content: center;
		margin-top: 8rpx;
		padding: 0 8rpx;
	}

	.tui-item__active .tui-item__img {
		border: 1px solid var(--tui-primary);
	}

	.tui-item__active .tui-item__text {
		background-color: var(--tui-primary);
		border-radius: 20rpx;
		color: #fff;
		box-sizing: border-box;
	}

	.tui-tab__view {
		width: 180rpx;
		position: absolute;
		left: 0;
		bottom: 0;
		z-index: 10;
	}

	.tui-tab__item {
		width: 180rpx;
		height: 110rpx;
		font-size: 26rpx;
		color: #666666;
		/* #ifdef H5
		cursor: pointer;
		/* #endif */
	}

	.tui-tab__active {
		color: var(--tui-primary);
		font-weight: 500;
		background-color: #fff;
	}

	.tui-content__view {
		position: absolute;
		right: 0;
		left: 180rpx;
		bottom: 0;
		z-index: 10;
		background-color: #fff;
	}

	.tui-goods__view {
		max-width: 570rpx;
	}
</style>
