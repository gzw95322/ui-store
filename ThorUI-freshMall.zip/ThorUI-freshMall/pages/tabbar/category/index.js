const menus = [{
	src: 'fruits_3x.png',
	text: '水果蔬菜'
}, {
	src: 'meat_egg_3x.png',
	text: '肉禽蛋品'
}, {
	src: 'seafood_3x.png',
	text: '海鲜水产'
}, {
	src: 'fast_food_3x.png',
	text: '速食冷冻'
}, {
	src: 'oil_3x.png',
	text: '粮油米面'
}]

const tabbar = [{
	id: 1,
	name: '好货推荐'
}, {
	id: 2,
	name: '热带水果'
}, {
	id: 3,
	name: '樱桃莓类'
}, {
	id: 4,
	name: '柑橘橙柚'
}, {
	id: 5,
	name: '苹果梨蕉'
}, {
	id: 6,
	name: '奇异果'
}, {
	id: 7,
	name: '瓜类葡萄'
}, {
	id: 8,
	name: '茄果'
}, {
	id: 9,
	name: '菌菇'
}, {
	id: 10,
	name: '葱姜蒜'
}]

const dataList=[{
	src:'/static/images/product/cart_orange_3x.png',
	title:'四川爱媛38号可吸果冻橙',
	specs:'有机食品 | 水果',
	price:'39.9',
	unit:'/箱'
},{
	src:'/static/images/product/img_orange_cart.png',
	title:'四川眉山 爱媛38号可吸果冻橙礼盒装12粒(单果180g+)',
	specs:'有机食品 | 水果',
	price:'12.8',
	unit:'/份'
},{
	src:'/static/images/product/cart_orange_3x.png',
	title:'四川爱媛38号可吸果冻橙',
	specs:'有机食品 | 水果',
	price:'39.9',
	unit:'/箱'
},{
	src:'/static/images/product/img_orange_cart.png',
	title:'四川眉山 爱媛38号可吸果冻橙礼盒装12粒(单果180g+)',
	specs:'有机食品 | 水果',
	price:'12.8',
	unit:'/份'
},{
	src:'/static/images/product/cart_orange_3x.png',
	title:'四川爱媛38号可吸果冻橙',
	specs:'有机食品 | 水果',
	price:'39.9',
	unit:'/箱'
},{
	src:'/static/images/product/img_orange_cart.png',
	title:'四川眉山 爱媛38号可吸果冻橙礼盒装12粒(单果180g+)',
	specs:'有机食品 | 水果',
	price:'12.8',
	unit:'/份'
},{
	src:'/static/images/product/cart_orange_3x.png',
	title:'四川爱媛38号可吸果冻橙',
	specs:'有机食品 | 水果',
	price:'39.9',
	unit:'/箱'
},{
	src:'/static/images/product/img_orange_cart.png',
	title:'四川眉山 爱媛38号可吸果冻橙礼盒装12粒(单果180g+)',
	specs:'有机食品 | 水果',
	price:'12.8',
	unit:'/份'
}]

export default {
	menus: menus,
	tabbar: tabbar,
	dataList:dataList
}
