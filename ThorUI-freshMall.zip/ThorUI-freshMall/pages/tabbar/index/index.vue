<template>
	<view class="tui-container">
		<tui-navigation-bar backgroundColor="#40AE36" :isOpacity="false" @init="initNavigation">
			<view class="tui-header__location tui-align__center tui-active" @tap="href(1)">
				<image src="/static/images/index/position_3x.png" class="tui-location__icon" mode="widthFix"></image>
				<view class="tui-location__text" :style="{maxWidth:left-80+'px'}">海淀区中关村大厦</view>
				<view class="tui-turningdown"></view>
			</view>
		</tui-navigation-bar>
		<view class="tui-content" :style="{marginTop:height+'px'}">
			<tui-searchbar inputBgColor="#EDEFF2" disabled @click="search"></tui-searchbar>
			<view class="tui-spacing">
				<view class="tui-banner__box">
					<image class="tui-banner" src="/static/images/index/banner_3x.png"></image>
				</view>
				<view class="tui-flex__between">
					<view class="tui-item__box tui-active" v-for="(item,index) in menus" :key="index" @tap="classify(index)">
						<image class="tui-item__img" :src="`/static/images/index/${item.src}`"></image>
						<text class="tui-item__text">{{item.text}}</text>
					</view>
				</view>
				<view class="tui-affordable__box">
					<view class="tui-flex__between">
						<view class="tui-flex tui-ad__box">
							<text class="tui-ad__text">超划算</text>
							<view class="tui-ad__tag">冬日礼遇</view>
						</view>
						<view class="tui-more__text tui-active" @tap="classify(0)">查看全部</view>
					</view>
					<view class="tui-ad__list tui-flex__between">
						<view class="tui-ad__list-item" v-for="(item,index) in affordable" :key="index" @tap="detail">
							<view class="tui-ad__img-box">
								<image class="tui-ad__img" :src="`/static/images/product/${item.src}`"></image>
							</view>
							<view class="tui-ad__title">{{item.title}}</view>
							<view class="tui-flex__between tui-top__16">
								<view class="tui-ad__price">
									<text class="tui-ad__sign">￥</text>
									<text class="tui-ad__num">{{item.price}}</text>
								</view>
								<image src="/static/images/common/cart_3x.png" class="tui-ad__add" @tap.stop=""></image>
							</view>
						</view>
					</view>
				</view>

				<view class="tui-recommend__box tui-flex__between">
					<view class="tui-recommend__item">
						<view class="tui-rec__tit">吃好点</view>
						<view class="tui-rec__sub">美国小木瓜尝鲜</view>
						<view class="tui-rec__img-box tui-flex__between">
							<image class="tui-rec__img" src="/static/images/product/cauliflower_3x.png" @tap="detail"></image>
							<image class="tui-rec__img" src="/static/images/product/avocado_3x.png" @tap="detail"></image>
						</view>
					</view>
					<view class="tui-recommend__item tui-ml20">
						<view class="tui-rec__tit">产地量贩</view>
						<view class="tui-rec__sub">核桃19.9元/箱</view>
						<view class="tui-rec__img-box tui-flex__between">
							<image class="tui-rec__img" src="/static/images/product/img_walnut_3x.png" @tap="detail"></image>
							<image class="tui-rec__img" src="/static/images/product/crab_3x.png" @tap="detail"></image>
						</view>
					</view>
				</view>
			</view>
			<view class="tui-product__menu tui-flex__between">
				<view class="tui-pd__menu-item"
					:class="{'tui-split__line':index!==0,'tui-menu__active':typeIndex===index}"
					v-for="(item,index) in category" :key="index" @tap="changeCategory(index)">
					<view class="tui-menu__tit">{{item.title}}</view>
					<view class="tui-menu__descr">{{item.descr}}</view>
				</view>
			</view>
			<t-waterfall>
				<t-waterfall-item v-for="(item,idx) in productList" :key="idx" :item="item" :index="idx" @click="detail">
				</t-waterfall-item>
			</t-waterfall>
		</view>
	</view>
</template>

<script>
	import data from './index.js'
	export default {
		data() {
			return {
				height: 44,
				left: 240,
				menus: data.menus,
				affordable: data.affordable,
				category: data.category,
				typeIndex: 0,
				productList: data.productList
			}
		},
		onLoad() {

		},
		methods: {
			initNavigation(e) {
				this.height = e.height
				this.left = e.left
			},
			search(e) {
				this.tui.href('/pages/index/search/search')
			},
			changeCategory(index) {
				this.typeIndex = index
				//...
			},
			href(type) {
				let page='/pages/index/location/location'
				page && this.tui.href(page)
			},
			detail() {
				this.tui.href('/pages/goods/goodsDetail/goodsDetail')
			},
			classify(type){
				uni.setStorageSync('category',type)
				uni.switchTab({
					url:'/pages/tabbar/category/category'
				})
			}
		}
	}
</script>

<style>
	.tui-container {
		padding-bottom: 40rpx;
	}

	.tui-header__location {
		width: 100%;
		height: 44px;
		padding: 0 30rpx;
		box-sizing: border-box;
	}

	.tui-location__icon {
		width: 48rpx;
		height: 48rpx;
		flex-shrink: 0;
	}

	.tui-location__text {
		font-size: 30rpx;
		line-height: 30rpx;
		color: #fff;
		padding: 0 12rpx 0 8rpx;
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
	}

	.tui-turningdown {
		width: 0;
		height: 0;
		border: 8rpx solid;
		border-color: #fff transparent transparent transparent;
		margin-top: 8rpx;
	}

	.tui-banner__box,
	.tui-banner {
		width: 100%;
		height: 240rpx;
	}

	.tui-item__box {
		display: flex;
		align-items: center;
		justify-content: center;
		flex-direction: column;
		padding: 40rpx 0;
	}

	.tui-item__img {
		width: 108rpx;
		height: 108rpx;
		display: block;
	}

	.tui-item__text {
		font-size: 24rpx;
		color: #666666;
		padding-top: 12rpx;
	}

	.tui-affordable__box {
		width: 100%;
		padding: 30rpx;
		box-sizing: border-box;
		background: #FFFFFF;
		border-radius: 20rpx;
	}

	.tui-ad__box {
		align-items: flex-end;
	}

	.tui-ad__text {
		font-size: 30rpx;
		line-height: 30rpx;
		font-weight: 500;
	}

	.tui-ad__tag {
		background: #EC9F09;
		border-radius: 4rpx;
		padding: 0 4rpx;
		font-size: 25rpx;
		color: #fff;
		zoom: 0.6;
		margin-left: 12rpx;
	}

	.tui-more__text {
		font-size: 24rpx;
		line-height: 24rpx;
		color: var(--tui-primary);
		padding: 4rpx 0;
	}

	.tui-ad__list {
		padding-top: 20rpx;
	}

	.tui-ad__list-item {
		width: 176rpx;
	}

	.tui-ad__img-box,
	.tui-ad__img {
		width: 176rpx;
		height: 176rpx;
		display: block;
	}

	.tui-ad__title {
		width: 100%;
		font-size: 24rpx;
		color: #666666;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
		margin-top: 16rpx;
	}

	.tui-ad__price {
		color: var(--tui-warning);
	}

	.tui-ad__sign {
		font-size: 24rpx;
		line-height: 24rpx;
	}

	.tui-ad__num {
		font-size: 32rpx;
		line-height: 32rpx;
		font-weight: 500;
	}

	.tui-ad__add {
		width: 44rpx;
		height: 44rpx;
		flex-shrink: 0;
	}

	.tui-top__16 {
		margin-top: 16rpx;
	}

	.tui-recommend__box {
		padding-top: 20rpx;
	}

	.tui-recommend__item {
		background: #fff;
		border-radius: 20rpx;
		flex: 1;
		padding: 20rpx 30rpx 12rpx;
		box-sizing: border-box;
	}

	.tui-ml20 {
		margin-left: 20rpx;
	}

	.tui-rec__tit {
		font-size: 30rpx;
		font-weight: 500;
	}

	.tui-rec__sub {
		font-size: 24rpx;
		color: #999999;
	}

	.tui-rec__img-box {
		width: 100%;
		padding-top: 20rpx;
	}

	.tui-rec__img {
		width: 120rpx;
		height: 120rpx;
	}

	.tui-product__menu {
		padding: 40rpx 0 30rpx 0;
	}

	.tui-pd__menu-item {
		display: flex;
		align-items: center;
		justify-content: center;
		flex-direction: column;
		flex: 1;
		position: relative;
		/* #ifdef H5 */
		cursor: pointer;
		/* #endif */
	}

	.tui-split__line::after {
		content: '';
		position: absolute;
		left: 0;
		top: 24%;
		bottom: 24%;
		width: 1px;
		background: #ECECEC;
		transform: scaleX(0.5) translateZ(0);
	}

	.tui-menu__tit {
		font-size: 30rpx;
		font-weight: 500;
		text-align: center;
		padding-bottom: 4rpx;
	}

	.tui-menu__descr {
		font-size: 25rpx;
		color: #999;
		text-align: center;
		padding: 0 8rpx;
		border-radius: 40rpx;
		zoom: .8;
	}

	.tui-menu__active .tui-menu__tit {
		color: var(--tui-primary);
	}

	.tui-menu__active .tui-menu__descr {
		background: var(--tui-primary);
		color: #fff;
	}
</style>
