const menus = [{
	src: 'fruits_3x.png',
	text: '水果蔬菜'
}, {
	src: 'meat_egg_3x.png',
	text: '肉禽蛋品'
}, {
	src: 'seafood_3x.png',
	text: '海鲜水产'
}, {
	src: 'fast_food_3x.png',
	text: '速食冷冻'
}, {
	src: 'oil_3x.png',
	text: '粮油米面'
}]

//超划算
const affordable = [{
	src: 'cart_orange_3x.png',
	title: '四川爱媛38号甜橙子超大个',
	price: '39.9'
}, {
	src: 'meat_3x.png',
	title: '山养黄牛腱子肉',
	price: '68.8'
}, {
	src: 'cabbage_3x.png',
	title: '有机水果卷心菜',
	price: '16.5'
}]

const category = [{
	title: '全部',
	descr: '猜你喜欢'
}, {
	title: '时令',
	descr: '当季优选'
}, {
	title: '进口',
	descr: '国际直采'
}, {
	title: '人气',
	descr: '大家在买'
}]

const productList = [{
	src: '/static/images/product/spinach_3x.png',
	title: '彩食鲜菠菜 270g/份',
	price: '12.8',
	unit: '/份'
}, {
	src: '/static/images/product/orange_3x.png',
	title: '四川爱媛38号可吸果冻橙 1kg/份',
	price: '39.9',
	unit: '/箱'
}, {
	src: '/static/images/product/carrot_3x.png',
	title: '云南昆明 有机水果胡萝卜 1.5kg/份',
	price: '38.8',
	unit: '/箱'
}, {
	src: '/static/images/product/img_walnut_3x.png',
	title: '云南香格里拉 野生山核桃 原味150g*6',
	price: '39.9',
	unit: '/箱'
}, {
	src: '/static/images/product/img_spinach_3x.png',
	title: '彩食鲜菠菜 270g/份',
	price: '12.8',
	unit: '/份'
}, {
	src: '/static/images/product/spinach_3x.png',
	title: '彩食鲜菠菜 270g/份',
	price: '12.8',
	unit: '/份'
}, {
	src: '/static/images/product/orange_3x.png',
	title: '四川爱媛38号可吸果冻橙 1kg/份',
	price: '39.9',
	unit: '/箱'
}, {
	src: '/static/images/product/carrot_3x.png',
	title: '云南昆明 有机水果胡萝卜 1.5kg/份',
	price: '38.8',
	unit: '/箱'
}, {
	src: '/static/images/product/img_walnut_3x.png',
	title: '云南香格里拉 野生山核桃 原味150g*6',
	price: '39.9',
	unit: '/箱'
}, {
	src: '/static/images/product/img_spinach_3x.png',
	title: '彩食鲜菠菜 270g/份',
	price: '12.8',
	unit: '/份'
}]


export default {
	menus: menus,
	affordable: affordable,
	category: category,
	productList:productList
}
