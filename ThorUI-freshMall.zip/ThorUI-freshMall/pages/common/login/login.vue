<template>
	<view class="tui-container">
		<view class="tui-form">
			<view class="tui-form__title">手机号码登录</view>
			<tui-input clearable maxlength="11" placeholder="请输入手机号码" :size="30" padding="32rpx 0" :lineLeft="false"
				:marginTop="68" v-model="mobile"></tui-input>
			<tui-input maxlength="6" placeholder="请输入手机验证码" :size="30" padding="48rpx 0 32rpx" :lineLeft="false"
				v-model="code">
				<template v-slot:right>
					<tui-countdown-verify height="40rpx" :successVal="successVal" :resetVal="resetVal" borderWidth="0"
						width="auto" color="#40AE36" @send="send">
					</tui-countdown-verify>
				</template>
			</tui-input>
			<view class="tui-flex">
				<view class="tui-link__text tui-active" @tap="reg">新用户注册</view>
			</view>
			<view class="tui-btn__box">
				<tui-form-button radius="80rpx" @click="login">登录</tui-form-button>
			</view>
		</view>
		<view class="tui-third__box">
			<tui-divider width="50%" backgroundColor="#fff">其他登录方式</tui-divider>
			<view class="tui-third__inner tui-flex__between">
				<tui-icon unit="rpx" :size="98" name="wechat" color="#07c160"></tui-icon>
				<tui-icon unit="rpx" :size="98" name="sina" color="#F65A3C"></tui-icon>
				<tui-icon unit="rpx" :size="90" name="qq" color="#3AB5F8"></tui-icon>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				mobile: '',
				code: '',
				successVal: 0,
				resetVal: 0
			}
		},
		methods: {
			//自行验证手机号码正确性
			send(e) {
				if (!this.mobile || this.mobile.length !== 11) {
					this.tui.toast('手机号码有误！')
					this.resetVal++
				} else {
					this.successVal++
				}
			},
			reg() {
				this.tui.href('../reg/reg')
			},
			login() {
				uni.switchTab({
					url:'/pages/tabbar/index/index'
				})
			}
		}
	}
</script>

<style>
	@import '@/static/style/login.css';

	.tui-third__box {
		width: 100%;
		left: 0;
		position: absolute;
		bottom: 96rpx;
		z-index: 2;
	}

	.tui-third__inner {
		width: 100%;
		padding: 24rpx 160rpx 0;
		box-sizing: border-box;
	}
</style>
