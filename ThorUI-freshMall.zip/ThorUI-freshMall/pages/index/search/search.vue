<template>
	<view class="tui-container">
		<tui-searchbar placeholder="吃出美好生活" :showLabel="false" focus @search="search"></tui-searchbar>
		<view class="tui-history__box tui-spacing" v-if="getCount>0">
			<view class="tui-tit__box tui-flex__between">
				<text class="tui-tit__text">历史搜索</text>
				<tui-icon name="delete" unit="rpx" @click="delHistory"></tui-icon>
			</view>
			<tui-data-checkbox activeBgColor="#F8F9FA" background="#F8F9FA" activeColor="#666" borderColor="#F8F9FA"
				radius="80rpx" :options="options" @change="change">
			</tui-data-checkbox>
		</view>
		<view class="tui-history__box tui-spacing">
			<view class="tui-tit__box tui-flex__between">
				<text class="tui-tit__text">实时热搜</text>
			</view>
			<tui-data-checkbox activeBgColor="#F8F9FA" background="#F8F9FA" activeColor="#666" borderColor="#F8F9FA"
				radius="80rpx" :options="options2" @change="change">
			</tui-data-checkbox>
		</view>

		<tui-actionsheet tips="是否清空历史搜索？" :show="show" @cancel="cancel" @click="btnDel"></tui-actionsheet>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				options: ['果冻橙', '芒果', '有机水果卷心菜', '水果萝卜', '熟冻帝王蟹', '赣南脐橙'],
				options2: ['车厘子', '草莓', '火锅到家', '精选红酒', '馋嘴零食暖热饮', '精美平安果', '高颜值好口味', '新鲜大虾仁', '冬季小食', '生菜'],
				show: false
			}
		},
		computed: {
			getCount() {
				return this.options.length
			}
		},
		methods: {
			change(e) {
				console.log(e)
				// this.tui.toast(e.detail.value)
				this.tui.href('../searchList/searchList?name=' + e.detail.value)
			},
			delHistory() {
				this.show = true
			},
			cancel() {
				this.show = false
			},
			btnDel() {
				this.options = []
				this.cancel()
			},
			search(e) {
				console.log(e)
				this.tui.href(`/pages/index/searchList/searchList?value=${e.value}`)
			}
		}
	}
</script>

<style>
	page {
		background: #fff;
	}

	.tui-history__box {
		padding-bottom: 40rpx;
	}

	.tui-tit__box {
		padding: 30rpx 0;
	}

	.tui-tit__text {
		font-size: 30rpx;
		font-weight: 600;
	}
</style>
