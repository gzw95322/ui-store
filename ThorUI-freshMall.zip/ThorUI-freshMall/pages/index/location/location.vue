<template>
	<view class="tui-container tui-spacing">
		<tui-text padding="24rpx 0 0" text="当前定位" size="28" type="gray"></tui-text>
		<view class="tui-card__wrap">
			<tui-list-cell unlined :hover="false">
				<view class="tui-flex__between">
					<tui-text padding="0 30rpx 0 0" text="海淀区中关村大厦" size="30" fontWeight="500"></tui-text>
					<view class="tui-align__center">
						<tui-lazyload-img src="/static/images/common/location_3x.png" backgroundColor="transparent"
							width="36rpx" height="36rpx"></tui-lazyload-img>
						<tui-text padding="0 0 0 12rpx" text="重新定位" :size="28" color="#40AE36"></tui-text>
					</view>
				</view>
			</tui-list-cell>
		</view>
		<tui-text padding="24rpx 0 0" text="我的地址" size="28" type="gray"></tui-text>
		<view class="tui-card__wrap" v-for="(item,index) in 2" :key="index">
			<t-address-item></t-address-item>
		</view>
		<view class="tui-btn__box">
			<tui-form-button radius="80rpx" @click="href">添加新地址</tui-form-button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {
			href() {
				this.tui.href('/pages/my/editAddress/editAddress')
			}
		}
	}
</script>

<style>
	.tui-align__center {
		flex-shrink: 0;
	}

	.tui-btn__box {
		width: 100%;
		padding: 70rpx 60rpx;
		box-sizing: border-box;
	}
</style>
