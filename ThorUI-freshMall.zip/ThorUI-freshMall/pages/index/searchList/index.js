export default [{
	src:'/static/images/product/cart_orange_3x.png',
	title:'四川爱媛38号可吸果冻橙',
	specs:'有机食品 | 水果',
	price:'39.9',
	unit:'/箱',
	original:'￥45.8/箱'
},{
	src:'/static/images/product/img_orange_cart.png',
	title:'四川眉山 爱媛38号可吸果冻橙礼盒装12粒(单果180g+)',
	specs:'有机食品 | 水果',
	price:'12.8',
	unit:'/份',
	original:'￥15.8/份'
},{
	src:'/static/images/product/cart_orange_3x.png',
	title:'四川爱媛38号可吸果冻橙',
	specs:'有机食品 | 水果',
	price:'39.9',
	unit:'/箱',
	original:'￥45.8/箱'
},{
	src:'/static/images/product/img_orange_cart.png',
	title:'四川眉山 爱媛38号可吸果冻橙礼盒装12粒(单果180g+)',
	specs:'有机食品 | 水果',
	price:'12.8',
	unit:'/份',
	original:'￥15.8/份'
},{
	src:'/static/images/product/cart_orange_3x.png',
	title:'四川爱媛38号可吸果冻橙',
	specs:'有机食品 | 水果',
	price:'39.9',
	unit:'/箱',
	original:'￥45.8/箱'
},{
	src:'/static/images/product/img_orange_cart.png',
	title:'四川眉山 爱媛38号可吸果冻橙礼盒装12粒(单果180g+)',
	specs:'有机食品 | 水果',
	price:'12.8',
	unit:'/份',
	original:'￥15.8/份'
},{
	src:'/static/images/product/cart_orange_3x.png',
	title:'四川爱媛38号可吸果冻橙',
	specs:'有机食品 | 水果',
	price:'39.9',
	unit:'/箱',
	original:'￥45.8/箱'
},{
	src:'/static/images/product/img_orange_cart.png',
	title:'四川眉山 爱媛38号可吸果冻橙礼盒装12粒(单果180g+)',
	specs:'有机食品 | 水果',
	price:'12.8',
	unit:'/份',
	original:'￥15.8/份'
}]