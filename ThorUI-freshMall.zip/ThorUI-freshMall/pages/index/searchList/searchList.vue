<template>
	<view class="tui-container">
		<tui-navigation-bar backgroundColor="#F8F9FA" :isOpacity="false" @init="initNavigation">
			<view class="tui-header tui-align__center" :class="['tui-header-pl']" :style="{width:left+'px'}">
				<!-- #ifndef H5 || MP-ALIPAY || MP-BAIDU -->
				<tui-icon name="arrowleft" unit="rpx" :size="64" color="#333"></tui-icon>
				<!-- #endif -->
				<tui-searchbar padding="0" height="32px" value="112" disabled></tui-searchbar>
				<view class="tui-cart__box tui-active" @tap="toCart">
					<image class="tui-cart__icon" src="/static/images/cart/cart_3x.png" mode="widthFix"></image>
					<tui-badge absolute type="warning" :scaleRatio="0.8" translateX="12rpx">1</tui-badge>
				</view>
			</view>
		</tui-navigation-bar>
		<view class="tui-screen__box tui-flex__between" :style="{top:height+'px'}">
			<view class="tui-screen__item tui-flex__center" @tap="screen(1)">
				<text class="tui-screen__text" :class="{'tui-screen__active':active===1}">价格</text>
				<view class="tui-sort__box">
					<view class="tui-asc" :class="{'tui-asc__active':sort==='asc' && active===1}"></view>
					<view class="tui-desc" :class="{'tui-desc__active':sort==='desc' && active===1}"></view>
				</view>
			</view>
			<view class="tui-screen__item tui-flex__center" @tap="screen(2)">
				<text class="tui-screen__text" :class="{'tui-screen__active':active===2}">销量</text>
			</view>
			<view class="tui-screen__item tui-flex__center" @tap="screen(3)">
				<text class="tui-screen__text">筛选</text>
				<tui-icon name="screen" unit="rpx" :size="24" color="#666"></tui-icon>
			</view>
		</view>
		<view class="tui-goods__list" :style="{marginTop:height+'px'}" v-if="!isNoData">
			<t-goods-item v-for="(item,index) in dataList" :key="index" :item="item"></t-goods-item>
			<tui-divider width="50%">已全部加载</tui-divider>
		</view>

		<!--筛选-->
		<tui-drawer :visible="visible" @close="close">
			<view class="tui-drawer__screen">
				<scroll-view scroll-y :style="{height:drawerHeight+'px'}">
					<!-- #ifndef MP -->
					<tui-status-bar></tui-status-bar>
					<!-- #endif -->
					<!-- #ifdef MP -->
					<view :style="{height:height-16+'px'}"></view>
					<!-- #endif -->
					<view class="tui-pl__30">
						<view class="tui-screen__title tui-flex__between">
							<text>价格区间</text>
						</view>
						<view class="tui-flex__center tui-price__box">
							<input placeholder-style="color:#999" placeholder="最低价" class="tui-price__input" />
							<text class="tui-input__sign">-</text>
							<input placeholder-style="color:#999" placeholder="最高价" class="tui-price__input" />
						</view>
						<tui-data-checkbox background="#EDEFF2" activeBgColor="rgba(64, 174, 54, .2)"
							borderColor="transparent" color="#333" activeColor="#40AE36" width="156"
							:options="priceArr"></tui-data-checkbox>
						<view v-for="(item,index) in options" :key="index">
							<view class="tui-screen__title tui-flex__between">
								<text>{{item.name}}</text>
								<tui-icon name="arrowdown" :size="40" unit="rpx" color="#666" @click="showAll">
								</tui-icon>
							</view>
							<tui-data-checkbox background="#EDEFF2" activeBgColor="rgba(64, 174, 54, .2)"
								borderColor="transparent" color="#333" activeColor="#40AE36" multiple width="156"
								:options="item.data"></tui-data-checkbox>
						</view>
					</view>
					<view class="tui-safe__seat tui-safe__area"></view>
				</scroll-view>
				<view class="tui-btn__box tui-safe__area">
					<tui-list-view unlined="bottom">
						<view class="tui-btn__inner tui-flex__between">
							<tui-form-button width="240rpx" plain :size="24" borderColor="#999" color="#333"
								height="72rpx" radius="40rpx">重置
							</tui-form-button>
							<tui-form-button width="242rpx" :size="24" height="72rpx" radius="40rpx" @click="close">确定
							</tui-form-button>
						</view>
					</tui-list-view>
				</view>
			</view>
		</tui-drawer>
		<!--无数据时显示-->
		<tui-no-data imgUrl="/static/images/common/icon_no_search.png" v-if="isNoData">
			<text class="tui-no__data">抱歉，没有找到商品哦</text>
		</tui-no-data>
	</view>
</template>

<script>
	import dataList from './index.js'
	export default {
		data() {
			return {
				isNoData: false,
				height: 44,
				left: 240,
				//asc、desc
				sort: 'asc',
				active: 2,
				drawerHeight: 0,
				visible: false,
				priceArr: ['10-20', '30-60', '80-100'],
				options: [{
					name: '商品特色',
					data: ['特色好货', '时令', '买手严选', '新品', '进口', '冷冻', '冷藏']
				}, {
					name: '品牌',
					data: ['正大', '桃李', '蒙牛', '伊利', '三得利', '象大厨']
				}],
				dataList
			}
		},
		onLoad() {
			let sys = uni.getSystemInfoSync()
			this.drawerHeight = sys.windowHeight
		},
		methods: {
			initNavigation(e) {
				this.height = e.height
				this.left = e.left
			},
			toCart() {
				uni.switchTab({
					url: '/pages/tabbar/cart/cart'
				})
			},
			screen(type) {
				if (type === 3) {
					this.visible = true
				} else {
					if (type === 1) {
						this.sort = this.active !== 1 || this.sort === 'desc' ? 'asc' : 'desc'
					}
					this.active = type
				}
			},
			showAll() {
				this.tui.toast('显示隐藏~')
			},
			close() {
				this.visible = false
			}
		}
	}
</script>

<style>
	.tui-header {
		width: 100%;
		height: 44px;
		padding: 0 30rpx 0 12rpx;
		box-sizing: border-box;
	}

	/*#ifdef H5*/
	.tui-header-pl {
		padding-left: 30rpx;
	}

	/* #endif */

	/*#ifdef MP-ALIPAY || MP-BAIDU */
	.tui-header-pl {
		padding-left: 80rpx;
	}

	/* #endif */

	.tui-cart__box {
		position: relative;
		width: 48rpx;
		height: 48rpx;
		margin-left: 24rpx;
	}

	.tui-cart__icon {
		width: 48rpx;
		height: 48rpx;
		display: block;
	}

	.tui-screen__box {
		width: 100%;
		height: 88rpx;
		background: #fff;
		position: fixed;
		left: 0;
		z-index: 2;
	}

	.tui-screen__item {
		flex: 1;
		/* #ifdef H5 */
		cursor: pointer;
		/* #endif */
	}

	.tui-sort__box {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: space-between;
		height: 36rpx;
		transform: scale(0.8);
		transform-origin: 0 center;
	}


	.tui-asc {
		width: 0;
		height: 0;
		border: 8rpx solid;
		border-color: transparent transparent #666 transparent;
	}

	.tui-asc__active {
		border-bottom-color: var(--tui-primary) !important;
	}

	.tui-desc {
		width: 0;
		height: 0;
		border: 8rpx solid;
		border-color: #666 transparent transparent transparent;
	}

	.tui-desc__active {
		border-top-color: var(--tui-primary) !important;
	}

	.tui-screen__text {
		font-size: 26rpx;
		color: #666666;
		padding-right: 8rpx;
	}

	.tui-screen__active {
		color: var(--tui-primary) !important;
	}

	.tui-goods__list {
		padding-top: 88rpx;
	}

	.tui-drawer__screen {
		width: 568rpx;
		height: 100%;
		background: #fff;
		position: relative;
	}

	.tui-pl__30 {
		padding-left: 30rpx;
		box-sizing: border-box;
	}

	.tui-screen__title {
		font-size: 26rpx;
		font-weight: 500;
		padding: 36rpx 30rpx 24rpx 0;
		box-sizing: border-box;
	}

	.tui-price__input {
		background: #EDEFF2;
		border-radius: 8rpx;
		font-size: 26rpx;
		text-align: center;
		padding: 12rpx 24rpx;
		flex: 1;
	}

	.tui-price__box {
		padding-right: 30rpx;
		padding-bottom: 20rpx;
		box-sizing: border-box;
	}

	.tui-input__sign {
		padding: 0 24rpx;
		flex-shrink: 0;
	}

	.tui-btn__box {
		width: 100%;
		position: absolute;
		left: 0;
		bottom: 0;
		background: #fff;
	}

	.tui-btn__inner {
		width: 100%;
		height: 100rpx;
		padding: 0 30rpx;
		box-sizing: border-box;
	}

	.tui-safe__seat {
		width: 100%;
		height: 120rpx;
	}

	.tui-no__data {
		color: #999;
	}
</style>
