<template>
	<view class="tui-container">
		<view class="tui-goods__info">
			<image src="/static/images/product/cart_orange_3x.png" class="tui-goods__img"></image>
			<view class="tui-goods__title">四川眉山 爱媛38号果冻橙礼盒装</view>
		</view>
		<view class="tui-comment__box">
			<t-comment-item marginTop="20rpx" v-for="(item,index) in commentList" :key="index"></t-comment-item>
			<tui-loadmore v-if="false"></tui-loadmore>
			<tui-divider width="52%">已全部加载</tui-divider>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				commentList:[{},{},{},{},{},{},{}]
			}
		},
		methods: {
			
		}
	}
</script>

<style>
	.tui-goods__info{
		width: 100%;
		padding: 20rpx;
		box-sizing: border-box;
		background: #fff;
		display: flex;
		align-items: center;
	}
	.tui-goods__img{
		width: 80rpx;
		height: 80rpx;
		margin-right: 30rpx;
		flex-shrink: 0;
	}
	.tui-goods__title{
		font-size: 26rpx;
	}
	.tui-comment__box{
		width: 100%;
		padding: 0 20rpx;
		box-sizing: border-box;
	}

</style>
