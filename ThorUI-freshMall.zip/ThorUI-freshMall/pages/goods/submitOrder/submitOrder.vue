<template>
	<view class="tui-container">
		<view class="tui-outer__box tui-safe__area">
			<t-address-item arrow icon @click="address"></t-address-item>
			<view class="tui-inner__box">
				<t-order-item title="生鲜快递发货" descr="上架24H发货，第三方物流配送" v-for="(item,index) in 2" :key="index" @click="detail">
				</t-order-item>
			</view>
			<view class="tui-inner__box">
				<tui-list-cell unlined arrow @click="coupon">
					<view class="tui-flex__between tui-pr--30">
						<text class="tui-size--30">优惠券</text>
						<text class="tui-color__warning tui-size--28">-￥10</text>
					</view>
				</tui-list-cell>
				<tui-list-cell unlined arrow>
					<view class="tui-flex__between tui-pr--30">
						<text class="tui-size--30">积分</text>
						<text class="tui-color__warning tui-size--28">-￥0.00</text>
					</view>
				</tui-list-cell>
				<tui-list-cell unlined arrow radius @click="invoice">
					<view class="tui-flex__between tui-pr--30">
						<text class="tui-size--30">发票</text>
						<tui-text type="gray" :size="28" text="不开发票"></tui-text>
					</view>
				</tui-list-cell>
			</view>
			<view class="tui-inner__box">
				<tui-radio-group>
					<tui-label>
						<view class="tui-list__item tui-flex__between">
							<view class="tui-flex__center">
								<tui-icon name="wechat" color="#09D116" unit="rpx" :size="64"></tui-icon>
								<text class="tui-size--30 tui-pl--20">微信支付</text>
							</view>
							<tui-radio color="#40AE36"></tui-radio>
						</view>
					</tui-label>
					<tui-label>
						<view class="tui-list__item tui-flex__between">
							<view class="tui-flex__center">
								<tui-icon name="alipay" color="#02A9F1" unit="rpx" :size="64"></tui-icon>
								<text class="tui-size--30 tui-pl--20">支付宝支付</text>
							</view>
							<tui-radio color="#40AE36"></tui-radio>
						</view>
					</tui-label>
				</tui-radio-group>
			</view>
			<view class="tui-inner__box">
				<tui-list-cell unlined :hover="false">
					<view class="tui-flex__between">
						<text class="tui-size--30">订单备注</text>
						<tui-input padding="0" :borderBottom="false" placeholder="请输入备注信息" align="right" :size="30">
						</tui-input>
					</view>
				</tui-list-cell>
			</view>
		</view>
		<t-goods-bar safeArea :checkAll="false" :num="4" text="提交订单" align="end" @click="submit"></t-goods-bar>
		<tui-bottom-popup :show="show">
			<view class="tui-bp__tit tui-flex__center">
				<text>确认付款</text>
				<view class="tui-icon--close" @tap="cancel">
					<tui-icon name="shut" unit="rpx" :size="44" color="#333"></tui-icon>
				</view>
			</view>
			<view class="tui-bp__content">
				<view class="tui-bp__price-box tui-flex__center">
					<text>￥</text>
					<text class="tui-bp__price">76.6</text>
				</view>
				<tui-list-cell :hover="false" :lineLeft="false" padding="30rpx 0">
					<view class="tui-flex__between">
						<text class="tui-bp__name">订单编号</text>
						<text>8283894949838</text>
					</view>
				</tui-list-cell>
				<tui-list-cell :hover="false" :lineLeft="false"  padding="30rpx 0">
					<view class="tui-flex__between">
						<text class="tui-bp__name">付款方式</text>
						<text>微信支付</text>
					</view>
				</tui-list-cell>
				<view class="ti-btn--box">
					<tui-form-button radius="80rpx" @click="result">立即付款</tui-form-button>
				</view>
			</view>
		</tui-bottom-popup>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				show: false
			}
		},
		methods: {
			submit() {
				this.show = true
			},
			cancel() {
				this.show = false
			},
			detail() {
				this.tui.href('/pages/goods/goodsDetail/goodsDetail')
			},
			address(){
				this.tui.href('/pages/my/address/address?isSelect=1')
			},
			invoice(){
				this.tui.href('/pages/goods/invoice/invoice')
			},
			result(){
				this.tui.href('/pages/goods/result/result')
			},
			coupon(){
				this.tui.href('/pages/my/myCoupon/myCoupon')
			}
		}
	}
</script>

<style>
	.tui-container {
		padding-bottom: 120rpx;
	}

	.tui-outer__box {
		width: 100%;
		padding-top: 20rpx;
		padding-left: 30rpx;
		padding-right: 30rpx;
		box-sizing: border-box;
	}

	.tui-inner__box {
		width: 100%;
		border-radius: 20rpx;
		margin-top: 20rpx;
		background: #fff;
		overflow: hidden;
	}

	.tui-pr--30 {
		padding-right: 30rpx;
		box-sizing: border-box;
	}

	.tui-size--30 {
		font-size: 30rpx;
	}

	.tui-size--28 {
		font-size: 28rpx;
	}

	.tui-pl--20 {
		padding-left: 20rpx;
	}

	.tui-list__item {
		width: 100%;
		padding: 20rpx 30rpx;
		box-sizing: border-box;
	}

	.tui-bp__tit {
		width: 100%;
		padding: 30rpx;
		box-sizing: border-box;
		position: relative;
		font-weight: 500;
	}

	.tui-icon--close {
		position: absolute;
		right: 22rpx;
		top: 12rpx;
		padding: 8rpx;
		/* #ifdef H5 */
		cursor: pointer;
		/* #endif */
	}

	.tui-bp__content {
		width: 100%;
		padding: 24rpx 50rpx 30rpx;
		box-sizing: border-box;
	}


	.tui-bp--top {
		padding-top: 40rpx;
	}

	.ti-btn--box {
		width: 100%;
		padding-top: 100rpx;
		box-sizing: border-box;
	}
	.tui-bp__price-box{
		width: 100%;
		align-items: flex-end;
		padding-bottom: 80rpx;
	}
	.tui-bp__price{
		font-size: 60rpx;
		line-height: 60rpx;
	}
	/* .tui-flex__between{
		width: 100%;
		font-size: 30rpx;
		padding-top:56rpx;
	} */
	.tui-bp__name{
		color: #999999;
	}
</style>
