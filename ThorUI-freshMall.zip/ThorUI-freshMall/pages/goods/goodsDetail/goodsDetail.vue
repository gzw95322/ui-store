<template>
	<view class="tui-container">
		<!-- #ifndef H5 -->
		<tui-navigation-bar @init="initNavigation" @change="opacityChange" :scrollTop="scrollTop" title="商品详情"
			color="#333">
			<!-- #ifndef MP-ALIPAY || MP-TOUTIAO -->
			<view class="tui-icon__box" :style="{ background: 'rgba(0, 0, 0,' + getIconOpacity + ')',top:top+'px' }"
				@tap="back">
				<tui-icon name="arrowleft" :size="30" :color="opacity >= 1 ? '#333' : '#fff'"></tui-icon>
			</view>
			<!-- #endif -->
		</tui-navigation-bar>
		<!-- #endif -->
		<view class="tui-gd__banner">
			<swiper class="tui-banner__swiper" autoplay :interval="5000" :duration="150" circular
				@change="bannerChange">
				<swiper-item v-for="(item, index) in banner" :key="index">
					<image :src="item.src" class="tui-slide__image"></image>
				</swiper-item>
			</swiper>
			<tui-swiper-dot :current="current" :type="4" :count="banner.length" right="30rpx" width="72rpx"
				height="44rpx" backgroundColor="rgba(0,0,0,0.4)" color="#fff" bottom="30rpx" radius="120rpx" :size="24">
			</tui-swiper-dot>
		</view>
		<view class="tui-content__wrap">
			<view class="tui-outer__box">
				<view class="tui-goods__info">
					<view class="tui-pri__box">
						<text class="tui-pri__sign">￥</text>
						<text class="tui-pri__num">39.8</text>
						<text class="tui-pri__unit">/份</text>
						<text class="tui-pri__original">￥45.8份</text>
					</view>
					<tui-icon name="share" color="#999" unit="rpx" :size="48" @click="share"></tui-icon>
				</view>
				<view class="tui-goods__title">四川眉山 爱媛38号可吸的果冻橙礼盒装12粒(单果180g+)</view>
				<view class="tui-tag__box tui-flex">
					<view class="tui-tag">产地量贩</view>
					<view class="tui-tag__text">基地优选 售后无忧</view>
				</view>
			</view>
			<view class="tui-outer__box">
				<view class="tui-flex">
					<text class="tui-service__tit">配送</text>
					<text class="tui-service__descr">上架24H发货，第三方物流配送，免运费</text>
				</view>
				<view class="tui-flex tui-sr__pd">
					<text class="tui-service__tit">服务</text>
					<text class="tui-service__descr">品质保证，生鲜不支持7天无理由退货</text>
				</view>
				<view class="tui-flex">
					<text class="tui-service__tit">优惠</text>
					<text class="tui-service__descr">特价商品每人限购2份</text>
				</view>
			</view>
			<view class="tui-outer__box tui-arrow__right" @tap="chooseSpecs">
				<tui-list-cell arrow unlined padding="16rpx 0" :arrowRight="false" :hover="false">
					<text class="tui-cell__tit">已选</text>
					<text class="tui-cell__descr">0.5kg/份</text>
				</tui-list-cell>
			</view>
			<view class="tui-outer__box tui-arrow__right">
				<tui-list-cell arrow unlined padding="16rpx 0" :arrowRight="false" :hover="false">
					<view class="tui-flex__between">
						<view>
							<text class="tui-cell__tit">用户评价</text>
							<text class="tui-cell__num">(1680)</text>
						</view>
						<text class="tui-cell__more">查看全部</text>
					</view>
				</tui-list-cell>
				<tui-list-view unlined="bottom" marginTop="20rpx">
					<t-comment-item padding="36rpx 0 0 0"></t-comment-item>
				</tui-list-view>
			</view>
			<view class="tui-outer__box">
				<tui-list-cell unlined padding="16rpx 0" :arrowRight="false" :hover="false">
					<text class="tui-cell__tit">规格信息</text>
				</tui-list-cell>
				<view class="tui-specs__box">
					<tui-list-cell padding="0" :hover="false" :lineLeft="false">
						<view class="tui-flex">
							<view class="tui-specs__tit tui-flex__center">产地</view>
							<view class="tui-specs__descr">安徽</view>
						</view>
					</tui-list-cell>
					<tui-list-cell padding="0" :hover="false" :lineLeft="false">
						<view class="tui-flex">
							<view class="tui-specs__tit tui-flex__center">规格</view>
							<view class="tui-specs__descr">180g+/份</view>
						</view>
					</tui-list-cell>
					<tui-list-cell padding="0" :hover="false" :lineLeft="false">
						<view class="tui-flex">
							<view class="tui-specs__tit tui-flex__center">保质期</view>
							<view class="tui-specs__descr">30天</view>
						</view>
					</tui-list-cell>
					<view class="tui-specs__item tui-flex">
						<view class="tui-specs__tit tui-flex__center">储存方式</view>
						<view class="tui-specs__descr">冷藏</view>
					</view>
				</view>
			</view>
		</view>
		<view class="tui-goods__descr">
			<image class="tui-img" src="/static/images/product/goods_descr.png" mode="widthFix"></image>
		</view>
		<view class="tui-safe__area"></view>
		<view class="tui-tabbar__wrap tui-safe__area">
			<view class="tui-tabbar__inner tui-flex__between">
				<view class="tui-flex__between tui-pr">
					<view class="tui-flex-1 tui-active">
						<tui-icon name="like" unit="rpx" :size="44" color="#333"></tui-icon>
						<view class="tui-cart__text">收藏</view>
					</view>
					<view class="tui-flex-1 tui-active">
						<tui-icon name="kefu" unit="rpx" :size="48" color="#333"></tui-icon>
						<view class="tui-cart__text">客服</view>
					</view>
					<view class="tui-flex-1 tui-active">
						<view class="tui-cart__box">
							<tui-icon name="cart" unit="rpx" :size="44" color="#333"></tui-icon>
							<tui-badge absolute type="warning" :scaleRatio="0.8" translateX="50%">1</tui-badge>
						</view>
						<view class="tui-cart__text">购物车</view>
					</view>
				</view>
				<view class="tui-btn__box">
					<tui-form-button radius="80rpx" width="400rpx" height="72rpx">加入购物车</tui-form-button>
				</view>
			</view>
		</view>
		<tui-bottom-popup :show="show">
			<view class="tui-bp__tit tui-flex__center">
				<text>选择规格</text>
				<view class="tui-icon--close" @tap="hideSpecs">
					<tui-icon name="shut" unit="rpx" :size="44" color="#333"></tui-icon>
				</view>
			</view>
			<view class="tui-bp__content">
				<view class="tui-bp--tit">选择重量</view>
				<tui-data-checkbox :options="options" background="#F8F9FA" activeBgColor="#F8F9FA" borderColor="#F8F9FA"
					activeColor="#40AE36"></tui-data-checkbox>
				<view class="tui-bp--tit tui-bp--top">选择数量</view>
				<tui-numberbox backgroundColor="#fff" color="#333" iconBgColor="#F8F9FA" iconColor="#333" :value="value"
					@change="change"></tui-numberbox>
				<view class="ti-btn--box">
					<tui-form-button radius="80rpx">添加到购物车</tui-form-button>
				</view>
			</view>
		</tui-bottom-popup>
		<t-share :show="shareShow" @cancel="shareCancel"></t-share>
	</view>
</template>

<script>
	import detail from './index.js'
	export default {
		data() {
			return {
				opacity: 0,
				scrollTop: 0,
				top: 0,
				banner: detail.banner,
				options: detail.options,
				current: 0,
				show: false,
				value: 1,
				shareShow: false
			}
		},
		computed: {
			getIconOpacity() {
				return 0.5 * (1 - this.opacity <= 0 ? 0 : 1 - this.opacity)
			}
		},
		methods: {
			initNavigation(e) {
				this.opacity = e.opacity;
				this.top = e.top;
			},
			opacityChange(e) {
				this.opacity = e.opacity;
			},
			bannerChange(e) {
				// console.log(e)
				this.current = e.detail.current
			},
			back() {
				uni.navigateBack()
			},
			chooseSpecs() {
				this.show = true
			},
			hideSpecs() {
				this.show = false
			},
			change(e) {
				this.value = e.value
			},
			share() {
				this.shareShow = true
			},
			shareCancel(){
				this.shareShow = false
			}
		},
		onPageScroll(e) {
			this.scrollTop = e.scrollTop;
		}
	}
</script>

<style>
	.tui-container {
		padding-bottom: 100rpx;
	}

	.tui-icon__box {
		height: 20px;
		width: 20px;
		padding: 6px;
		border-radius: 50%;
		display: flex;
		align-items: center;
		justify-content: center;
		position: fixed;
		left: 10px;
		transform: translateZ(0);
		z-index: 90;
	}

	.tui-banner__swiper {
		width: 100%;
		height: 750rpx;
	}

	.tui-slide__image {
		width: 100%;
		height: 750rpx;
		display: block;
	}

	.tui-gd__banner {
		position: relative;
	}

	.tui-content__wrap {
		width: 100%;
		padding: 0 20rpx;
		box-sizing: border-box;
	}

	.tui-outer__box {
		width: 100%;
		padding: 20rpx;
		box-sizing: border-box;
		background: #FFFFFF;
		border-radius: 20rpx;
		margin-top: 20rpx;
	}

	.tui-goods__info {
		width: 100%;
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	.tui-pri__sign {
		font-size: 24rpx;
		line-height: 24rpx;
		color: #F55726;
	}

	.tui-pri__num {
		font-size: 36rpx;
		line-height: 32rpx;
		font-weight: 500;
		color: #F55726;
	}

	.tui-pri__unit {
		font-size: 24rpx;
		line-height: 24rpx;
		color: #999999;
	}

	.tui-pri__original {
		font-size: 24rpx;
		line-height: 24rpx;
		color: #CCCCCC;
		text-decoration: line-through;
		padding-left: 12rpx;
	}

	.tui-goods__title {
		width: 100%;
		font-size: 32rpx;
		font-weight: 500;
		word-break: break-all;
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 2;
		margin-top: 10rpx;
	}

	.tui-tag__box {
		transform: scale(.8);
		transform-origin: 0 center;
		padding-top: 16rpx;
		align-items: center;
	}

	.tui-tag {
		display: inline-flex;
		align-items: center;
		justify-content: center;
		font-size: 24rpx;
		font-weight: 500;
		color: #FFFFFF;
		background: var(--tui-primary, #40AE36);
		padding: 4rpx 8rpx;
		border-radius: 6rpx;
	}

	.tui-tag__text {
		padding-left: 10rpx;
		font-size: 25rpx;
		color: #666;
	}

	.tui-service__tit {
		font-size: 24rpx;
		color: #999;
	}

	.tui-service__descr {
		font-size: 24rpx;
		padding-left: 20rpx;
	}

	.tui-sr__pd {
		padding: 16rpx 0;
	}

	.tui-arrow__right {
		padding-right: 28rpx;
		box-sizing: border-box;
		/* #ifdef H5 */
		cursor: pointer;
		/* #endif */
	}

	.tui-cell__tit {
		font-size: 26rpx;
		font-weight: 500;
		color: #333333;
	}

	.tui-cell__descr {
		padding-left: 20rpx;
		font-size: 26rpx;
	}

	.tui-cell__num {
		font-size: 24rpx;
		color: #999;
	}

	.tui-cell__more {
		font-size: 24rpx;
		color: #666666;
		padding-right: 30rpx;
	}

	.tui-specs__box {
		font-size: 24rpx;
		line-height: 24rpx;
		position: relative;
	}

	.tui-specs__box::after {
		content: '';
		position: absolute;
		width: 200%;
		height: 200%;
		border: 1px solid #eaeef1;
		transform: scale(.5);
		transform-origin: 0 0;
		left: 0;
		top: 0;
	}

	.tui-specs__tit {
		color: #666;
		width: 160rpx;
		height: 68rpx;
		background: #F8F9FA;
	}

	.tui-specs__descr {
		flex: 1;
		display: flex;
		align-items: center;
		padding: 20rpx;
		box-sizing: border-box;
	}

	.tui-flex {
		width: 100%;
	}

	.tui-goods__descr {
		width: 100%;
		margin-top: 20rpx;
		padding: 20rpx;
		box-sizing: border-box;
		background: #fff;
		word-break: break-all;
	}

	.tui-img {
		width: 100%;
	}

	.tui-icon__cart {
		width: 44rpx;
		height: 44rpx;
	}

	.tui-tabbar__wrap {
		width: 100%;
		position: fixed;
		left: 0;
		bottom: 0;
		z-index: 10;
		background-color: #fff;
	}

	.tui-tabbar__inner {
		width: 100%;
		height: 100rpx;
		padding-right: 24rpx;
		box-sizing: border-box;
	}

	.tui-pr {
		padding-right: 20rpx;
	}

	.tui-tabbar__wrap::before {
		content: " ";
		position: absolute;
		top: 0;
		right: 0;
		left: 0;
		border-top: 1px solid #eaeef1;
		-webkit-transform: scaleY(0.5) translateZ(0);
		transform: scaleY(0.5) translateZ(0);
		transform-origin: 0 0;
		z-index: 2;
		pointer-events: none;
	}

	.tui-btn__box {
		flex-shrink: 0;
	}

	.tui-cart__box {
		position: relative;
		display: inline-block;
	}

	.tui-flex-1 {
		text-align: center;
		flex-direction: column;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.tui-cart__text {
		font-size: 24rpx;
		transform: scale(.8);
		text-align: center;
		transform-origin: center;
	}

	.tui-bp__tit {
		width: 100%;
		padding: 30rpx;
		box-sizing: border-box;
		position: relative;
		font-weight: 500;
	}

	.tui-icon--close {
		position: absolute;
		right: 22rpx;
		top: 12rpx;
		padding: 8rpx;
		/* #ifdef H5 */
		cursor: pointer;
		/* #endif */
	}

	.tui-bp__content {
		width: 100%;
		padding: 50rpx 50rpx 30rpx;
		box-sizing: border-box;
	}

	.tui-bp--tit {
		font-size: 28rpx;
		padding-bottom: 24rpx;
	}

	.tui-bp--top {
		padding-top: 40rpx;
	}

	.ti-btn--box {
		width: 100%;
		padding-top: 120rpx;
		box-sizing: border-box;
	}
</style>
