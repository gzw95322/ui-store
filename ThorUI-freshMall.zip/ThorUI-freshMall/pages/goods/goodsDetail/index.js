const data = {
	banner: [{
		id: 1,
		src: '/static/images/product/orange_3x.png'
	}, {
		id: 1,
		src: '/static/images/product/img_spinach_3x.png'
	}, {
		id: 1,
		src: '/static/images/product/carrot_3x.png'
	}],
	options:[{
		text: '0.5 kg',
		value: 1
	}, {
		text: '0.8 kg',
		value: 2
	}, {
		text: '1 kg',
		value: 3
	}]

}
export default data
