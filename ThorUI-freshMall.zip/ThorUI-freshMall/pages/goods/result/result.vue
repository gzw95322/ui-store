<template>
	<view class="tui-container">
		<view class="tui-header tui-flex__center">
			<tui-icon name="circle-fill" color="#40AE36" unit="rpx" :size="120"></tui-icon>
			<text class="tui-res__tit">付款成功</text>
		</view>
		<view class="tui-form__box">
			<tui-list-cell :hover="false">
				<view class="tui-flex__between">
					<text class="tui-color__gray">接收方</text>
					<text>生鲜</text>
				</view>
			</tui-list-cell>
			<tui-list-cell :hover="false">
				<view class="tui-flex__between">
					<text class="tui-color__gray">订单编号</text>
					<text>8283894949838</text>
				</view>
			</tui-list-cell>
			<tui-list-cell :hover="false">
				<view class="tui-flex__between">
					<text class="tui-color__gray">支付方式</text>
					<text>微信</text>
				</view>
			</tui-list-cell>
			<tui-list-cell radius :hover="false" unlined>
				<view class="tui-flex__between">
					<text class="tui-color__gray">积分券奖励</text>
					<text>50.00</text>
				</view>
			</tui-list-cell>
		
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>
	.tui-container{
		width: 100%;
		padding: 0 30rpx;
		box-sizing: border-box;
	}
	.tui-header{
		flex-direction: column;
		padding-top: 120rpx;
	}
	.tui-res__tit{
		font-size: 30rpx;
		font-weight: bold;
		padding-top: 24rpx;
	}
	.tui-form__box {
		width: 100%;
		border-radius: 20rpx;
		overflow: hidden;
		background: #fff;
		margin-top: 60rpx;
		box-sizing: border-box;
	}
	.tui-form__box text{
		font-size: 30rpx;
	}

</style>
