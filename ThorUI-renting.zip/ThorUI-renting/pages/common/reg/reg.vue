<template>
	<view class="tui-container">
		<t-header></t-header>
		<view class="tui-outer__box">
			<tui-text text="创建您的账号" size="40" fontWeight="600" color="#1F244B"></tui-text>
			<tui-text padding="16rpx 0 60rpx" size="30" text="请输入您的个人信息以创建帐号" color="#555568" block></tui-text>
			<tui-text padding="0 0 20rpx" fontWeight="600" text="昵称*" color="#555568"></tui-text>
			<tui-input border-color="#979BB5" input-border color="#1F244B" placeholder="请输入您的昵称"></tui-input>
			<tui-text padding="40rpx 0 20rpx" fontWeight="600" text="手机号*" color="#555568"></tui-text>
			<tui-input border-color="#979BB5" input-border color="#1F244B" placeholder="请输入您的手机号"></tui-input>
			<tui-text padding="40rpx 0 20rpx" fontWeight="600" text="邮箱*" color="#555568"></tui-text>
			<tui-input border-color="#979BB5" input-border color="#1F244B" placeholder="请输入您的邮箱"></tui-input>
			<tui-text padding="40rpx 0 20rpx" fontWeight="600" text="密码*" color="#555568"></tui-text>
			<tui-input border-color="#979BB5" input-border placeholder="请输入密码" :password="password">
				<template v-slot:right>
					<tui-icon :name="password?'unseen':'seen'" :size="36" unit="rpx" @click="changeType"></tui-icon>
				</template>
			</tui-input>
			<view class="tui-btn__box">
				<tui-form-button margin="50rpx 0 40rpx" @click="nextStep">下一步</tui-form-button>
			</view>
			<view class="tui-flex__center">
				<tui-text color="#555568" text="已有账号？"></tui-text>
				<tui-text color="#EE9C40" decoration="underline" text="登录" highlight @click="login"></tui-text>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				password: true
			}
		},
		methods: {
			changeType() {
				this.password = !this.password
			},
			login(){
				uni.navigateBack()
			},
			nextStep(){
				this.tui.href('/pages/common/code/code')
			}
		}
	}
</script>

<style>
	.tui-outer__box {
		padding: 68rpx 44rpx;
		box-sizing: border-box;
	}
</style>