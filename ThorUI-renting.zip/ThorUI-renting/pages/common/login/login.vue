<template>
	<view class="tui-container">
		<t-header title="登录" :is-back="false"></t-header>
		<view class="tui-outer__box">
			<tui-text padding="0 0 20rpx" fontWeight="600" text="手机号" size="28" color="#555568"></tui-text>
			<tui-input border-color="#979BB5" input-border placeholder="请输入手机号"></tui-input>
			<tui-text padding="40rpx 0 20rpx" fontWeight="600" text="密码" size="28" color="#555568"></tui-text>
			<tui-input border-color="#979BB5" input-border placeholder="请输入密码" password></tui-input>
			<view class="tui-flex">
				<view class="tui-forget tui-active" @click="forget">忘记密码？</view>
			</view>
			<view class="tui-btn__box">
				<tui-form-button @click="login">登录</tui-form-button>
			</view>
			<view class="tui-flex__center">
				<tui-text color="#555568" text="没有账号？"></tui-text>
				<tui-text color="#EE9C40" decoration="underline" text="注册" highlight @click="reg"></tui-text>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		onLoad() {

		},
		methods: {
			reg() {
				this.tui.href('/pages/common/reg/reg')
			},
			forget() {
				this.tui.href('/pages/common/verifyCode/verifyCode')
			},
			login(){
				this.tui.href('/pages/tabbar/index/index',true)
			}
		}
	}
</script>

<style>
	.tui-outer__box {
		padding: 68rpx 44rpx;
		box-sizing: border-box;
	}

	.tui-forget {
		margin-left: auto;
		padding: 20rpx 0;
		font-size: 26rpx;
		margin-bottom: 20rpx;
	}

	.tui-flex__center {
		margin-top: 40rpx;
	}
</style>