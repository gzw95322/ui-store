<template>
	<view class="tui-container">
		<t-header></t-header>
		<view class="tui-outer__box">
			<tui-text text="设置密码" size="40" fontWeight="600" color="#1F244B"></tui-text>
			<tui-text padding="16rpx 0 60rpx" size="30" text="设置您的新密码" color="#555568" block></tui-text>
			<tui-text padding="0 0 20rpx" fontWeight="600" text="密码" color="#555568"></tui-text>
			<tui-input border-color="#979BB5" input-border placeholder="请输入确认密码" :password="password">
				<template v-slot:right>
					<tui-icon :name="password?'unseen':'seen'" :size="36" unit="rpx" @click="changeType(1)"></tui-icon>
				</template>
			</tui-input>
			<tui-text padding="40rpx 0 20rpx" fontWeight="600" text="确认密码" color="#555568"></tui-text>
			<tui-input border-color="#979BB5" input-border placeholder="请输入确认密码" :password="password2">
				<template v-slot:right>
					<tui-icon :name="password2?'unseen':'seen'" :size="36" unit="rpx" @click="changeType(2)"></tui-icon>
				</template>
			</tui-input>
			<view class="tui-btn__box">
				<tui-form-button margin="50rpx 0 40rpx" @click="btnConfirm">确定</tui-form-button>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				password: true,
				password2: true
			}
		},
		methods: {
			changeType(type) {
				if (type === 1) {
					this.password = !this.password
				} else {
					this.password2 = !this.password2
				}
			},
			btnConfirm() {
				uni.reLaunch({
					url: '/pages/common/login/login'
				})
			}
		}
	}
</script>

<style>
	.tui-outer__box {
		padding: 68rpx 44rpx;
		box-sizing: border-box;
	}
</style>