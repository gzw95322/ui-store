<template>
	<view class="tui-container">
		<t-header></t-header>
		<view class="tui-outer__box">
			<tui-text text="重置密码" size="40" fontWeight="600" color="#1F244B"></tui-text>
			<tui-text padding="16rpx 0 60rpx" size="30" text="修改密码、忘记密码找回" color="#555568" block></tui-text>
			<tui-text padding="0 0 20rpx" fontWeight="600" text="手机号码" color="#555568"></tui-text>
			<tui-input border-color="#979BB5" input-border color="#1F244B" placeholder="请输入您的手机号码" maxlength="11"
				v-model="mobile"></tui-input>
			<tui-text padding="40rpx 0 20rpx" fontWeight="600" text="验证码" color="#555568"></tui-text>
			<tui-input border-color="#979BB5" input-border color="#1F244B" placeholder="请输入验证码" maxlength="6"
				v-model="code">
				<template v-slot:right>
					<tui-countdown-verify :successVal="successVal" :resetVal="resetVal" borderWidth="0" height="40rpx"
						width="auto" @send="send">
					</tui-countdown-verify>
				</template>
			</tui-input>
			<view class="tui-btn__box">
				<tui-form-button margin="50rpx 0 40rpx" @click="setPwd">确定</tui-form-button>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				mobile: '',
				code: '',
				successVal: 0,
				resetVal: 0
			}
		},
		methods: {
			send(e) {
				if (!this.mobile || this.mobile.length !== 11) {
					this.tui.toast('手机号码有误！')
					this.resetVal++
				} else {
					this.successVal++
				}
			},
			setPwd(){
				this.tui.href('/pages/common/setPwd/setPwd')
			}
		}
	}
</script>

<style>
	.tui-outer__box {
		padding: 68rpx 44rpx;
		box-sizing: border-box;
	}
</style>