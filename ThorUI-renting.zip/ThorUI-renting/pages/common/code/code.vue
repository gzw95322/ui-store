<template>
	<view class="tui-container">
		<t-header></t-header>
		<view class="tui-outer__box">
			<image class="tui-img--code" mode="widthFix" src="/static/images/common/img_code_3x.png"></image>
			<view class="tui-flex__center">
				<tui-text padding="32rpx 120rpx 60rpx" color="#555568" text="输入我们通过短信发送到您注册手机上的验证"
					align="center"></tui-text>
			</view>
			<tui-code-input radius="20" border-color="#979BB5" width="96" height="96"></tui-code-input>
			<view class="tui-flex__center tui-padding">
				<tui-text size="24" color="#555568" text="没收到验证码？"></tui-text>
				<tui-text size="24" color="#EE9C40" decoration="underline" text="重新发送" highlight></tui-text>
			</view>
			<tui-form-button margin="50rpx 0 40rpx" @click="btnConfirm">确定</tui-form-button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {
			btnConfirm() {
				uni.reLaunch({
					url: '/pages/common/login/login'
				})
			}
		}
	}
</script>

<style>
	.tui-outer__box {
		padding: 68rpx 44rpx;
		box-sizing: border-box;
	}

	.tui-img--code {
		width: 360rpx;
		height: 340rpx;
		display: block;
		margin: 0 auto;
	}

	.tui-padding {
		padding: 50rpx 0;
	}
</style>