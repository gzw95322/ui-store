export default {
	msgList:[{
		type:'send',
		msg:'你好 ！我正在寻找一套公寓，大概需要可以住 1 个月左右。 请告诉我您的公寓都配套哪些设施？'
	},{
		type:'receive',
		msg:'是的，我的公寓有一些设施，比如有6个房间、4个卫生间、冰箱、wifi、洗衣机、办公桌、电视等等。'
	}]
}