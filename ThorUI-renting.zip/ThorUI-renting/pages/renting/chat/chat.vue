<template>
	<view class="tui-container">
		<view class="tui-chat__box">
			<view v-for="(item,index) in msgList" :key="index">
				<view class="tui-chat__item" :class="[item.type==='send'?'tui-chat__right':'tui-chat__left']">
					<image :src="`/static/images/renting/avatar_0${item.type==='send'?1:3}.png`" class="tui-avatar">
					</image>
					<view>
						<view class="tui-chat__content">
							<text decode>{{item.msg}}</text>
						</view>
						<view class="tui-chat--time" :class="{'tui-time--right':item.type!=='send'}">13:25</view>
					</view>
				</view>
			</view>
		</view>
		<view class="tui-safe__area"></view>
		<view class="tui-fixed__box" :class="{'tui-face__show':faceShow}">
			<view class="tui-tabbar__box">
				<view class="tui-chat--input">
					<view class="tui-icon--box tui-active" @tap="faceToggle">
						<tui-icon name="imface" :size="40" unit="rpx" color="#818194"></tui-icon>
					</view>
					<textarea :enableNative="false" auto-height :show-count="false" :fixed="true"
						disable-default-padding confirm-type="send" class="tui-input" :maxlength="2000"
						:cursor-spacing="16" v-model="msg" @focus="onFocus" @blur="onBlur"></textarea>
					<view class="tui-icon--box tui-active" @tap="selectPhotos">
						<tui-icon name="camera-fill" :size="40" unit="rpx" color="#818194"></tui-icon>
					</view>
				</view>
				<view class="tui-send--iconbox" @tap="sendMsg">
					<image class="tui-send--icon" src="/static/images/renting/icon_send.png"></image>
				</view>
			</view>
			<view class="tui-scroll__box" :class="{'tui-face--show':faceShow}">
				<scroll-view scroll-y class="tui-face__box">
					<view class="tui-face__inner">
						<text class="tui-face__text tui-active" v-for="(item,index) in faceList" :key="index"
							@click="faceClick(item)">{{item}}</text>
					</view>
					<view class="tui-seat__box"></view>
				</scroll-view>
				<view class="tui-del__box" @tap.stop="delMsg">
					<tui-icon name="deletekey" :size="44" unit="rpx"></tui-icon>
				</view>
			</view>
			<view class="tui-safe__area" v-if="!faceShow && !isFocus"></view>
		</view>
	</view>
</template>

<script>
	import data from './index.js'
	import faceList from './emoji.js'
	export default {
		data() {
			return {
				msgList: data.msgList,
				faceList,
				faceShow: false,
				msg: '',
				isFocus: false
			}
		},
		methods: {
			faceToggle() {
				this.faceShow = !this.faceShow
			},
			faceClick(item) {
				this.msg += item;
			},
			delMsg() {
				if (!this.msg) return;
				let number = 1;
				if (this.msg.length > 1) {
					number = this.msg.substr(this.msg.length - 2, this.msg.length).search(
						/(\ud83c[\udf00-\udfff])|(\ud83d[\udc00-\ude4f])|(\ud83d[\ude80-\udeff])/i) == -1 ? 1 : 2;
				}
				this.msg = this.msg.substr(0, this.msg.length - number);
			},
			selectPhotos() {
				this.tui.toast('选择照片~')
			},
			sendMsg() {
				this.tui.toast('发送消息~')
			},
			onFocus() {
				this.isFocus = true
			},
			onBlur() {
				this.isFocus = false
			}
		}
	}
</script>

<style>
	.tui-container {
		padding-bottom: 108rpx;
	}

	.tui-chat__box {
		width: 100%;
		padding: 48rpx 24rpx 0;
		box-sizing: border-box;
		white-space: pre-wrap;
		word-break: break-word;
	}

	.tui-chat__item {
		width: 100%;
		display: flex;
		padding-right: 96rpx;
		margin-bottom: 48rpx;
		box-sizing: border-box;
		overflow: hidden;
		white-space: pre-wrap;
		word-break: break-word;
	}

	.tui-chat--time {
		font-size: 24rpx;
		color: #818194;
		padding: 16rpx 24rpx;
		box-sizing: border-box;
	}

	.tui-time--right {
		text-align: right;
	}

	.tui-avatar {
		width: 90rpx;
		height: 90rpx;
		flex-shrink: 0;
	}

	.tui-chat__content {
		margin-left: 24rpx;
		background-color: #fff;
		padding: 20rpx 24rpx;
		box-sizing: border-box;
		border-radius: 0 32rpx 32rpx 32rpx;
		font-size: 28rpx;
		color: #818194;
		text-align: justify;
		display: flex;
		align-items: center;
		white-space: pre-wrap;
		word-break: break-word;
		position: relative;
	}


	.tui-chat__content text {
		max-width: 100%;
		white-space: pre-wrap;
		word-break: break-word;
	}

	.tui-chat__right {
		padding-left: 96rpx;
		padding-right: 0;
		flex-direction: row-reverse;
	}

	.tui-chat__right .tui-chat__content {
		margin-left: 0;
		margin-right: 24rpx;
		border-radius: 32rpx 0 32rpx 32rpx;
		background-color: #ED9B40;
		color: #fff;
	}

	.tui-fixed__box {
		width: 100%;
		position: fixed;
		left: 0;
		bottom: 0;
		z-index: 10;
		background-color: #fff;
		box-sizing: content-box;
		transform: translateY(520rpx);
		transition: transform 0.15s linear;
	}

	.tui-face__show {
		transform: translateY(0rpx);
	}

	.tui-tabbar__box {
		width: 100%;
		display: flex;
		align-items: flex-end;
		justify-content: space-between;
		padding: 16rpx 44rpx;
		box-sizing: border-box;
	}

	.tui-icon--box {
		flex-shrink: 0;
		height: 76rpx;
		display: flex;
		align-items: center;
		padding: 0 24rpx;
	}

	.tui-chat--input {
		width: 100%;
		display: flex;
		align-items: flex-end;
		position: relative;
		border-radius: 20rpx;
		background: rgba(228, 228, 231, .4);
	}

	.tui-input {
		width: 100%;
		/* #ifndef MP-ALIPAY || MP-QQ */
		min-height: 36rpx;
		box-sizing: content-box;
		padding: 20rpx 0rpx;
		line-height: 36rpx;
		/* #endif */
		/* #ifdef MP-ALIPAY || MP-QQ */
		line-height: 1;
		min-height: 76rpx;
		/* #endif */
		font-size: 28rpx;

	}

	.tui-send--iconbox {
		height: 76rpx;
		display: flex;
		flex-shrink: 0;
		align-items: center;
		justify-content: center;
		/* #ifdef H5 */
		cursor: pointer;
		/* #endif */
		margin-left: 36rpx;
	}

	.tui-send--iconbox:active {
		opacity: .5;
	}

	.tui-send--icon {
		width: 40rpx;
		height: 40rpx;
		flex-shrink: 0;
	}

	.tui-scroll__box {
		position: relative;
		opacity: 0;
		visibility: hidden;

	}

	.tui-face--show {
		opacity: 1;
		visibility: visible;
	}

	.tui-face__box {
		width: 100%;
		height: 520rpx;
		background-color: #FEFBF7;
	}

	.tui-face__inner {
		width: 100%;
		display: flex;
		box-sizing: border-box;
		flex-direction: row;
		flex-wrap: wrap;
		padding: 32rpx 2rpx;
	}

	.tui-face__text {
		display: flex;
		width: 106rpx;
		font-size: 60rpx;
		padding: 16rpx 0;
		text-align: center;
		justify-content: center;
		align-items: center;
		/* #ifdef H5 */
		cursor: pointer;
		/* #endif */
	}

	.tui-seat__box {
		width: 100%;
		height: 96rpx;
	}

	.tui-del__box {
		position: absolute;
		right: 32rpx;
		bottom: 32rpx;
		width: 120rpx;
		height: 72rpx;
		background-color: #fff;
		border-radius: 16rpx;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.tui-del__box:active {
		background-color: #ddd;
	}
</style>