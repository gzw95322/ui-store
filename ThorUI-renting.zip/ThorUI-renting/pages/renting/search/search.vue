<template>
	<view class="tui-container">
		<t-header>
			<view class="tui-search--box" :style="{paddingRight}">
				<tui-input padding="22rpx 30rpx" :border-bottom="false" background-color="#fff" placeholder="请输入搜索关键词">
					<template v-slot:right>
						<image src="/static/images/common/icon_search.png" class="tui-icon--search tui-active"></image>
					</template>
				</tui-input>
			</view>
		</t-header>
		<view class="tui-outer__box">
			<view class="tui-flex__between">
				<tui-text text="新上" size="36" font-weight="600"></tui-text>
				<view class="tui-filter--bar tui-bg tui-flex__center" @tap="screen">
					<image class="tui-icon--filter" src="/static/images/common/icon_filter.png"></image>
					<text>筛选</text>
				</view>
			</view>

			<view class="tui-list">
				<t-list-item width="100%" top="32" v-for="(item,index) in list" :key="index" @click="detail"></t-list-item>
				<!-- <tui-loadmore index="3" type="primary"></tui-loadmore> -->
				<tui-divider background-color="#FEFBF7" width="50%">已全部加载</tui-divider>
			</view>
			<tui-no-data v-if="false" imgUrl="/static/images/common/img_none.png" :fixed="false" margin-top="300">
				暂无结果，试试别的吧
			</tui-no-data>
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				paddingRight: '44rpx',
				list:['','','']
			}
		},
		onLoad() {
			this.getMpMenu()
		},
		methods: {
			getMpMenu() {
				let menuInfo = null;
				// #ifdef MP-ALIPAY || MP-WEIXIN || MP-BAIDU || MP-QQ || MP-TOUTIAO
				menuInfo = uni.getMenuButtonBoundingClientRect()
				// #endif
				if (menuInfo) {
					const sys = uni.getSystemInfoSync()
					this.paddingRight = (sys.windowWidth - menuInfo.left + uni.upx2px(30)) + 'px'
				}
			},
			detail(){
				this.tui.href('/pages/renting/detail/detail')
			},
			screen(){
				this.tui.href('/pages/renting/screen/screen?page=2')
			}
		}
	}
</script>

<style>
	.tui-search--box {
		position: relative;
		z-index: 410;
		height: 90rpx;
		/* #ifdef H5 */
		padding: 0 44rpx;
		margin-top: 24rpx;
		/* #endif */
		/* #ifndef H5 */
		margin-top: 108rpx;
		margin-left: 162rpx;
		/* #endif */
		box-sizing: border-box;
	}

	.tui-icon--search {
		width: 44rpx;
		height: 44rpx;
		display: block;
	}

	.tui-outer__box {
		padding: 50rpx 44rpx 30rpx;
		box-sizing: border-box;
	}

	.tui-filter--bar {
		width: 178rpx;
		height: 68rpx;
		border-radius: 20rpx;
		flex-shrink: 0;
		font-size: 26rpx;
		color: #fff;
		/* #ifdef H5 */
		cursor: pointer;
		/* #endif */
	}

	.tui-icon--filter {
		width: 28rpx;
		height: 28rpx;
		margin-right: 16rpx;
	}

	.tui-list {
		padding-top: 8rpx;
	}
</style>