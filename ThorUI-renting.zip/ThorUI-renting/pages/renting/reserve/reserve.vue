<template>
	<view class="tui-container">
		<t-header title="预定"></t-header>
		<view class="tui-outer__box">
			<view class="tui-info__box tui tui-align__center">
				<view class="tui-house__box tui-flex__center">
					<image class="tui-house" src="/static/images/renting/icon_house.png"></image>
				</view>
				<view class="tui-flex--1">
					<tui-overflow-hidden bold :lineClamp="1" color="#1F244B">远洋天地二区</tui-overflow-hidden>
					<tui-text text="回龙观·远洋天地二区" size="24" color="#818194"></tui-text>
				</view>
				<view class="tui-score__box">
					<tui-icon name="star-fill" size="26" unit="rpx" color="#FBBC04"></tui-icon>
					<text class="tui-score">4.6</text>
				</view>
			</view>

			<view class="tui-flex__between tui-top--lg">
				<view class="tui-flex__1 tui-left">
					<tui-text text="入住时间" size="30" color="#555568" font-weight="600" padding="0 0 20rpx">
						<template v-slot:right>
							<image src="/static/images/my/icon_check_in.png" class="tui-icon--check"></image>
						</template>
					</tui-text>
					<tui-input disabled border-color="#979BB5" input-border color="#1F244B" placeholder="请选择时间"
						:value="startTime" @click="pickDate(1)">
						<template v-slot:left>
							<image src="/static/images/common/icon_calendar_3x.png" class="tui-icon-input"></image>
						</template>
					</tui-input>
				</view>
				<view class="tui-flex__1 tui-right">
					<tui-text text="退房时间" size="30" color="#555568" font-weight="600" padding="0 0 20rpx">
						<template v-slot:right>
							<image src="/static/images/my/icon_check_out.png" class="tui-icon--check"></image>
						</template>
					</tui-text>
					<tui-input disabled border-color="#979BB5" input-border color="#1F244B" placeholder="请选择时间"
						:value="endTime" @click="pickDate(2)">
						<template v-slot:left>
							<image src="/static/images/common/icon_calendar_3x.png" class="tui-icon-input"></image>
						</template>
					</tui-input>
				</view>
			</view>
			<tui-text text="支付方式" size="30" color="#555568" font-weight="600" padding="50rpx 0 20rpx"></tui-text>
			<tui-input disabled border-color="#979BB5" input-border color="#1F244B" placeholder="请选择支付方式"
				@click="selectToggle(true)" :value="options.text">
				<template v-slot:left>
					<image :src="options.src || '/static/images/common/img_def.png'" class="tui-icon-input"></image>
				</template>
				<template v-slot:right>
					<tui-icon name="arrowright" unit="rpx" size="36"></tui-icon>
				</template>
			</tui-input>

			<tui-text text="小结" font-weight="600" size="36" padding="68rpx 0 0"></tui-text>
			<view class="tui-flex__between tui-top--md">
				<view>
					<tui-text text="租金" color="#555568"></tui-text>
					<tui-text text="（季付价）" size="24" color="#555568"></tui-text>
				</view>
				<tui-text text="￥2546" color="#EE9C40"></tui-text>
			</view>
			<view class="tui-flex__between tui-top--sm">
				<tui-text text="服务费" color="#555568"></tui-text>
				<tui-text text="￥180" color="#EE9C40"></tui-text>
			</view>
			<view class="tui-flex__between tui-top--sm">
				<tui-text text="网费" color="#555568"></tui-text>
				<tui-text text="￥120" color="#EE9C40"></tui-text>
			</view>
			<tui-divider :height="72"></tui-divider>
			<view class="tui-flex__between">
				<tui-text text="实付" color="#555568" font-weight="600" size="32"></tui-text>
				<tui-text text="￥2846" color="#EE9C40" font-weight="600" size="32"></tui-text>
			</view>
			<view class="tui-btn__box">
				<tui-form-button @click="btnPay">确定</tui-form-button>
			</view>
		</view>
		<tui-select :height="400" :list="list" :show="show" iconBgColor="transparent" @close="selectToggle(false)"
			@confirm="changePay"></tui-select>
		<tui-datetime ref="dateTime" :type="2" @confirm="onConfirm"></tui-datetime>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				show: false,
				list: [{
					text: '微信支付',
					src: '/static/images/renting/icon_wxpay.png'
				}, {
					text: '支付宝支付',
					src: '/static/images/renting/icon_alipay.png'
				}, {
					text: '银行卡 6222***8888',
					src: '/static/images/renting/icon_unionpay.png'
				}, {
					text: '银行卡 6222***6666',
					src: '/static/images/renting/icon_unionpay.png'
				}],
				options: {},
				dateShow: true,
				//1-入住时间 2-退房时间
				pickType: 1,
				startTime: '',
				endTime: ''
			}
		},
		onLoad() {
			// this.options = this.list[0]
		},
		methods: {
			changePay(e) {
				console.log(e)
				const index = e.index;
				this.options = e.options
				//关闭选择弹框
				this.selectToggle(false)
			},
			selectToggle(show) {
				this.show = show
			},
			btnPay() {
				this.tui.href('/pages/renting/result/result')
			},
			pickDate(type) {
				this.pickType = type;
				this.$refs.dateTime.show()
			},
			onConfirm(e) {
				console.log(e)
				if (this.pickType === 1) {
					this.startTime = e.result
				} else {
					this.endTime = e.result
				}
			}
		}
	}
</script>

<style>
	.tui-outer__box {
		padding: 50rpx 44rpx;
	}

	.tui-info__box {
		background: #FFFFFF;
		border-radius: 20rpx;
		padding: 28rpx;
		box-sizing: border-box;
		position: relative;
	}

	.tui-house__box {
		width: 126rpx;
		height: 126rpx;
		background: rgba(247, 178, 99, .1);
		border-radius: 20rpx;
		margin-right: 24rpx;
		flex-shrink: 0;
	}

	.tui-house {
		width: 76rpx;
		height: 76rpx;
	}

	.tui-score__box {
		position: absolute;
		right: 24rpx;
		top: 12rpx;
		font-size: 24rpx;
		line-height: 28rpx;
		color: #555568;
		padding: 6rpx 0;
		z-index: 2;
	}

	.tui-score {
		zoom: .9;
		padding-left: 8rpx;
		line-height: 24rpx;
	}

	.tui-flex--1 {
		flex: 1;
		overflow: hidden;
	}

	.tui-icon--check {
		width: 26rpx;
		height: 26rpx;
		margin-left: 4rpx;
	}

	.tui-flex__between {
		width: 100%;

	}

	.tui-left {
		padding-right: 16rpx;
		box-sizing: border-box;
	}

	.tui-right {
		padding-left: 16rpx;
		box-sizing: border-box;
	}

	.tui-icon-input {
		width: 44rpx;
		height: 44rpx;
		flex-shrink: 0;
		margin-right: 12rpx;
	}

	.tui-top--lg {
		padding-top: 50rpx;
	}

	.tui-top--md {
		padding-top: 32rpx;
	}

	.tui-top--sm {
		padding-top: 24rpx;
	}

	.tui-btn__box {
		width: 100%;
		margin-top: 90rpx;
	}
</style>