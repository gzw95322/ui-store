<template>
	<view>
	   <web-view src="https://www.thorui.cn/tpl/#/home"></web-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		onLoad(){
			this.tui.modal('温馨提示','该功能请自行实现，该模板不提供此功能，示例仅做简单演示。非模板内容，小程序请打开调试模式预览！',false)
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
