<template>
	<view class="tui-container">
		<!-- #ifndef H5 -->
		<t-header :is-bg="false" background="transparent"></t-header>
		<!-- #endif -->
		<view class="tui-swiper--outer">
			<swiper class="tui-swiper--box" circular autoplay>
				<swiper-item>
					<image src="/static/images/house/img_detail_2x.png" class="tui-swiper--img"></image>
				</swiper-item>
				<swiper-item>
					<image src="/static/images/house/img_detail_2x.png" class="tui-swiper--img"></image>
				</swiper-item>
			</swiper>
			<view class="tui-ar__box tui-flex__center" @tap="arView">
				<image class="tui-icon--ar" src="/static/images/renting/icon_ar.png"></image>
				<tui-text text="AR视图" color="#fff"></tui-text>
			</view>
		</view>

		<view class="tui-outer__box">
			<view class="tui-collect__box" :class="{'tui-bg':collect}" @tap="toggle">
				<image class="tui-icon--collect" src="/static/images/renting/icon_collect.png"></image>
			</view>
			<view class="tui-align__center">
				<tui-grade disabled :score="4.6" active="#FBBC04" :size="16"></tui-grade>
				<tui-text text="4.6" color="#555568" size="26" padding="0 0 0 12rpx"></tui-text>
			</view>
			<tui-text text="远洋天地二期·2居室-01卧" size="44" font-weight="600" padding="32rpx 0"></tui-text>

			<view class="tui-align__center">
				<view class="tui-info__box">
					<view class="tui-icon__box">
						<image class="tui-info--icon" src="/static/images/renting/icon_bed.png" mode="widthFix"></image>
					</view>
					<tui-text text="3床" font-weight="500" size="24"></tui-text>
				</view>
				<view class="tui-info__box">
					<view class="tui-icon__box">
						<image class="tui-info--icon t-width" src="/static/images/renting/icon_toilet.png"
							mode="widthFix">
						</image>
					</view>
					<tui-text text="2卫" font-weight="500" size="24"></tui-text>
				</view>
				<view class="tui-info__box">
					<view class="tui-icon__box">
						<image class="tui-info--icon" src="/static/images/renting/icon_area.png" mode="widthFix">
						</image>
					</view>
					<tui-text text="124㎡" font-weight="500" size="24"></tui-text>
				</view>
			</view>
			<tui-divider :height="72"></tui-divider>
			<view class="tui-flex__between">
				<view class="tui-align__center">
					<image class="tui-avatar" src="/static/images/renting/avatar_03.png"></image>
					<view>
						<tui-text text="李大力" font-weight="500" block></tui-text>
						<tui-text text="服务管家" size="26" color="#555568"></tui-text>
					</view>
				</view>
				<view class="tui-menu--box">
					<view class="tui-menu--item tui-active" @tap="chat">
						<image src="/static/images/renting/icon_msg.png" class="tui-menu--icon" mode="widthFix"></image>
					</view>
					<view class="tui-menu--item tui-active" @tap="makePhone">
						<image src="/static/images/renting/icon_tel.png" class="tui-menu--icon" mode="widthFix"></image>
					</view>
				</view>
			</view>
			<tui-divider :height="72"></tui-divider>
			<tui-text text="位置" font-weight="600" size="32"></tui-text>
			<view class="tui-position__box">
				<tui-icon name="position" unit="rpx"></tui-icon>
				<tui-text padding="0 0 0 8rpx" text="北京市海淀区13号线回龙观站步行约324米" size="26" color="#818194"></tui-text>
			</view>
			<view class="tui-map--box" @tap="openLocation">
				<!-- 使用百度地图静态图，传入经纬度即可，优化性能以及解决各平台层级问题 ，小程序端需在后台配置域名：https://api.map.baidu.com-->
				<image class="tui-map" :src="src" @error="error"></image>
				<view class="tui-map--center">
					<image class="tui-icon--posi" src="/static/images/house/img_position.png" mode="widthFix"></image>
					<tui-text text="远洋天地二期" size="24"></tui-text>
				</view>
				<image class="tui-nav--map" src="/static/images/house/img_nav.png"></image>
			</view>
			<tui-divider :height="72"></tui-divider>
			<tui-text text="房源简介" font-weight="600" size="32"></tui-text>
			<tui-overflow-hidden :type="2" :size="30" color="#555568" height="200rpx" padding="30rpx 0 0"
				gradientColor="#FEFBF7" :removeGradient="removeGradient">
				房源位于海天通西苑三区。总共有35栋楼。为低密度社区，居住环境好。全天有保安执勤。有出租车位，可在物业处申请。
				房源位于海天通西苑三区。总共有35栋楼。为低密度社区，居住环境好。全天有保安执勤。有出租车位，可在物业处申请。房源位于海天通西苑三区。总共有35栋楼。为低密度社区，居住环境好。全天有保安执勤。有出租车位，可在物业处申请。
			</tui-overflow-hidden>
			<view class="tui-btn__box">
				<tui-form-button background="#fff" color="#FBBC04" btn-size="medium" size="28" margin="36rpx auto"
					@click="readmore">{{removeGradient?'收起描述':'全部描述'}}</tui-form-button>
			</view>

		</view>
		<view class="tui-tababr__box">
			<view class="tui-flex__between">
				<view>
					<tui-text size="24" type="primary" text="￥"></tui-text>
					<tui-text text="2500" type="primary" size="30" font-weight="600"></tui-text>
					<tui-text size="24" text="/月" color="#555568"></tui-text>
				</view>
				<tui-form-button width="318rpx" @click="reserve">马上预定</tui-form-button>
			</view>
			<view class="tui-safe__area"></view>
		</view>
		<view class="tui-safe__area"></view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				lat: 40.07649,
				lng: 116.34266,
				src: '',
				removeGradient: false,
				collect: false
			}
		},
		onLoad() {
			//使用百度地图静态图，传入经纬度即可，优化性能以及解决各平台层级问题 ，小程序端需在后台配置域名：https://api.map.baidu.com
			this.src =
				`https://api.map.baidu.com/staticimage/v2?ak=w0LgoyM3d6uCcIxc6z5Oe940UjOnNFKa&mcode=666666&center=${this.lng},${this.lat}&width=800&height=400&zoom=15&copyright=1&dpiType=ph`
		},
		methods: {
			readmore() {
				this.removeGradient = !this.removeGradient
			},
			openLocation() {
				//此处地址与经纬度随意填写，仅做演示使用，并非真实数据
				uni.openLocation({
					name: '远洋天地二期',
					address: '北京市海淀区13号线回龙观站步行约324米',
					latitude: 40.07649,
					longitude: 116.34266,
					scale: 18
				})
			},
			toggle() {
				this.collect = !this.collect
				this.tui.toast(this.collect ? '收藏成功' : '取消收藏成功')
			},
			chat() {
				this.tui.href('/pages/renting/chat/chat')
			},
			error(){
				this.src='/static/images/renting/v2.png'
			},
			arView(){
				this.tui.href('/pages/renting/ar/ar')
			},
			makePhone(){
				uni.makePhoneCall({
					phoneNumber:'4000809970'
				})
			},
			reserve(){
				this.tui.href('/pages/renting/reserve/reserve')
			}
		}
	}
</script>

<style>
	.tui-container {
		padding-bottom: 136rpx;
	}

	.tui-swiper--outer {
		position: relative;
	}

	.tui-swiper--box {
		width: 100%;
		height: 634rpx;
	}

	.tui-swiper--img {
		width: 100%;
		height: 634rpx;
		display: block;
	}

	.tui-ar__box {
		position: absolute;
		bottom: 118rpx;
		left: 46rpx;
		z-index: 2;
		width: 248rpx;
		height: 96rpx;
		background: rgba(0, 0, 0, .6);
		box-shadow: 4rpx 28rpx 144rpx 0 rgba(0, 0, 0, 0.05);
		border-radius: 30rpx;
		border: 1px solid #FFF3F3;
		/* #ifdef H5 */
		cursor: pointer;
		/* #endif */
		box-sizing: border-box;
	}

	.tui-icon--ar {
		width: 48rpx;
		height: 48rpx;
		margin-right: 20rpx;
	}

	.tui-outer__box {
		padding: 50rpx 44rpx;
		box-sizing: border-box;
		margin-top: -72rpx;
		position: relative;
	}

	.tui-collect__box {
		position: absolute;
		right: 44rpx;
		top: -48rpx;
		width: 96rpx;
		height: 96rpx;
		box-shadow: 0 54rpx 54rpx 0 rgba(170, 170, 170, 0.15);
		border-radius: 30rpx;
		background: rgba(0, 0, 0, .4);
		border: 1px solid #FFFFFF;
		box-sizing: border-box;
		display: flex;
		align-items: center;
		justify-content: center;
		z-index: 8;
		/* #ifdef H5 */
		cursor: pointer;
		/* #endif */
	}

	.tui-icon--collect {
		width: 44rpx;
		height: 44rpx;
	}

	.tui-info__box {
		display: flex;
		align-items: center;
		margin-right: 50rpx
	}

	.tui-padding {
		padding: 32rpx 0 8rpx;
	}

	.tui-icon__box {
		width: 52rpx;
		height: 52rpx;
		background: rgba(31, 36, 75, .1);
		border-radius: 16rpx;
		display: flex;
		align-items: center;
		justify-content: center;
		margin-right: 16rpx;
	}

	.tui-info--icon {
		width: 32rpx;
		height: 32rpx;
	}

	.tui-avatar {
		width: 90rpx;
		height: 90rpx;
		border-radius: 50%;
		margin-right: 20rpx;
	}

	.tui-menu--item {
		width: 72rpx;
		height: 72rpx;
		background: #FFFFFF;
		box-shadow: 0 18rpx 36rpx 0 rgba(103, 103, 103, 0.05);
		border-radius: 20rpx;
		display: flex;
		align-items: center;
		justify-content: center;
		flex-shrink: 0;
		margin-left: 30rpx;
	}

	.tui-menu--icon {
		width: 36rpx;
		height: 36rpx;
	}

	.tui-menu--box {
		display: inline-flex;
		align-items: center;
	}

	.tui-position__box {
		display: flex;
		align-items: center;
		padding-top: 20rpx;
	}

	.tui-tababr__box {
		position: fixed;
		left: 0;
		bottom: 0;
		z-index: 10;
		width: 100%;
		background-color: #fff;
		padding: 20rpx 44rpx;
		box-sizing: border-box;
	}

	.tui-safe__area {
		width: 100%;
		padding-bottom: env(safe-area-inset-bottom);
	}

	.tui-map--box {
		width: 100%;
		margin-top: 28rpx;
		position: relative;
	}

	.tui-map {
		width: 100%;
		height: 300rpx;
		border-radius: 20rpx;
	}

	.tui-map--center {
		display: inline-flex;
		align-items: center;
		padding: 20rpx 32rpx;
		background-color: #fff;
		border-radius: 30px;
		box-shadow: 0 8rpx 24rpx 0 rgba(33, 33, 33, 0.1);
		position: absolute;
		left: 50%;
		top: 50%;
		transform: translate(-50%, -50%);
		z-index: 2;
	}

	.tui-icon--posi {
		width: 28rpx;
		height: 32rpx;
		margin-right: 8rpx;
	}

	.tui-nav--map {
		width: 72rpx;
		height: 72rpx;
		position: absolute;
		right: 24rpx;
		top: 24rpx;
		z-index: 2;
	}
</style>