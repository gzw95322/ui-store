export default {
	houseType: ['住房', '公寓', '办公楼', '酒店'],
	houseNum: ['1', '2', '3', '4', '5+'],
	toiletNum: ['1', '2', '3', '4', '5+'],
	scoreNum: [5, 4, 3, 2, 1]
}