<template>
	<view class="tui-container">
		<t-header title="筛选"></t-header>
		<view class="tui-outer__box">
			<tui-text padding="0 0 24rpx" text="房屋类型" font-weight="600" size="32"></tui-text>
			<tui-data-checkbox radius="20rpx" multiple defaultBorderColor="#DADADA" color="#818194"
				active-bg-color="#EE9C40" active-color="#fff" :options="houseType"></tui-data-checkbox>
			<tui-text padding="56rpx 0 24rpx" text="价格范围" font-weight="600" size="32"></tui-text>
			<tui-slider valueFormat="￥value" showValue position="bottom" blockColor="#EE9C40"
				blockBorder="2px solid #fff" boxColor="transparent" :valueSize="26" :width="width" :height="2" section
				:max="10000" :endValue="10000"></tui-slider>
			<tui-text padding="120rpx 0 24rpx" text="房间" font-weight="600" size="32"></tui-text>
			<tui-data-checkbox radius="20rpx" padding="20rpx 36rpx" multiple defaultBorderColor="#DADADA"
				color="#818194" active-bg-color="#EE9C40" active-color="#fff" :options="houseNum"></tui-data-checkbox>
			<tui-text padding="56rpx 0 24rpx" text="卫生间" font-weight="600" size="32"></tui-text>
			<tui-data-checkbox radius="20rpx" padding="20rpx 36rpx" multiple defaultBorderColor="#DADADA"
				color="#818194" active-bg-color="#EE9C40" active-color="#fff" :options="toiletNum"></tui-data-checkbox>
			<tui-text padding="56rpx 0 24rpx" text="面积" font-weight="600" size="32"></tui-text>
			<tui-slider valueFormat="value㎡" showValue position="bottom" blockColor="#EE9C40"
				blockBorder="2px solid #fff" boxColor="transparent" :valueSize="26" :width="width" :height="2" section
				:max="200" :endValue="200"></tui-slider>
			<tui-text padding="120rpx 0 24rpx" text="评分" font-weight="600" size="32"></tui-text>
			<tui-radio-group>
				<view class="tui-radio--item" v-for="(item,index) in scoreNum" :key="index">
					<tui-label>
						<view class="tui-flex__between">
							<tui-grade :quantity="item" :score="item" disabled :size="14" active="#FBBC04"></tui-grade>
							<tui-radio></tui-radio>
						</view>
					</tui-label>
				</view>
			</tui-radio-group>
			<view class="tui-btn--box">
				<tui-form-button @click="btnConfirm">提交筛选</tui-form-button>
			</view>
		</view>
	</view>
</template>

<script>
	import data from './index.js'
	export default {
		data() {
			const sys = uni.getSystemInfoSync()
			const width = sys.windowWidth - uni.upx2px(90)
			return {
				//类型
				houseType: data.houseType,
				//房间数
				houseNum: data.houseNum,
				//卫生间数
				toiletNum: data.toiletNum,
				//评分
				scoreNum: data.scoreNum,
				width,
				page: 0
			}
		},
		onLoad(e) {
			this.page = e.page || 0
		},
		methods: {

			btnConfirm() {
				if (this.page) {
					uni.navigateBack()
				} else {
					this.tui.href('/pages/renting/search/search')
				}
			}
		}
	}
</script>

<style>
	.tui-outer__box {
		padding: 56rpx 44rpx;
		box-sizing: border-box;
	}

	.tui-radio--item {
		margin-bottom: 36rpx;
	}

	.tui-btn--box {
		width: 100%;
		padding: 32rpx 0;
	}
</style>