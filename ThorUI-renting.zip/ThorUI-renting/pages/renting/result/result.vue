<template>
	<view class="tui-container">
		<t-header></t-header>
		<view class="tui-outer__box">
			<tui-msg :type="type" :title="title" :desc="desc" :color="color">
				<!--自定义内容部分-->
				<tui-form-button btn-size="medium" margin="50rpx auto 0" @click="home">返回首页</tui-form-button>
				<tui-form-button btn-size="medium" background="#f8f8f8" color="#1E1F20" margin="32rpx auto" @click="my">个人中心</tui-form-button>
			</tui-msg>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				//warn
				type: 'success',
				title: '支付成功',
				//您的付款失败，请再试一次或更改其他付款方式
				desc: '您已成功付款，请安心享受您的房间',
				//#FF4B4F
				color:'#07c160'
			}
		},
		methods: {
			home(){
				this.tui.href('/pages/tabbar/index/index',true)
			},
			my(){
				this.tui.href('/pages/tabbar/my/my',true)
			}
		}
	}
</script>

<style>
.tui-outer__box{
	width: 100%;
	padding: 0 88rpx;
}
</style>
