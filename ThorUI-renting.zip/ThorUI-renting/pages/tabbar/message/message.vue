<template>
	<view class="tui-container">
		<t-header title="消息" :is-back="false"></t-header>
		<view class="tui-outer__box">
			<tui-slide-view @click="handleClick(index)" v-for="(item,index) in 4" :key="index" :buttons="button"
				width="80rpx" height="80rpx" radius="20rpx" padding="0">
				<tui-list-cell background-color="transparent" :line-right="44" @click="chat">
					<view class="tui-msg--item">
						<image :src="`/static/images/renting/avatar_0${index || 3}.png`" class="tui-avatar"></image>
						<view class="tui-content">
							<tui-text padding="0 0 6rpx" text="李大兵" size="32" font-weight="600"></tui-text>
							<tui-overflow-hidden :lineClamp="1" size="26"
								color="#818194">{{index===0?'是的，当然可以，明天您有时间可以明天您有时间可以':'物业质量很好'}}</tui-overflow-hidden>
						</view>
						<view class="tui-time--box">
							<tui-text text="13:25" size="24" color="#818194" unShrink></tui-text>
							<view class="tui-badge" v-if="index<2">
								<view class="tui-badge--scale">{{index+1}}</view>
							</view>
						</view>
					</view>
				</tui-list-cell>
			</tui-slide-view>
			
			<!--无数据时显示-->
			<tui-no-data v-if="false" imgUrl="/static/images/common/img_none.png" :fixed="false" margin-top="300">
				暂无消息
			</tui-no-data>
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				button: [{
					src: '/static/images/renting/icon_del.png',
					width: '32rpx',
					height: '36rpx',
					background: '#FF4B4F'
				}]
			}
		},
		methods: {
			handleClick(index) {
				console.log(index)
				this.tui.toast(`删除：${index}`)
			},
			chat(){
				this.tui.href('/pages/renting/chat/chat')
			}
		}
	}
</script>

<style>
	.tui-outer__box {
		padding: 50rpx 0;
	}

	.tui-msg--item {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	.tui-avatar {
		width: 90rpx;
		height: 90rpx;
		border-radius: 50%;
		flex-shrink: 0;
		margin-right: 20rpx;
	}

	.tui-content {
		flex: 1;
		overflow: hidden;
	}

	.tui-time--box {
		min-width: 80rpx;
		height: 90rpx;
		flex-shrink: 0;
		padding-left: 16rpx;
		position: relative;
		display: flex;
		flex-direction: column;
		align-items: flex-end;

	}

	.tui-badge {
		position: absolute;
		bottom: 12rpx;
		right: 0;
		padding: 4rpx 10rpx;
		height: 36rpx;
		min-width: 36rpx;
		border-radius: 40rpx;
		background-color: #FF4B4F;
		box-sizing: border-box;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.tui-badge--scale {
		font-size: 25rpx;
		color: #fff;
		transform: scale(.8);
	}
</style>