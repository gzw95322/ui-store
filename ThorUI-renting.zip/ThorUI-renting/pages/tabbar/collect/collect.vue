<template>
	<view class="tui-container">
		<t-header :is-back="false" title="收藏" descr="共 12 个收藏房源"></t-header>
		<view class="tui-outer__box">
			<tui-dropdown-list :show="show" :height="304" :top="72">
				<template v-slot:selectionbox>
					<view class="tui-selection tui-bg" @tap.stop="showFilter">
						<text>排序方式：</text>
						<text>{{active}}</text>
						<view class="tui-icon__box" :class="{'tui-active':show}">
							<tui-icon name="arrowdown" color="#fff" unit="rpx"></tui-icon>
						</view>
					</view>
				</template>
				<template v-slot:dropdownbox>
					<view class="tui-dropdown--list tui-bg">
						<view class="tui-item" v-for="(item,index) in sorts" :key="index" @tap="itemClick(item,index)">
							{{item}}
						</view>
					</view>
				</template>
			</tui-dropdown-list>

			<view class="tui-card--list">
				<tui-slide-view marginTop="32" @click="handleClick(index)" v-for="(item,index) in 10" :key="index"
					:buttons="button" width="80rpx" height="80rpx" radius="20rpx" padding="0">
					<t-list-cell :bottom="0" @click="href"></t-list-cell>
				</tui-slide-view>

				<!-- <tui-loadmore index="3" type="primary"></tui-loadmore> -->
				<tui-divider background-color="#FEFBF7" width="50%">已全部加载</tui-divider>
			</view>
			<!--无数据时显示-->
			<tui-no-data v-if="false" imgUrl="/static/images/common/img_none.png" :fixed="false" margin-top="300">
				您还没有收藏房源哦
			</tui-no-data>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				show: false,
				active: '价格',
				sorts: ['价格', '面积', '评分', '位置'],
				button: [{
					src: '/static/images/renting/icon_del.png',
					width: '32rpx',
					height: '36rpx',
					background: '#FF4B4F'
				}]
			}
		},
		methods: {
			showFilter() {
				this.show = !this.show
			},
			itemClick(item, index) {
				this.active = item;
				this.show = false
			},
			handleClick(index) {
				console.log(index)
				this.tui.toast(`删除：${index}`)
			},
			href(){
				this.tui.href('/pages/renting/detail/detail')
			}
		}
	}
</script>

<style>
	.tui-outer__box {
		padding: 50rpx 44rpx;
	}

	.tui-selection {
		width: 294rpx;
		height: 68rpx;
		border-radius: 20rpx;
		/* #ifdef H5 */
		cursor: pointer;
		/* #endif */
		color: #fff;
		font-size: 26rpx;
		position: relative;
		display: flex;
		align-items: center;
		padding: 0 32rpx;
		box-sizing: border-box;
	}

	.tui-icon__box {
		position: absolute;
		right: 24rpx;
		top: 50%;
		transform: translateY(-50%);
		transition: transform 0.15s linear;
	}

	.tui-active {
		transform: translateY(-50%) rotate(180deg);
	}

	.tui-dropdown--list {
		width: 294rpx;
		height: 304rpx;
		border-radius: 20rpx;
		display: flex;
		flex-direction: column;
		overflow: hidden;
	}

	.tui-item {
		width: 100%;
		flex: 1;
		color: #fff;
		font-size: 26rpx;
		display: flex;
		align-items: center;
		padding: 0 32rpx;
		box-sizing: border-box;
		/* #ifdef H5 */
		cursor: pointer;
		/* #endif */
	}

	.tui-item:active {
		background-color: #1B1A2D;
	}

	.tui-card--list {
		padding-top: 12rpx;
	}
</style>