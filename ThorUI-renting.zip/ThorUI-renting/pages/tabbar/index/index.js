export default {
	nav: [{
		icon: 'housing',
		text: '住房'
	}, {
		icon: 'apartment',
		text: '公寓'
	}, {
		icon: 'office',
		text: '办公楼'
	}, {
		icon: 'hotel',
		text: '酒店'
	}]
}