<template>
	<view class="tui-container">
		<t-header title="首页" descr="住潮房，与我们一起寻找最合适的住处" :is-back="false"></t-header>
		<view class="tui-page__body">
			<view class="tui-header--box">
				<view class="tui-flex__between">
					<view class="tui-search--bar tui-align__center" @tap="href('/pages/renting/search/search')">
						<image class="tui-icon--search" src="/static/images/common/icon_search.png"></image>
						<tui-text text="输入关键字…" color="#818194" size="26"></tui-text>
					</view>
					<view class="tui-filter--bar tui-bg tui-flex__center" @tap="href('/pages/renting/screen/screen')">
						<image class="tui-icon--filter" src="/static/images/common/icon_filter.png"></image>
					</view>
				</view>
				<view class="tui-nav--box tui-flex__between">
					<view class="tui-nav--item tui-active" v-for="(item,index) in nav" :key="index" @tap="href('/pages/renting/search/search')">
						<image class="tui-icon--nav" :src="`/static/images/index/icon_${item.icon}.png`"></image>
						<tui-text :text="item.text" color="#FFE9FA" size="24"></tui-text>
					</view>

				</view>
			</view>
			<view class="tui-outer__box">
				<view class="tui-flex__between tui-tit">
					<tui-text text="猜你喜欢" size="36" font-weight="600"></tui-text>
					<tui-text text="查看全部" size="26" type="primary" highlight @click="href('/pages/renting/search/search')"></tui-text>
				</view>

				<swiper class="tui-swiper__box" circular next-margin="128rpx">
					<swiper-item  v-for="(item,index) in arr" :key="index">
						<t-list-item @click="href('/pages/renting/detail/detail')"></t-list-item>
					</swiper-item>
				</swiper>

				<view class="tui-tit">
					<tui-text text="新上" size="36" font-weight="600"></tui-text>
				</view>

				<view class="tui-new__box">
					<t-list-cell v-for="(item,index) in arr" :key="index" @click="href('/pages/renting/detail/detail')"></t-list-cell>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import data from './index.js'
	export default {
		data() {
			return {
				nav: data.nav,
				arr:['','','']
			}
		},
		methods: {
			href(page) {
				this.tui.href(page)
			}
		}
	}
</script>

<style>
	.tui-header--box {
		width: 100%;
		padding: 50rpx 44rpx 0;
		/* #ifndef H5 */
		margin-top: 208rpx;
		padding-top: 44rpx;
		/* #endif */
		box-sizing: border-box;

	}

	.tui-page__body {
		position: relative;
		z-index: 4;
	}

	.tui-outer__box {
		margin-top: 0rpx;
	}

	.tui-search--bar {
		height: 96rpx;
		background-color: #fff;
		border-radius: 30rpx;
		flex: 1;
		padding-left: 42rpx;
		box-sizing: border-box;
		/* #ifdef H5 */
		cursor: pointer;
		/* #endif */
	}

	.tui-icon--search {
		width: 44rpx;
		height: 44rpx;
		margin-right: 20rpx;
	}

	.tui-filter--bar {
		width: 96rpx;
		height: 96rpx;
		border-radius: 30rpx;
		flex-shrink: 0;
		margin-left: 40rpx;
		/* #ifdef H5 */
		cursor: pointer;
		/* #endif */
	}

	.tui-icon--filter {
		width: 36rpx;
		height: 36rpx;
	}

	.tui-nav--box {
		padding: 50rpx 0;
	}

	.tui-nav--item {
		width: 128rpx;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		background: rgba(199, 125, 40, .6);
		box-shadow: inset 4rpx 10rpx 36rpx 0 rgba(161, 161, 161, 0.05);
		border-radius: 30rpx;
		padding: 24rpx 0;
		box-sizing: border-box;
	}

	.tui-icon--nav {
		width: 66rpx;
		height: 66rpx;
		margin-bottom: 8rpx;
	}

	.tui-tit {
		width: 100%;
		padding: 50rpx 44rpx 30rpx;
		box-sizing: border-box;
	}

	.tui-swiper__box {
		padding-left: 44rpx;
		height: 536rpx;
		box-sizing: border-box;
	}

	.tui-new__box {
		width: 100%;
		padding: 0 44rpx 32rpx;
		box-sizing: border-box;
	}
</style>