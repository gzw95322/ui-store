<template>
	<view class="tui-container">
		<t-header :is-back="false" :is-fixed="false" max-height="680">
			<view class="tui-user__info">
				<view class="tui-avatar__box">
					<tui-lazyload-img width="218rpx" height="218rpx" radius="50%"
						:src="userAvatar || '/static/images/renting/avatar_01.png'"></tui-lazyload-img>
					<image src="/static/images/my/icon_upload_3x.png" class="tui-upload__img" @tap.stop="changeAvatar">
					</image>
				</view>
				<tui-text block text="邹小猫" :size="40" color="#fff" font-weight="600" padding="48rpx 0 0"></tui-text>
			</view>
		</t-header>
		<view class="tui-outer__box">
			<tui-tab :tabs="tabs" scroll leftGap="44" scale="1.2" color="#828294" selectedColor="#1F244B"
				backgroundColor="transparent" bold @change="change"></tui-tab>
			<view class="tui-set__box" v-if="active===0">
				<tui-list-cell arrow arrow-right="40" radius="30" unlined margin-top="32" v-for="(item,index) in setList" :key="index"
					@click="href(index)">
					<view class="tui-align__center">
						<image :src="`/static/images/my/${item.icon}`" class="tui-set--icon"></image>
						<tui-text :text="item.text"></tui-text>
					</view>
				</tui-list-cell>
			</view>
			<view class="tui-list__view" v-else>
				<t-record top="32" v-for="(item,index) in 2" :key="index" @click="detail" @scoring="scoring"></t-record>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		mapState
	} from 'vuex';
	export default {
		computed: mapState(['userAvatar']),
		data() {
			return {
				active: 0,
				tabs: ['设置', '租赁记录'],
				setList: [{
					text: '账号信息',
					icon: 'icon_account.png'
				}, {
					text: '我的钱包',
					icon: 'icon_pay.png'
				}, {
					text: '消息通知',
					icon: 'icon_notice.png'
				}, {
					text: '账号安全',
					icon: 'icon_safe.png'
				}, {
					text: '关于我们',
					icon: 'icon_info.png'
				}]
			}
		},
		methods: {
			change(e) {
				console.log(e)
				this.active = e.index
			},
			changeAvatar() {
				uni.chooseImage({
					count: 1,
					sizeType: ['original', 'compressed'],
					sourceType: ['album', 'camera'],
					success: res => {
						const tempFilePaths = res.tempFilePaths[0];
						this.tui.href('/pages/my/upload/upload?src=' + tempFilePaths);
					}
				});
			},
			href(index) {
				let url = '/pages/my/account/account'
				if (index === 1) {
					url = '/pages/my/wallet/wallet'
				} else if (index === 2) {
					url = '/pages/my/notice/notice'
				} else if (index === 3) {
					url = '/pages/my/security/security'
				} else if (index === 4) {
					url = '/pages/my/about/about'
				}
				this.tui.href(url)
			},
			scoring(e){
				this.tui.href('/pages/my/scoring/scoring')
			},
			detail(e){
				this.tui.href('/pages/renting/detail/detail')
			}
		}
	}
</script>

<style>
	.tui-outer__box {
		min-height: 880rpx;
		padding: 32rpx 44rpx;
		/* #ifdef H5 */
		margin-top: -208rpx;
		/* #endif */
		/* #ifndef H5 */
		margin-top: -168rpx;
		/* #endif */
		position: relative;
		z-index: 1;
	}

	.tui-user__info {
		width: 100%;
		position: absolute;
		z-index: 12;
		left: 0;
		/* #ifndef H5 */
		top: 124rpx;
		/* #endif */
		/* #ifdef H5 */
		top: 88rpx;
		/* #endif */
		display: flex;
		justify-content: center;
		align-items: center;
		flex-direction: column;
	}

	.tui-avatar__box {
		position: relative;
	}

	.tui-upload__img {
		width: 90rpx;
		height: 90rpx;
		position: absolute;
		bottom: 0;
		right: 0;
		z-index: 2;
		/* #ifdef H5 */
		cursor: pointer;
		/* #endif */
	}

	.tui-set__box,
	.tui-list__view {
		padding-top: 18rpx;
	}

	.tui-set--icon {
		width: 44rpx;
		height: 44rpx;
		flex-shrink: 0;
		margin-right: 28rpx;
	}
</style>