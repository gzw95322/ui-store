<template>
	<view class="tui-container">
		<t-header title="账号安全"></t-header>
		<view class="tui-outer__box">
			<tui-list-cell :hover="false" unlined radius="30" margin-bottom="32">
				<view class="tui-flex__between">
					<tui-text text="同意隐私政策"></tui-text>
					<tui-switch checked></tui-switch>
				</view>
			</tui-list-cell>
			<tui-list-cell :hover="false" unlined radius="30" margin-bottom="32">
				<view class="tui-flex__between">
					<tui-text text="个性推荐功能"></tui-text>
					<tui-switch checked></tui-switch>
				</view>
			</tui-list-cell>
			<tui-text text="了解个性化推荐功能的工作原理" color="#EE9C40" size="24" highlight @click="protocol"></tui-text>
			<tui-text :text="descr" size="24" padding="24rpx 0 0"></tui-text>
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				descr: '当您开启个性化推荐功能后，我们会根据您主动提供的基础信息找房条件和您授权我们自动采集的位置信息、服务日志、设备标识符，利用算法技术在推荐区域向您推荐您可能感兴趣的房源。当您关闭个性化推荐功能后，我们将立即停止提供算法推荐服务(推荐区域仍然存在，但其中的内容为系统默认排序，与您的个人信息无关)。'
			}
		},
		methods: {
			protocol() {
				this.tui.href('/pages/common/protocol/protocol')
			}
		}
	}
</script>

<style>
	.tui-outer__box {
		padding: 50rpx 44rpx;
	}
</style>