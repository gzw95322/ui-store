<template>
	<view class="tui-container">
		<t-header title="我的钱包"></t-header>
		<view class="tui-outer__box">
			<tui-text text="欢迎来到ThorUI钱包" size="40" fontWeight="600" color="#1F244B"></tui-text>
			<view class="tui-card__box">
				<tui-text text="余额（元）" size="24"></tui-text>
				<tui-text text="0.00" size="52" font-weight="600" padding="8rpx 0 0"></tui-text>
				<image class="tui-img__amount" src="/static/images/my/bg_balance_amount.png" mode="widthFix"></image>
			</view>
			<view class="tui-list">
				<view class="tui-item" @tap="bankcard">
					<view class="tui-icon__box tui-flex__center tui-active">
						<image class="tui-icon" src="/static/images/my/icon_bankcard.png"></image>
					</view>
					<tui-text text="银行卡" size="24"></tui-text>
				</view>
				<view class="tui-item" @tap="bill">
					<view class="tui-icon__box tui-flex__center tui-bg tui-active">
						<image class="tui-icon" src="/static/images/my/icon_bill.png"></image>
					</view>
					<tui-text text="账单" size="24"></tui-text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {
            bankcard(){
				this.tui.href('/pages/my/bankCard/bankCard')
			},
			bill(){
				this.tui.href('/pages/my/bill/bill')
			}
		}
	}
</script>

<style>
	.tui-outer__box {
		padding: 50rpx 44rpx;
	}

	.tui-card__box {
		width: 100%;
		height: 200rpx;
		background-color: #fff;
		border-radius: 30rpx;
		margin-top: 32rpx;
		padding: 0 32rpx;
		display: flex;
		justify-content: center;
		flex-direction: column;
		box-sizing: border-box;
		position: relative;
	}
	.tui-img__amount{
		position: absolute;
		bottom: 0;
		right: 0;
		width: 200rpx;
		height: 160rpx;
		z-index: 2;
	}
	.tui-list{
		width: 100%;
		padding: 50rpx 44rpx;
		box-sizing: border-box;
	}
	.tui-item{
		display: inline-flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		margin-right: 96rpx;
	}
	.tui-icon__box{
		width: 96rpx;
		height: 96rpx;
		border-radius: 30rpx;
		background: #FFAB4B;
		margin-bottom: 12rpx;
	}
	.tui-icon{
		width: 52rpx;
		height: 52rpx;
	}
</style>