<template>
	<view class="tui-container">
		<t-header title="添加银行卡"></t-header>
		<view class="tui-outer__box">
			<!--输入完卡号后如果需要识别银行信息则将下面文字替换为，如： 中国农业银行 储蓄卡 -->
			<tui-text padding="16rpx 0 60rpx" size="30" :text="descr" color="#555568" block></tui-text>
			<tui-text padding="0 0 20rpx" fontWeight="600" text="卡号*" color="#555568"></tui-text>
			<tui-input border-color="#979BB5" input-border color="#1F244B" placeholder="请输入银行卡号"
				v-model="cardno"></tui-input>
			<tui-text padding="40rpx 0 20rpx" fontWeight="600" text="姓名*" color="#555568"></tui-text>
			<tui-input border-color="#979BB5" input-border color="#1F244B" placeholder="请输入持卡人姓名"></tui-input>
			<tui-text padding="40rpx 0 20rpx" fontWeight="600" text="证件类型*" color="#555568"></tui-text>
			<tui-input disabled border-color="#979BB5" input-border color="#1F244B" placeholder="请选择证件类型"
				@click="selectToggle(true)" :value="text">
				<template v-slot:right>
					<tui-icon name="arrowright" unit="rpx" size="36"></tui-icon>
				</template>
			</tui-input>
			<tui-text padding="40rpx 0 20rpx" fontWeight="600" text="证件号*" color="#555568"></tui-text>
			<tui-input border-color="#979BB5" input-border placeholder="请输入证件号码"></tui-input>
			<tui-text padding="40rpx 0 20rpx" fontWeight="600" text="手机号*" color="#555568"></tui-text>
			<tui-input border-color="#979BB5" input-border placeholder="请输入手机号码"></tui-input>
			<tui-text text="* 请填写银行预留手机号" size="24" color="#818194" padding="16rpx 0 0 32rpx"></tui-text>

			<view class="tui-btn__box">
				<tui-form-button margin="50rpx 0 40rpx">确定</tui-form-button>
			</view>
		</view>
		<tui-select :height="400" :list="list" :show="show" iconBgColor="transparent" @close="selectToggle(false)"
			@confirm="changeType"></tui-select>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				descr: '请输入信息以添加银行卡',
				cardno: '',
				show: false,
				text: '',
				list: ['身份证', '港澳居民来往内地通行证', '台湾居民来往大陆通行证', '护照'],
			}
		},
		watch: {
			cardno(val) {
				//请自行实现校验，此处仅模拟逻辑，可以等输入框失去焦点再去验证
				if (val && val.length > 15) {
					this.descr = '中国农业银行 储蓄卡'
				} else {
					this.descr = '请输入信息以添加银行卡'
				}
			}
		},
		methods: {
			changeType(e) {
				console.log(e)
				const index = e.index;
				this.text = e.options
				//关闭选择弹框
				this.selectToggle(false)
			},
			selectToggle(show) {
				this.show = show
			}
		}
	}
</script>

<style>
	.tui-outer__box {
		padding: 68rpx 44rpx;
		box-sizing: border-box;
	}
</style>