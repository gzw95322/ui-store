<template>
	<view class="tui-container">
		<t-header title="账号信息"></t-header>
		<view class="tui-outer__box">
			<tui-list-cell unlined arrow arrow-right="40" radius="30" @click="changeAvatar">
				<view class="tui-flex__between tui-pr--40">
					<tui-text text="头像"></tui-text>
					<tui-lazyload-img width="80rpx" height="80rpx" radius="50%"
						:src="userAvatar || '/static/images/renting/avatar_01.png'"></tui-lazyload-img>
				</view>
			</tui-list-cell>
			<tui-list-cell marginTop="32" arrow-right="40" unlined radius="30" arrow @click="changeNickName">
				<view class="tui-flex__between tui-pr--40">
					<tui-text text="昵称"></tui-text>
					<tui-text size="26" color="#818194" text="邹小猫"></tui-text>
				</view>
			</tui-list-cell>
			<tui-list-cell marginTop="32" unlined radius="30" :hover="false">
				<view class="tui-flex__between">
					<tui-text text="手机号"></tui-text>
					<tui-text size="26" color="#818194" text="138***9900"></tui-text>
				</view>
			</tui-list-cell>
			<tui-list-cell marginTop="32" unlined radius="30" :hover="false">
				<view class="tui-flex__between">
					<tui-text text="邮箱"></tui-text>
					<tui-text size="26" color="#818194" text="1088**@qq.com"></tui-text>
				</view>
			</tui-list-cell>

			<view class="tui-btn__box">
				<tui-form-button @click="btnLogout">退出登录</tui-form-button>
			</view>
		</view>
		<tui-actionsheet :itemList="itemList" :show="show" tips="退出后将会清除登录信息，确认退出吗？" @click="logout"
			@cancel="cancel"></tui-actionsheet>
	</view>
</template>

<script>
	import {
		mapState
	} from 'vuex';
	export default {
		computed: mapState(['userAvatar']),
		data() {
			return {
				itemList: [{
					text: "退出登录",
					color: "#FF4B4F"
				}],
				show: false
			}
		},
		methods: {
			changeAvatar() {
				uni.chooseImage({
					count: 1,
					sizeType: ['original', 'compressed'],
					sourceType: ['album', 'camera'],
					success: res => {
						const tempFilePaths = res.tempFilePaths[0];
						this.tui.href('/pages/my/upload/upload?src=' + tempFilePaths);
					}
				});
			},
			changeNickName() {
				this.tui.href('/pages/my/nickname/nickname')
			},
			btnLogout() {
				this.show = true;
			},
			cancel() {
				this.show = false;
			},
			logout(e) {
				uni.reLaunch({
					url:'/pages/common/login/login'
				})
			}
		}
	}
</script>

<style>
	.tui-outer__box {
		padding: 50rpx 40rpx;
	}

	.tui-pr--40 {
		padding-right: 40rpx;
		box-sizing: border-box;
	}

	.tui-btn__box {
		width: 100%;
		padding-top: 64rpx;
	}
</style>