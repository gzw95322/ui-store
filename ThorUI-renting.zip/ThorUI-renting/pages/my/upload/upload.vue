<template>
	<view class="container">
		<!-- #ifndef H5 -->
		<t-header :is-bg="false" background="transparent"></t-header>
		<!-- #endif -->
		<!--不支持wxs的平台可使用tui-image-cropper组件-->
		<tui-picture-cropper :lockRatio="true" :imageUrl="imageUrl" @ready="ready" @cropper="cropper"></tui-picture-cropper>
	</view>
</template>

<script>
	import {
		mapMutations
	} from 'vuex';
	export default {
		data() {
			return {
				src: '',
				imageUrl: '',
				isRound:true
			};
		},
		onLoad(options) {
			this.src = options.src || '';
			this.src &&
				uni.showLoading({
					title: '请稍候...',
					mask: true
				});
		},
		methods: {
			...mapMutations(['setAvatar']),
			ready() {
				this.imageUrl = this.src;
			},
			cropper(e) {
				this.setAvatar({
					avatar: e.url
				})
				this.tui.toast('头像更换成功')
				setTimeout(() => {
					uni.navigateBack()
				}, 300)
			}
		}
	};
</script>
