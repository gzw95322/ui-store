<template>
	<view class="tui-container">
		<t-header title="打分评价"></t-header>
		<view class="tui-outer__box">
			<view class="tui-info__box tui tui-align__center">
				<view class="tui-house__box tui-flex__center">
					<image class="tui-house" src="/static/images/renting/icon_house.png"></image>
				</view>
				<view class="tui-flex--1">
					<tui-overflow-hidden bold :lineClamp="1" color="#1F244B">华润置地.有巢公寓</tui-overflow-hidden>
					<tui-text text="回龙观·远洋天地二区" size="24" color="#818194"></tui-text>
				</view>
				<view class="tui-score__box">
					<tui-icon name="star-fill" size="26" unit="rpx" color="#FBBC04"></tui-icon>
					<text class="tui-score">4.6</text>
				</view>
			</view>
			<tui-text padding="40rpx 0 20rpx" fontWeight="600" text="评分*" size="28" color="#555568" block></tui-text>
			<tui-grade :width="24" active="#FBBC04" :score="score" @change="change"></tui-grade>
			<view class="tui-btn__box">
				<tui-form-button @click="submit">提交</tui-form-button>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				score: 0
			}
		},
		methods: {
			change(e) {
				this.score = e.score
			},
			submit(){
				this.tui.toast('提交成功！')
			}
		}
	}
</script>

<style>
	.tui-outer__box {
		padding: 50rpx 44rpx;
	}

	.tui-info__box {
		background: #FFFFFF;
		border-radius: 20rpx;
		padding: 28rpx;
		box-sizing: border-box;
		position: relative;
	}

	.tui-house__box {
		width: 126rpx;
		height: 126rpx;
		background: rgba(247, 178, 99, .1);
		border-radius: 20rpx;
		margin-right: 24rpx;
		flex-shrink: 0;
	}

	.tui-house {
		width: 76rpx;
		height: 76rpx;
	}

	.tui-score__box {
		position: absolute;
		right: 24rpx;
		top: 12rpx;
		font-size: 24rpx;
		line-height: 28rpx;
		color: #555568;
		padding: 6rpx 0;
		z-index: 2;
	}

	.tui-score {
		zoom: .9;
		padding-left: 8rpx;
		line-height: 24rpx;
	}
	.tui-btn__box{
		padding-top: 96rpx;
	}
</style>