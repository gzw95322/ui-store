<template>
	<view class="tui-container">
		<t-header max-height="400"></t-header>
		<view class="tui-outer__box">
			<view class="tui-logo__box">
				<tui-lazyload-img src="/static/images/logo.jpeg" radius="30rpx" width="200rpx"
					height="200rpx"></tui-lazyload-img>
				<tui-text text="ThorUI 让家更美好" size="32" block padding="32rpx 0 12rpx"></tui-text>
				<tui-text text="Version 1.0.0" size="28"></tui-text>
			</view>
			<view class="tui-descr__box">
				<tui-text text="ThorUI租房为租房者提供房源信息搜索、浏览等功能,让您的租房交易更加便捷。" size="28" color="#818194"></tui-text>
				<tui-text text="官方网站：www.thorui.cn" block padding="24rpx 0 4rpx" size="28" color="#A7A7A7"></tui-text>
				<tui-text text="客服电话：10108100" size="28" color="#A7A7A7"></tui-text>
			</view>
		</view>
		<tui-footer copyright="Copyright © 2019-2023 Thor UI."></tui-footer>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {

		}
	}
</script>

<style>
	.tui-outer__box {
		min-height: 880rpx;
	}

	.tui-logo__box {
		position: fixed;
		left: 50%;
		top: 50%;
		transform: translate(-50%, -50%);
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		margin-top: -160rpx;
		z-index: 11;
	}

	.tui-descr__box {
		position: fixed;
		z-index: 11;
		left: 44rpx;
		right: 44rpx;
		bottom: 240rpx;
	}
</style>