<template>
	<view class="tui-container">
		<t-header title="消息通知"></t-header>
		<view class="tui-outer__box">
			<tui-list-cell :hover="false" unlined radius="30" margin-bottom="32">
				<view class="tui-flex__between">
					<tui-text text="推送通知"></tui-text>
					<tui-switch checked></tui-switch>
				</view>
			</tui-list-cell>
			<tui-list-cell :hover="false" unlined radius="30" margin-bottom="32">
				<view class="tui-flex__between">
					<tui-text text="私聊我"></tui-text>
					<tui-switch></tui-switch>
				</view>
			</tui-list-cell>
			<tui-list-cell :hover="false" unlined radius="30" margin-bottom="32">
				<view class="tui-flex__between">
					<tui-text text="支付成功通知"></tui-text>
					<tui-switch ></tui-switch>
				</view>
			</tui-list-cell>
			<tui-list-cell :hover="false" unlined radius="30" margin-bottom="32">
				<view class="tui-flex__between">
					<tui-text text="系统通知"></tui-text>
					<tui-switch></tui-switch>
				</view>
			</tui-list-cell>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>
.tui-outer__box{
	padding: 50rpx 44rpx;
}
</style>
