<template>
	<view class="tui-container">
		<t-header title="修改昵称"></t-header>
		<view class="tui-outer__box">
			<tui-text padding="0 0 20rpx" fontWeight="600" text="昵称" color="#555568" block></tui-text>
			<tui-input border-color="#979BB5" input-border placeholder="请输入昵称"></tui-input>
			<view class="tui-btn__box">
				<tui-form-button margin="50rpx 0 40rpx">确定</tui-form-button>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {

		}
	}
</script>

<style>
	.tui-outer__box {
		padding: 68rpx 44rpx;
		box-sizing: border-box;
	}
</style>