export default {
	recordsList: [{
		loading: false,
		pullUpOn: true,
		pageIndex: 1,
		noData: false,
		data: []
	}, {
		loading: false,
		pullUpOn: true,
		pageIndex: 1,
		noData: false,
		data: []
	}, {
		loading: false,
		pullUpOn: true,
		pageIndex: 1,
		noData: false,
		data: []
	}],
	requestData: [{
		type: 1, //1-收入 2-支出
		title: "退房收入",
		time: "2019-05-12 11:53:06",
		balance: '3006.50',
		amount: '2000.00'
	}, {
		type: 1,
		title: "退房收入",
		time: "2019-05-12 11:53:06",
		balance: '3006.50',
		amount: '2000.00'
	}, {
		type: 2,
		title: "租房支出",
		time: "2019-05-12 11:53:06",
		balance: '4206.50',
		amount: '2500.00'
	}, {
		type: 1,
		title: "退房收入",
		time: "2019-05-12 11:53:06",
		balance: '3006.50',
		amount: '2000.00'
	}, {
		type: 1,
		title: "退房收入",
		time: "2019-05-12 11:53:06",
		balance: '3006.50',
		amount: '2000.00'
	}, {
		type: 2,
		title: "租房支出",
		time: "2019-05-12 11:53:06",
		balance: '4206.50',
		amount: '2500.00'
	}, {
		type: 2,
		title: "租房支出",
		time: "2019-05-12 11:53:06",
		balance: '4206.50',
		amount: '2500.00'
	}, {
		type: 1,
		title: "退房收入",
		time: "2019-05-12 11:53:06",
		balance: '3006.50',
		amount: '2000.00'
	}, {
		type: 1,
		title: "退房收入",
		time: "2019-05-12 11:53:06",
		balance: '3006.50',
		amount: '2000.00'
	}, {
		type: 2,
		title: "租房支出",
		time: "2019-05-12 11:53:06",
		balance: '4206.50',
		amount: '2500.00'
	}]
}