<template>
	<view class="tui-container">
		<t-header title="我的账单"></t-header>
		<view class="tui-outer__box">
			<tui-tab :tabs="tabs" scroll leftGap="44" scale="1.2" color="#828294" selectedColor="#1F244B"
				backgroundColor="transparent" bold :current="currentTab" @change="change"></tui-tab>
			<view class="tui-records__list">
				<view v-for="(item,index) in recordsList" :key="index" v-show="currentTab==index">
					<tui-list-cell margin-top="32" unlined radius="30" :hover="false"
						v-for="(model,subIndex) in item.data" :key="subIndex">
						<view class="tui-records__item">
							<view>
								<view class="tui-title">{{model.title}}</view>
								<view class="tui-desc">{{model.time}}</view>
							</view>
							<view class="tui-right__box">
								<view class="tui-amount" :class="{'tui-expend':model.type==2}">
									{{model.type==2?'-':'+'}}{{model.amount}}
								</view>
								<view class="tui-desc">余额: {{model.balance}}</view>
							</view>
						</view>
					</tui-list-cell>
					<!--加载loading-->
					<tui-loadmore v-if="recordsList[index].loading" :index="3" type="primary"></tui-loadmore>
					<tui-divider v-if="!recordsList[index].pullUpOn" background-color="#FEFBF7"
						width="50%">已全部加载</tui-divider>
					<!--加载loading-->
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import data from './index.js'
	export default {
		data() {
			return {
				tabs: ["全部", "收入", "支出"],
				currentTab: 0,
				recordsList: data.recordsList,
				requestData: data.requestData
			}
		},
		onLoad() {
			this.getRecordsList(this.currentTab)
		},
		methods: {
			change(e) {
				this.currentTab = e.index
				if (this.recordsList[this.currentTab].pageIndex == 1) {
					this.getRecordsList(this.currentTab)
				}
			},
			getRecordsList(index) {
				let item = this.recordsList[index]
				item.loading = true;
				setTimeout(() => {
					let recordsList = [...this.requestData];
					if (this.currentTab > 0) {
						recordsList = recordsList.filter(item => item.type === this.currentTab)
					}
					if (item.pageIndex == 1) {
						item.data = recordsList;
					} else {
						item.data = item.data.concat(recordsList);
					}
					if (item.pageIndex > 2 || recordsList.length < 10) {
						item.pullUpOn = false;
					}
					item.pageIndex++;
					item.loading = false;
				}, 50)
			}
		},
		onReachBottom() {
			let index = this.currentTab
			if (!this.recordsList[index].pullUpOn) return;
			this.getRecordsList(index)
		}
	}
</script>

<style>
	.tui-outer__box {
		padding: 50rpx 44rpx;
	}

	.tui-records__list {
		margin-top: 20rpx;
	}

	.tui-records__item {
		width: 100%;
		display: flex;
		align-items: center;
	}

	.tui-icon {
		width: 72rpx;
		height: 72rpx;
		margin-right: 20rpx;
	}

	.tui-title {
		font-size: 30rpx;
		font-weight: 400;
	}

	.tui-desc {
		font-size: 24rpx;
		font-weight: 400;
		color: #818194;
		padding-top: 12rpx;
	}

	.tui-right__box {
		margin-left: auto;
		text-align: right;
	}

	.tui-amount {
		font-size: 30rpx;
		font-weight: 400;
		color: #FF4B4F;
	}

	.tui-expend {
		color: #07c160 !important;
	}
</style>