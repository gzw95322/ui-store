<template>
	<view class="t-list__item" :style="{width,marginBottom:bottom+'rpx',marginTop:top+'rpx',marginRight:right+'rpx'}" @tap.stop="handleClick">
		<view class="t-img__box">
			<image class="t-img" src="/static/images/index/img_house_1.png" mode="widthFix"></image>
			<view class="t-score__box" @tap.stop="handleScoring">
				<tui-icon name="star-fill" size="26" unit="rpx" color="#FBBC04"></tui-icon>
				<text class="t-score">打分评价</text>
			</view>
		</view>
		<view class="t-tit__box">
			<tui-text font-weight="600" text="华润置地.有巢公寓 618限时超值半价" size="32"></tui-text>
		</view>
		<view class="t-align__center">
			<tui-icon name="position" unit="rpx" size="30"></tui-icon>
			<tui-text padding="0 0 0 8rpx" text="距8号线-联行路站1.1km" size="24" color="#818194"></tui-text>
		</view>

		<view class="t-check--box">
			<view class="t-check--inner">
				<view class="t-align__center">
					<tui-text text="入住时间" color="#555568" size="24"></tui-text>
					<image src="/static/images/my/icon_check_in.png" class="t-check--icon"></image>
				</view>
				<tui-text  text="2023/06/18" color="#818194" size="24"></tui-text>
			</view>
			<view>
				<view class="t-align__center">
					<tui-text text="退房时间" color="#555568" size="24"></tui-text>
					<image src="/static/images/my/icon_check_out.png" class="t-check--icon"></image>
				</view>
				<tui-text  text="2023/07/02" color="#818194" size="24"></tui-text>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "t-record",
		emits: ['click','scoring'],
		props: {
			width: {
				type: String,
				default: '100%'
			},
			item: {
				type: Object,
				default () {
					return {}
				}
			},
			top: {
				type: [Number, String],
				default: 0
			},
			bottom: {
				type: [Number, String],
				default: 32
			},
			right: {
				type: [Number, String],
				default: 32
			}

		},
		data() {
			return {

			};
		},
		methods: {
			handleClick() {
				this.$emit('click', {
					...this.item
				})
			},
			handleScoring(){
				this.$emit('scoring', {
					...this.item
				})
			}
		}
	}
</script>

<style scoped>
	.t-list__item {
		background: #FFFFFF;
		box-shadow: 0 8rpx 24rpx 0 rgba(132, 67, 67, 0.05);
		border-radius: 30rpx;
		padding: 20rpx;
		box-sizing: border-box;
	}

	.t-img__box {
		width: 100%;
		position: relative;
	}

	.t-img {
		width: 100%;
		display: block;
	}

	.t-score__box {
		position: absolute;
		right: 12rpx;
		top: 12rpx;
		font-size: 24rpx;
		line-height: 28rpx;
		color: #FFFFFF;
		background: rgba(35, 21, 21, .4);
		border-radius: 10rpx;
		padding: 8rpx 12rpx;
		/* #ifdef H5 */
		cursor: pointer;
		/* #endif */
	}

	.t-score {
		zoom: .9;
		padding-left: 4rpx;
		line-height: 24rpx;
	}

	.t-tit__box {
		width: 100%;
		padding: 20rpx 0 16rpx;
	}

	.t-align__center {
		display: flex;
		align-items: center;
	}
	.t-check--box{
		display: flex;
		align-items: center;
		padding-top: 20rpx;
	}
	.t-check--icon{
		width: 26rpx;
		height: 26rpx;
		margin-left: 4rpx;
	}
   .t-check--inner{
	   margin-right: 96rpx;
   }
	
</style>