<template>
	<view class="t-list__item" :style="{width,marginBottom:bottom+'rpx',marginTop:top+'rpx',marginRight:right+'rpx'}" @tap.stop="handleClick">
		<view class="t-img__box">
			<image class="t-img" src="/static/images/index/img_house_1.png" mode="widthFix"></image>
			<view class="t-score__box">
				<tui-icon name="star-fill" size="26" unit="rpx" color="#FBBC04"></tui-icon>
				<text class="t-score">4.6</text>
			</view>
		</view>
		<view class="t-tit__box">
			<tui-text font-weight="600" text="合租 3居室" size="32"></tui-text>
			<view>
				<tui-text size="24" type="primary" text="￥"></tui-text>
				<tui-text text="2500" type="primary" size="28" font-weight="600"></tui-text>
				<tui-text size="24" text="/月" color="#555568"></tui-text>
			</view>
		</view>
		<view class="t-align__center">
			<tui-icon name="position" unit="rpx" size="30"></tui-icon>
			<tui-text padding="0 0 0 8rpx" text="距8号线-联行路站1.1km" size="24" color="#818194"></tui-text>
		</view>

		<view class="t-align__center t-padding">
			<view class="t-info__box">
				<view class="t-icon__box">
					<image class="t-info--icon" src="/static/images/renting/icon_bed.png" mode="widthFix"></image>
				</view>
				<tui-text text="3床" font-weight="500" size="24"></tui-text>
			</view>
			<view class="t-info__box">
				<view class="t-icon__box">
					<image class="t-info--icon t-width" src="/static/images/renting/icon_toilet.png" mode="widthFix">
					</image>
				</view>
				<tui-text text="2卫" font-weight="500" size="24"></tui-text>
			</view>
			<view class="t-info__box">
				<view class="t-icon__box">
					<image class="t-info--icon" src="/static/images/renting/icon_area.png" mode="widthFix"></image>
				</view>
				<tui-text text="124㎡" font-weight="500" size="24"></tui-text>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "t-list-item",
		emits: ['click'],
		props: {
			width: {
				type: String,
				default: '544rpx'
			},
			item: {
				type: Object,
				default () {
					return {}
				}
			},
			top: {
				type: [Number, String],
				default: 0
			},
			bottom: {
				type: [Number, String],
				default: 32
			},
			right: {
				type: [Number, String],
				default: 32
			}

		},
		data() {
			return {

			};
		},
		methods: {
			handleClick() {
				this.$emit('click', {
					...this.item
				})
			}
		}
	}
</script>

<style scoped>
	.t-list__item {
		background: #FFFFFF;
		box-shadow: 0 8rpx 24rpx 0 rgba(132, 67, 67, 0.05);
		border-radius: 30rpx;
		padding: 20rpx;
		box-sizing: border-box;
	}

	.t-img__box {
		width: 100%;
		position: relative;
	}

	.t-img {
		width: 100%;
		display: block;
	}

	.t-score__box {
		position: absolute;
		right: 12rpx;
		top: 12rpx;
		font-size: 24rpx;
		line-height: 28rpx;
		color: #FFFFFF;
		background: rgba(35, 21, 21, .4);
		border-radius: 10rpx;
		padding: 6rpx 12rpx;
	}

	.t-score {
		zoom: .9;
		padding-left: 4rpx;
		line-height: 24rpx;
	}

	.t-tit__box {
		width: 100%;
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 20rpx 0 16rpx;
	}

	.t-align__center {
		display: flex;
		align-items: center;
	}

	.t-info__box {
		display: flex;
		align-items: center;
		margin-right: 50rpx
	}

	.t-padding {
		padding: 32rpx 0 8rpx;
	}

	.t-icon__box {
		width: 52rpx;
		height: 52rpx;
		background: rgba(31, 36, 75, .1);
		border-radius: 16rpx;
		display: flex;
		align-items: center;
		justify-content: center;
		margin-right: 16rpx;
	}

	.t-info--icon {
		width: 32rpx;
		height: 32rpx;
	}

	.t-width {
		width: 28rpx;
		height: 28rpx;
	}
</style>