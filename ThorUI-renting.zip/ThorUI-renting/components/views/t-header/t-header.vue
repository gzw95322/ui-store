<template>
	<view class="t-header__wrap">
		<view class="t-header__box" :class="{'tui-fixed':isFixed}"
			:style="{background,height:(isBg?maxHeight:208)+'rpx'}">
			<template v-if="isBg">
				<view class="t-bg__inner"></view>
				<view class="t-bg__outer"></view>
			</template>
		</view>
		<!-- #ifndef H5 -->
		<view class="t-header__box" :class="{'tui-fixed':isFixed,'t-nav__box':isFixed}" :style="{background,zIndex}"
			v-if="isFixed">
			<template v-if="isBg">
				<view class="t-bg__inner"></view>
				<view class="t-bg__outer"></view>
			</template>
			<!-- #ifndef MP-ALIPAY || MP-BAIDU-->
			<image v-if="src && isBack" :src="src" class="t-icon__back" @tap.stop="navBack"></image>
			<!-- #endif -->
			<view class="t-nav__title" v-if="title">{{title}} </view>
			<view class="t-nav__descr" v-if="descr">{{descr}}</view>
			<slot></slot>
		</view>
		<view v-if="!isFixed">
			<slot></slot>
		</view>
		<!-- #endif -->
		<!-- #ifdef H5 -->
		<slot></slot>
		<!-- #endif -->
	</view>
</template>

<script>
	export default {
		name: "t-header",
		props: {
			src: {
				type: String,
				default: '/static/images/common/icon_back.png'
			},
			title: {
				type: String,
				default: ''
			},
			descr: {
				type: String,
				default: ''
			},
			maxHeight: {
				type: [Number, String],
				default: 880
			},
			background: {
				type: String,
				default: '#FFAB4B'
			},
			isBg: {
				type: Boolean,
				default: true
			},
			isBack: {
				type: Boolean,
				default: true
			},
			isFixed: {
				type: Boolean,
				default: true
			},
			zIndex: {
				type: [Number, String],
				default: 99
			}
		},
		data() {
			return {

			};
		},
		methods: {
			navBack() {
				uni.navigateBack()
			}
		}
	}
</script>

<style scoped>
	.t-header__wrap {
		position: relative;
	}

	.t-header__box {
		width: 100%;
		overflow: hidden;
		transform: translateZ(0);
		position: relative;
	}

	.tui-fixed {
		position: fixed;
		left: 0;
		top: 0;
	}

	.t-nav__box {
		height: 208rpx;
		z-index: 10;
	}

	.t-bg__inner {
		width: 308rpx;
		height: 308rpx;
		background: linear-gradient(35deg, rgba(255, 255, 255, 0.2) 0%, rgba(255, 255, 255, 0.04) 100%);
		position: absolute;
		border-radius: 50%;
		right: -100rpx;
		top: -100rpx;
		z-index: 2;
		opacity: .7;
		overflow: hidden;
	}

	.t-bg__outer {
		width: 380rpx;
		height: 380rpx;
		background: linear-gradient(154deg, rgba(255, 255, 255, 0.4) 0%, rgba(255, 255, 255, 0) 92%);
		position: absolute;
		border-radius: 50%;
		right: -100rpx;
		top: -120rpx;
		z-index: 1;
		opacity: .7;
	}

	.t-icon__back {
		position: absolute;
		left: 44rpx;
		top: 108rpx;
		width: 90rpx;
		height: 90rpx;
		z-index: 3;
		/* #ifdef H5 */
		cursor: pointer;
		/* #endif */
	}

	.t-icon__back:active {
		opacity: .5;
	}

	.t-nav__title {
		position: absolute;
		left: 138rpx;
		right: 138rpx;
		top: 108rpx;
		height: 82rpx;
		display: flex;
		align-items: center;
		justify-content: center;
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
		font-size: 36rpx;
		font-weight: 500;
		color: #FFFFFF;
		z-index: 3;
	}

	.t-nav__descr {
		width: 100%;
		color: #FFF5E9;
		font-size: 25rpx;
		transform: scale(.8);
		position: absolute;
		bottom: 0;
		text-align: center;
		z-index: 3;
	}

	.tui-custom__content {
		position: relative;
		z-index: 3;
	}
</style>