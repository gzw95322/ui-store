<template>
	<view class="t-list__cell" :style="{marginBottom:bottom+'rpx',marginTop:top+'rpx'}" @tap.stop="handleClick">
		<view class="t-cell--imgbox">
			<image class="t-cell--img" mode="widthFix" src="/static/images/index/img_house_01.png"></image>
		</view>
		<view class="t-right__box">
			<tui-text font-weight="600" text="合租 3居室 19.4㎡" size="32"></tui-text>
			<view class="t-align__center">
				<tui-icon name="position" size="30" unit="rpx"></tui-icon>
				<tui-text padding="0 0 0 8rpx" text="距8号线-联行路站1.1km" size="24" color="#818194"></tui-text>
			</view>
			<view>
				<tui-text size="24" type="primary" text="￥"></tui-text>
				<tui-text text="2500" type="primary" size="28" font-weight="600"></tui-text>
				<tui-text size="24" text="/月" color="#555568"></tui-text>
			</view>
		</view>
		<view class="t-score__box">
			<tui-icon name="star-fill" size="26" unit="rpx" color="#FBBC04"></tui-icon>
			<text class="t-score">4.6</text>
		</view>
	</view>
</template>

<script>
	export default {
		name: "t-list-cell",
		emits: ['click'],
		props: {
			item: {
				type: Object,
				default () {
					return {}
				}
			},
			top: {
				type: [Number, String],
				default: 0
			},
			bottom: {
				type: [Number, String],
				default: 32
			}
		},
		data() {
			return {

			};
		},
		methods: {
			handleClick() {
				this.$emit('click', {
					...this.item
				})
			}
		}
	}
</script>

<style scoped>
	.t-list__cell {
		width: 100%;
		padding: 20rpx;
		border-radius: 30rpx;
		background-color: #fff;
		display: flex;
		align-items: center;
		box-sizing: border-box;
		position: relative;
		box-shadow: 0 8rpx 24rpx 0 rgba(132, 67, 67, 0.05);
	}

	.t-cell--imgbox {
		width: 218rpx;
		height: 152rpx;
		display: flex;
		align-items: center;
		justify-content: center;
		border-radius: 30rpx;
		overflow: hidden;
		flex-shrink: 0;
		margin-right: 30rpx;
	}

	.t-cell--img {
		width: 218rpx;
		height: 152rpx;
		border-radius: 30rpx;
		display: block;
	}

	.t-right__box {
		flex: 1;
		height: 152rpx;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}


	.t-align__center {
		display: flex;
		align-items: center;
	}

	.t-score__box {
		position: absolute;
		right: 20rpx;
		top: 20rpx;
		font-size: 24rpx;
		line-height: 28rpx;
		color: #555568;
		padding: 6rpx 0;
	}

	.t-score {
		zoom: .9;
		padding-left: 8rpx;
		line-height: 24rpx;
	}
</style>